// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Interactive Help & Module Selection
const {
    SlashCommandBuilder,
    EmbedBuilder,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ComponentType
} = require('discord.js');
const emojis = require('../../emojis.json');
const config = require('../../config');

const SUPPORT_SERVER_URL = 'https://discord.gg/YamDeqrbxV';

const categories = {
    antinuke: {
        name: 'Anti-Nuke',
        description: 'Server protection against raids, mass bans, and malicious bots',
        catEmoji: 'shield',
        commands: [
            '?antinuke', '?antinuke enable', '?antinuke disable', '?antinuke status',
            '?antinuke diagnose', '?antinuke filters', '?antinuke logs', '?antinuke wizard',
            '?antinuke settings', '?antinuke panic', '?antinuke wl', '?extraowner set'
        ]
    },
    linkprotection: {
        name: 'Link Protection',
        description: 'Block prohibited links, Discord invite links, and untrusted URLs',
        catEmoji: 'cat_automod',
        commands: [
            '?linkprotection enable', '?linkprotection disable', '?linkprotection status',
            '?linkprotection whitelist', '?linkprotection logs'
        ]
    },
    antispam: {
        name: 'Anti-Spam',
        description: 'Detect message flooding, duplicate text, and mass mentions',
        catEmoji: 'cat_automod',
        commands: [
            '?antispam enable', '?antispam disable', '?antispam status', '?antispam settings'
        ]
    },
    antiraid: {
        name: 'Anti-Raid',
        description: 'Detect abnormal member join bursts and alert administrators',
        catEmoji: 'shield',
        commands: [
            '?antiraid enable', '?antiraid disable', '?antiraid status', '?antiraid settings'
        ]
    },
    automod: {
        name: 'AutoMod',
        description: 'Automated word filtering, caps, zalgo, and ping controls',
        catEmoji: 'cat_automod',
        commands: [
            '?automod', '?automod enable', '?automod disable', '?automod status',
            '?automod settings', '?automod rules', '?automod logs', '?automod whitelist',
            '?automod blacklist add', '?automod blacklist remove'
        ]
    },
    moderation: {
        name: 'Moderation',
        description: 'Ban, kick, timeout, warn, slowmode, channel locks, and case logs',
        catEmoji: 'crown',
        commands: [
            '?ban', '?unban', '?kick', '?timeout', '?warn', '?warnings',
            '?clearwarns', '?purge', '?lock', '?unlock', '?slowmode', '?nick'
        ]
    },
    logging: {
        name: 'Logging',
        description: 'Real-time security alerts, message audits, and member activity logs',
        catEmoji: 'cat_logging',
        commands: [
            '?logging setup', '?logging config', '?logging reset', '?logging test'
        ]
    },
    autorole: {
        name: 'AutoRole',
        description: 'Automatic role assignment for new human and bot members',
        catEmoji: 'cat_welcome',
        commands: [
            '?autorole humans', '?autorole bots', '?autorole config', '?autorole reset'
        ]
    },
    greetings: {
        name: 'Greetings',
        description: 'Customizable welcome and farewell messages with image cards',
        catEmoji: 'cat_welcome',
        commands: [
            '?welcome setup', '?welcome config', '?welcome test', '?welcome reset',
            '?farewell setup', '?farewell config', '?farewell test'
        ]
    },
    tickets: {
        name: 'Tickets',
        description: 'Private support tickets, category routing, and transcript archives',
        catEmoji: 'cat_tickets',
        commands: [
            '?ticket setup', '?ticket panel', '?ticket close', '?ticket claim',
            '?ticket transcript', '?ticket delete'
        ]
    },
    giveaways: {
        name: 'Giveaways',
        description: 'Create, schedule, end, and reroll server giveaways',
        catEmoji: 'cat_giveaway',
        commands: [
            '?giveaway start', '?giveaway end', '?giveaway reroll', '?giveaway list'
        ]
    },
    premium: {
        name: 'Premium',
        description: 'Server protection tiers, Premium User licenses, entitlements, and redemption codes',
        catEmoji: 'star',
        commands: [
            '?premium', '?premium status', '?premium activate', '?premium servers',
            '?premium-user <@user> <time>', '?premium-remove <@user>', '?plans', '?redeem <CODE>'
        ]
    },
    subscriptions: {
        name: 'Subscriptions',
        description: 'Manage active subscriptions, renewals, and payment billing',
        catEmoji: 'star',
        commands: [
            '?subscription', '?subscription history', '?plans', '?subscribe',
            '?activate', '?renew', '?cancel', '?redeem <CODE>'
        ]
    },
    generalsecurity: {
        name: 'General Security',
        description: 'Master security control panel, diagnostics, and permission checks',
        catEmoji: 'shield',
        commands: [
            '?security', '?security enable', '?security disable', '?security status',
            '?security diagnose', '?security permissions', '?security logs', '?security wizard'
        ]
    }
};

function formatEmoji(key) {
    return emojis[key] || emojis.shield || '🛡️';
}

function parseSelectEmoji(str) {
    if (!str) return '🛡️';
    const match = str.match(/<a?:(\w+):(\d+)>/);
    if (match) {
        return { name: match[1], id: match[2] };
    }
    return str;
}

function buildHelpEmbed(categoryKey = null, botUser, guildPrefix = '?') {
    const embed = new EmbedBuilder()
        .setColor(0x0A0E17)
        .setThumbnail(botUser.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ • Advanced Server Defense', iconURL: botUser.displayAvatarURL() })
        .setTimestamp();

    if (!categoryKey) {
        const categoryLines = Object.entries(categories).map(([k, cat]) => {
            const emojiStr = formatEmoji(cat.catEmoji);
            return `> ${emojiStr} \`»\` **${cat.name}** — *${cat.description}*`;
        }).join('\n');

        embed.setTitle(`𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™`)
            .setDescription(
                `### Advanced Discord Server Protection\n` +
                `Guarding against mass nukes, malicious administrators, token raids, and abusive spam.\n\n` +
                `**Prefix:** \`${guildPrefix}\` | [Support Server](${SUPPORT_SERVER_URL})\n\n` +
                `**🛡️ Available Protection Modules:**\n${categoryLines}\n\n` +
                `*Select a module from the dropdown menu below to view commands and details.*`
            );
    } else {
        const cat = categories[categoryKey];
        if (!cat) return buildHelpEmbed(null, botUser, guildPrefix);

        const emojiStr = formatEmoji(cat.catEmoji);
        const cmdFormatted = cat.commands.map(cmd => `\`${cmd.replace('?', guildPrefix)}\``).join('  ');

        embed.setTitle(`${emojiStr} ${cat.name} Commands`)
            .setDescription(
                `**Module Overview:**\n${cat.description}\n\n` +
                `**Available Commands:**\n${cmdFormatted}\n\n` +
                `*Use \`${guildPrefix}help\` or select Overview from the dropdown to return.*`
            );
    }

    return embed;
}

function buildSelectMenu(activeKey = null) {
    const menu = new StringSelectMenuBuilder()
        .setCustomId('help_category_select')
        .setPlaceholder('Choose a module to explore...');

    const overviewOption = new StringSelectMenuOptionBuilder()
        .setLabel('Overview & Main Menu')
        .setValue('overview')
        .setDescription('Return to the main category directory')
        .setEmoji('🏠')
        .setDefault(!activeKey || activeKey === 'overview');

    const options = [overviewOption];

    for (const [key, cat] of Object.entries(categories)) {
        const rawEmoji = formatEmoji(cat.catEmoji);
        const opt = new StringSelectMenuOptionBuilder()
            .setLabel(`${cat.name}`)
            .setValue(key)
            .setDescription(cat.description.slice(0, 50))
            .setEmoji(parseSelectEmoji(rawEmoji))
            .setDefault(activeKey === key);
        options.push(opt);
    }

    menu.addOptions(options);
    return new ActionRowBuilder().addComponents(menu);
}

function buildLinksRow() {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setLabel('Support Server')
            .setStyle(ButtonStyle.Link)
            .setURL(SUPPORT_SERVER_URL)
    );
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Display the interactive command help menu (𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™)')
        .addStringOption(opt =>
            opt.setName('module')
                .setDescription('Select a specific module to inspect')
                .setRequired(false)
        ),

    name: 'help',
    aliases: ['h', 'commands'],
    description: 'Display the interactive command help menu',

    async execute(interactionOrMessage, args = []) {
        const isSlash = interactionOrMessage.isCommand?.();
        const client = interactionOrMessage.client;
        const guildId = interactionOrMessage.guild?.id;

        let requestedModule = isSlash
            ? interactionOrMessage.options?.getString?.('module')?.toLowerCase()
            : args[0]?.toLowerCase();

        let guildPrefix = config.PREFIX || '?';
        if (guildId) {
            try {
                const { GuildPrefix } = require('../../data/models');
                const customPrefix = await GuildPrefix.getPrefix(guildId);
                if (customPrefix) guildPrefix = customPrefix;
            } catch (_) {}
        }

        const initialKey = (requestedModule && categories[requestedModule]) ? requestedModule : null;
        const embed = buildHelpEmbed(initialKey, client.user, guildPrefix);
        const selectRow = buildSelectMenu(initialKey);
        const buttonsRow = buildLinksRow();

        const payload = {
            embeds: [embed],
            components: [selectRow, buttonsRow]
        };

        let responseMsg;
        if (isSlash) {
            responseMsg = await interactionOrMessage.reply({ ...payload, fetchReply: true });
        } else {
            responseMsg = await interactionOrMessage.reply(payload);
        }

        const collector = responseMsg.createMessageComponentCollector({
            componentType: ComponentType.StringSelect,
            time: 180000
        });

        collector.on('collect', async (i) => {
            const authorId = isSlash ? interactionOrMessage.user.id : interactionOrMessage.author.id;
            if (i.user.id !== authorId) {
                return i.reply({ content: `${emojis.cross || '❌'} This menu was opened by someone else. Type \`${guildPrefix}help\` to open your own.`, ephemeral: true });
            }

            const selected = i.values[0];
            const newKey = selected === 'overview' ? null : selected;
            const updatedEmbed = buildHelpEmbed(newKey, client.user, guildPrefix);
            const updatedSelect = buildSelectMenu(newKey);

            await i.update({
                embeds: [updatedEmbed],
                components: [updatedSelect, buttonsRow]
            });
        });

        collector.on('end', async () => {
            try {
                const disabledSelect = buildSelectMenu(null);
                disabledSelect.components[0].setDisabled(true);
                await responseMsg.edit({ components: [disabledSelect, buttonsRow] });
            } catch (_) {}
        });
    }
};