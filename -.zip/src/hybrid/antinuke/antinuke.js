// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Anti-Nuke Command
const {
    SlashCommandBuilder,
    MessageFlags,
    PermissionFlagsBits,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle
} = require('discord.js');
const { AntinukeConfig, AntinukeWhitelist, ExtraOwner, SecurityAuditLog } = require('../../data/models');
const { isAuthorizedOwner, sendSecurityReply } = require('../../lib/securityAuth');
const config = require('../../config');
const emojis = require('../../emojis.json');

const SUPPORT_SERVER_URL = config.SUPPORT_SERVER || 'https://discord.gg/YamDeqrbxV';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('antinuke')
        .setDescription('Protect your server from nuking attacks (𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™)')
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable the antinuke system'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable the antinuke system'))
        .addSubcommand(sub => sub.setName('panic').setDescription('Emergency lockdown all server channels'))
        .addSubcommand(sub => sub.setName('lockdown')
            .setDescription('Lockdown or unlock server channels')
            .addStringOption(opt => opt.setName('state').setDescription('State').addChoices({ name: 'on', value: 'on' }, { name: 'off', value: 'off' }))
        )
        .addSubcommand(sub => sub.setName('unlock').setDescription('Lift server emergency lockdown'))
        .addSubcommand(sub => sub.setName('wizard').setDescription('Setup antinuke with interactive wizard'))
        .addSubcommand(sub => sub.setName('setup').setDescription('Setup antinuke with interactive wizard'))
        .addSubcommand(sub => sub.setName('settings').setDescription('View and edit current antinuke settings'))
        .addSubcommand(sub => sub.setName('status').setDescription('View antinuke protection status'))
        .addSubcommand(sub => sub.setName('diagnose').setDescription('Run system diagnostics and permission check'))
        .addSubcommand(sub => sub.setName('filters').setDescription('List active antinuke protection filters'))
        .addSubcommand(sub => sub.setName('logs').setDescription('View antinuke log channel and recent triggers'))
        .addSubcommand(sub =>
            sub.setName('whitelist')
                .setDescription('Manage whitelisted users')
                .addStringOption(opt =>
                    opt.setName('action')
                        .setDescription('Action')
                        .addChoices(
                            { name: 'add', value: 'add' },
                            { name: 'remove', value: 'remove' },
                            { name: 'list', value: 'list' }
                        )
                )
                .addUserOption(opt => opt.setName('user').setDescription('Target user'))
        )
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset antinuke to defaults')),

    name: 'antinuke',
    aliases: ['an', 'nuke'],
    description: 'Protect your server from nuking attacks',

    async execute(interactionOrMessage, args = []) {
        const isSlash = interactionOrMessage.isCommand?.();
        let subcommand;

        if (isSlash) {
            subcommand = interactionOrMessage.options.getSubcommand();
        } else {
            subcommand = args[0]?.toLowerCase();
            args = args.slice(1);
        }

        if (subcommand === 'panic') {
            return this.handleLockdown(interactionOrMessage, true);
        }
        if (subcommand === 'lockdown') {
            const state = isSlash ? interactionOrMessage.options.getString('state') : args[0]?.toLowerCase();
            const enable = state !== 'off' && state !== 'disable' && state !== 'false' && state !== 'unlock';
            return this.handleLockdown(interactionOrMessage, enable);
        }
        if (subcommand === 'unlock') {
            return this.handleLockdown(interactionOrMessage, false);
        }
        if (subcommand === 'wl') {
            const whitelistCmd = require('./subcommands/whitelist');
            return whitelistCmd.execute(interactionOrMessage, ['add', ...args]);
        }
        if (subcommand === 'unwl') {
            const whitelistCmd = require('./subcommands/whitelist');
            return whitelistCmd.execute(interactionOrMessage, ['remove', ...args]);
        }
        if (subcommand === 'wlist') {
            const whitelistCmd = require('./subcommands/whitelist');
            return whitelistCmd.execute(interactionOrMessage, ['list', ...args]);
        }
        if (subcommand === 'wlreset') {
            return this.handleWhitelistReset(interactionOrMessage);
        }
        if (subcommand === 'wizard' || subcommand === 'setup') {
            const setupCmd = require('./subcommands/setup');
            return setupCmd.execute(interactionOrMessage, args);
        }
        if (subcommand === 'status') {
            return this.handleStatus(interactionOrMessage);
        }
        if (subcommand === 'diagnose' || subcommand === 'permissions') {
            return this.handleDiagnose(interactionOrMessage);
        }
        if (subcommand === 'filters') {
            return this.handleFilters(interactionOrMessage);
        }
        if (subcommand === 'logs') {
            return this.handleLogs(interactionOrMessage);
        }

        if (subcommand === 'whitelist') {
            const whitelistCmd = require('./subcommands/whitelist');
            return whitelistCmd.execute(interactionOrMessage, args);
        }

        if (subcommand && ['settings', 'enable', 'disable', 'reset'].includes(subcommand)) {
            const subcommandFile = require(`./subcommands/${subcommand}`);
            return subcommandFile.execute(interactionOrMessage, args);
        }

        return this.handleStatus(interactionOrMessage);
    },

    async handleLockdown(ctx, enable = true) {
        const member = ctx.member;
        const guild = ctx.guild;

        if (!guild) return;

        const authorized = await isAuthorizedOwner(member, guild);
        if (!authorized) {
            return sendSecurityReply(ctx, {
                title: `${emojis.cross || '❌'} Access Denied`,
                description: 'Only the **Server Owner** or authorized **Extra Owners** can engage Lockdown / Panic Mode.',
                color: 0xEF4444,
                ephemeral: true
            });
        }

        const botMember = guild.members.me;
        if (!botMember?.permissions?.has(PermissionFlagsBits.ManageChannels)) {
            return sendSecurityReply(ctx, {
                title: `${emojis.cross || '❌'} Missing Bot Permissions`,
                description: 'I need the **Manage Channels** permission to enforce server lockdown.',
                color: 0xEF4444,
                ephemeral: true
            });
        }

        const everyoneRole = guild.roles.everyone;
        const channels = guild.channels.cache.filter(c => c.isTextBased() && !c.isThread() && c.permissionsFor(botMember)?.has(PermissionFlagsBits.ManageChannels));

        let count = 0;
        for (const [, channel] of channels) {
            try {
                await channel.permissionOverwrites.edit(everyoneRole, {
                    SendMessages: enable ? false : null,
                    SendMessagesInThreads: enable ? false : null,
                    CreatePublicThreads: enable ? false : null,
                    CreatePrivateThreads: enable ? false : null,
                    AddReactions: enable ? false : null
                }, { reason: `𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Emergency ${enable ? 'Lockdown' : 'Unlock'} by ${member.user?.tag || member.id}` });
                count++;
            } catch (_) {}
        }

        try {
            await SecurityAuditLog.create({
                guildId: guild.id,
                module: 'ANTINUKE',
                action: enable ? 'LOCKDOWN_ON' : 'LOCKDOWN_OFF',
                executorId: member.id,
                targetId: guild.id,
                reason: `Emergency server lockdown ${enable ? 'engaged' : 'lifted'} (${count} channels)`
            });
        } catch (_) {}

        if (enable) {
            return sendSecurityReply(ctx, {
                title: `${emojis.warning || '⚠️'} 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Emergency Lockdown Active`,
                description:
                    `${emojis.shield || '🛡️'} **SERVER EMERGENCY LOCKDOWN ACTIVATED!**\n\n` +
                    `• **Locked Channels:** \`${count}\` text channels secured.\n` +
                    `• **Effect:** Standard members cannot send messages, create threads, or add reactions.\n` +
                    `• **Staff Access:** Whitelisted administrators and Extra Owners retain access.\n\n` +
                    `*To restore standard server chat, run:* \`?antinuke unlock\` or \`?antinuke lockdown off\``,
                color: 0xEF4444,
                ephemeral: false
            });
        } else {
            return sendSecurityReply(ctx, {
                title: `${emojis.check || '✅'} 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Lockdown Lifted`,
                description:
                    `${emojis.success || '✅'} **Server Lockdown has been deactivated.**\n\n` +
                    `• **Unlocked Channels:** \`${count}\` channels restored to standard permissions.\n` +
                    `• **Status:** Normal member chat restored. Anti-Nuke shield remains vigilant 24/7!`,
                color: 0x10B981,
                ephemeral: false
            });
        }
    },

    async handleStatus(ctx) {
        const guild = ctx.guild;
        const config = await AntinukeConfig.findOne({ where: { guildId: guild.id } });
        const whitelistCount = await AntinukeWhitelist.count({ where: { guildId: guild.id } });
        const extraOwnerCount = await ExtraOwner.count({ where: { guildId: guild.id } });

        const botMember = guild.members.me;
        const requiredPerms = [
            { perm: PermissionFlagsBits.ViewAuditLog, name: 'View Audit Log' },
            { perm: PermissionFlagsBits.ManageChannels, name: 'Manage Channels' },
            { perm: PermissionFlagsBits.ManageRoles, name: 'Manage Roles' },
            { perm: PermissionFlagsBits.KickMembers, name: 'Kick Members' },
            { perm: PermissionFlagsBits.BanMembers, name: 'Ban Members' },
            { perm: PermissionFlagsBits.ManageWebhooks, name: 'Manage Webhooks' }
        ];

        const missingPerms = requiredPerms.filter(p => !botMember?.permissions?.has(p.perm));
        const isEnabled = config?.enabled || false;

        let stateText = isEnabled ? 'ACTIVE & GUARDING' : 'DISABLED';
        let stateColor = isEnabled ? 0x10B981 : 0x64748B;

        if (isEnabled && missingPerms.length > 0) {
            stateText = `DEGRADED (Missing ${missingPerms.length} required bot permissions!)`;
            stateColor = 0xF59E0B;
        }

        const logWarn = !config?.logChannelId ? `\n⚠️ **Warning:** No log channel configured! Run \`?antinuke settings\` to set one.` : '';
        const permWarn = missingPerms.length > 0 ? `\n⚠️ **Missing Permissions:** ${missingPerms.map(p => `\`${p.name}\``).join(', ')}` : '';

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel('Support Server')
                .setStyle(ButtonStyle.Link)
                .setURL(SUPPORT_SERVER_URL)
        );

        return sendSecurityReply(ctx, {
            title: `${emojis.shield || '🛡️'} 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Anti-Nuke Status`,
            description:
                `**System State:** ${isEnabled ? '🟢' : '🔴'} **${stateText}**${permWarn}${logWarn}\n\n` +
                `• **Punishment:** \`${config?.punishment || 'stripall'}\` (Remove dangerous administrative permissions)\n` +
                `• **Action Threshold:** \`${config?.threshold || 3} actions\` per \`${config?.timeframe || 60}s\`\n` +
                `  *(Note: Threshold >1 allows initial actions before containment. Strict Mode triggers on action 1)*\n` +
                `• **Strict Instant Mode:** \`${config?.strict !== false ? 'ON (Instant Containment)' : 'OFF (Threshold Enforced)'}\`\n` +
                `• **Auto-Recovery:** \`${config?.autoRecovery !== false ? 'ENABLED (Recreates deleted channels/roles)' : 'DISABLED'}\`\n` +
                `• **Log Channel:** ${config?.logChannelId ? `<#${config.logChannelId}>` : '*None configured*'}\n` +
                `• **Whitelisted Admins:** \`${whitelistCount}\` user(s)\n` +
                `• **Extra Owners:** \`${extraOwnerCount}\` user(s)\n` +
                `• **Dry-Run Mode:** \`${config?.dryRun ? 'ON (Simulated)' : 'OFF (Enforcing)'}\`\n\n` +
                `*Quick Commands:*\n` +
                `• \`?antinuke enable\` — Enable full protection\n` +
                `• \`?antinuke diagnose\` — Run deep permission & component diagnostics\n` +
                `• \`?antinuke panic\` — Emergency lockdown all channels\n` +
                `• \`?antinuke wl @user\` — Whitelist a trusted administrator`,
            color: stateColor,
            components: [row]
        });
    },

    async handleDiagnose(ctx) {
        const guild = ctx.guild;
        const botMember = guild.members.me;

        const checks = [
            { name: 'View Audit Log', pass: botMember?.permissions?.has(PermissionFlagsBits.ViewAuditLog), detail: 'Required to identify destructive actors' },
            { name: 'Manage Channels', pass: botMember?.permissions?.has(PermissionFlagsBits.ManageChannels), detail: 'Required for lockdown & channel recovery' },
            { name: 'Manage Roles', pass: botMember?.permissions?.has(PermissionFlagsBits.ManageRoles), detail: 'Required for role recovery & stripping perms' },
            { name: 'Kick Members', pass: botMember?.permissions?.has(PermissionFlagsBits.KickMembers), detail: 'Required for kicking rogue bots/attackers' },
            { name: 'Ban Members', pass: botMember?.permissions?.has(PermissionFlagsBits.BanMembers), detail: 'Required for banning attackers' },
            { name: 'Manage Webhooks', pass: botMember?.permissions?.has(PermissionFlagsBits.ManageWebhooks), detail: 'Required for anti-webhook containment' },
            { name: 'Manage Server', pass: botMember?.permissions?.has(PermissionFlagsBits.ManageGuild), detail: 'Required for anti-server update protection' },
            { name: 'Administrator', pass: botMember?.permissions?.has(PermissionFlagsBits.Administrator), detail: 'Recommended for maximum security enforcement' }
        ];

        const config = await AntinukeConfig.findOne({ where: { guildId: guild.id } });
        const hasLogChannel = Boolean(config?.logChannelId && guild.channels.cache.has(config.logChannelId));

        const failedChecks = checks.filter(c => !c.pass);
        let overallStatus = 'OPERATIONAL';
        let statusColor = 0x10B981;

        if (failedChecks.length > 0) {
            overallStatus = failedChecks.some(c => c.name === 'View Audit Log' || c.name === 'Manage Roles') ? 'DEGRADED / CRITICAL PERMISSIONS MISSING' : 'DEGRADED';
            statusColor = 0xEF4444;
        }

        const checkLines = checks.map(c => `${c.pass ? '✅' : '❌'} **${c.name}** — ${c.pass ? 'Granted' : `*MISSING* (${c.detail})`}`).join('\n');

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel('Support Server')
                .setStyle(ButtonStyle.Link)
                .setURL(SUPPORT_SERVER_URL)
        );

        return sendSecurityReply(ctx, {
            title: `${emojis.shield || '🛡️'} 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Anti-Nuke Diagnostics`,
            description:
                `**System Diagnosis:** \`${overallStatus}\`\n` +
                `**Log Channel Status:** ${hasLogChannel ? '✅ Configured' : '⚠️ *Missing (Security alerts will not be posted)*'}\n\n` +
                `**Permission Check Results:**\n${checkLines}\n\n` +
                `*Troubleshooting Instructions:*\n` +
                `1. Grant **Administrator** or missing permissions to the bot role in Server Settings.\n` +
                `2. Move the **𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™** role above all untrusted admin roles in Role Hierarchy.\n` +
                `3. Set a log channel with \`?antinuke settings\`.`,
            color: statusColor,
            components: [row]
        });
    },

    async handleFilters(ctx) {
        const guild = ctx.guild;
        const config = await AntinukeConfig.findOne({ where: { guildId: guild.id } });

        const f = (val) => val ? (emojis.check || '✅') : (emojis.cross || '❌');
        const isEnabled = config?.enabled || false;

        return sendSecurityReply(ctx, {
            title: `${emojis.shield || '🛡️'} 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Anti-Nuke Filters`,
            description:
                `**Overall System State:** ${isEnabled ? `${emojis.check || '✅'} **ENABLED**` : `${emojis.cross || '❌'} **DISABLED**`}\n\n` +
                `**Active Protection Modules:**\n` +
                `• ${f(config?.antiBan !== false)} **Mass Bans Protection** (Auto-revert & punish)\n` +
                `• ${f(config?.antiKick !== false)} **Mass Kicks Protection** (Rate limit kicks)\n` +
                `• ${f(config?.antiMemberPrune !== false)} **Member Pruning Protection**\n` +
                `• ${f(config?.antiRoleCreate !== false)} **Role Creation Tampering**\n` +
                `• ${f(config?.antiRoleDelete !== false)} **Role Deletion Protection & Auto-Recovery**\n` +
                `• ${f(config?.antiRoleUpdate !== false)} **Dangerous Role Updates / Admin Escalation**\n` +
                `• ${f(config?.antiChannelCreate !== false)} **Channel Creation Spam**\n` +
                `• ${f(config?.antiChannelDelete !== false)} **Channel Deletion Protection & Auto-Recovery**\n` +
                `• ${f(config?.antiChannelEdit)} **Channel Updates / Renames**\n` +
                `• ${f(config?.antiWebhook !== false)} **Webhook Creation & Spam Attacks**\n` +
                `• ${f(config?.antiBot !== false)} **Unauthorized Bot Additions (Kick bot & inviter)**\n` +
                `• ${f(config?.antiGuildUpdate)} **Server Vanity / Name / Icon Tampering**\n` +
                `• ${f(config?.antiPermissionEscalation !== false)} **Unauthorized Permission Escalation**\n\n` +
                `*Use \`?antinuke enable\` to activate all filters.*`,
            color: 0x5865F2,
            ephemeral: false
        });
    },

    async handleLogs(ctx) {
        const guild = ctx.guild;
        const config = await AntinukeConfig.findOne({ where: { guildId: guild.id } });
        const recentLogs = await SecurityAuditLog.findAll({
            where: { guildId: guild.id, module: 'ANTINUKE' },
            order: [['createdAt', 'DESC']],
            limit: 6
        });

        const logChannelText = config?.logChannelId ? `<#${config.logChannelId}>` : '*No dedicated log channel set*';
        let incidentText = recentLogs.length > 0
            ? recentLogs.map(l => `• \`${new Date(l.createdAt).toLocaleTimeString()}\` **${l.action}** — ${l.reason || 'Triggered'} (<@${l.executorId}>)`).join('\n')
            : '*No recent security alerts.*';

        return sendSecurityReply(ctx, {
            title: `📜 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Anti-Nuke Logs & Alerts`,
            description:
                `**Configured Log Channel:** ${logChannelText}\n\n` +
                `**Recent Incident History:**\n${incidentText}`,
            color: 0x5865F2,
            ephemeral: false
        });
    },

    async handleWhitelistReset(ctx) {
        const member = ctx.member;
        const guild = ctx.guild;

        const authorized = await isAuthorizedOwner(member, guild);
        if (!authorized) {
            return sendSecurityReply(ctx, {
                title: `${emojis.cross || '❌'} Access Denied`,
                description: 'Only the **Server Owner** or authorized **Extra Owners** can reset the whitelist.',
                color: 0xEF4444,
                ephemeral: true
            });
        }

        const count = await AntinukeWhitelist.destroy({ where: { guildId: guild.id } });
        return sendSecurityReply(ctx, {
            title: `${emojis.success || '✅'} Whitelist Cleared`,
            description: `Anti-Nuke whitelist reset successfully. Removed **${count}** trusted user(s).`,
            color: 0x10B981,
            ephemeral: false
        });
    }
};