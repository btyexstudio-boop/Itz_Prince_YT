// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Anti-Nuke Whitelist Subcommand
const {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    UserSelectMenuBuilder,
    StringSelectMenuBuilder
} = require('discord.js');
const { AntinukeWhitelist, SecurityAuditLog } = require('../../../data/models');
const { isAuthorizedOwner, sendSecurityReply } = require('../../../lib/securityAuth');
const emojis = require('../../../emojis.json');

const EVENTS = AntinukeWhitelist.EVENTS || {
    ban: 'Anti-Ban',
    kick: 'Anti-Kick',
    channel: 'Anti-Channel',
    role: 'Anti-Role',
    webhook: 'Anti-Webhook',
    bot: 'Anti-Bot',
    server: 'Anti-Server',
    prune: 'Anti-Prune'
};

module.exports = {
    name: 'whitelist',
    description: 'Manage whitelisted users for Anti-Nuke',

    async execute(interactionOrMessage, args = []) {
        const member = interactionOrMessage.member;
        const guild = interactionOrMessage.guild;
        const isSlash = interactionOrMessage.isCommand?.();

        if (!guild) return;

        const authorized = await isAuthorizedOwner(member, guild);
        if (!authorized) {
            return sendSecurityReply(interactionOrMessage, {
                title: `${emojis.cross || '❌'} Access Denied`,
                description: 'Only the **Server Owner** or authorized **Extra Owners** can manage the Anti-Nuke whitelist.',
                color: 0xEF4444,
                ephemeral: true
            });
        }

        let action, user;

        if (isSlash) {
            action = interactionOrMessage.options.getString('action');
            user = interactionOrMessage.options.getUser('user');
        } else {
            action = args[0]?.toLowerCase();
            const targetStr = args[1];
            const userId = targetStr?.replace(/[<@!>]/g, '');
            if (userId) {
                try {
                    user = await interactionOrMessage.client.users.fetch(userId);
                } catch (_) {
                    user = null;
                }
            }
        }

        if (action === 'add') {
            if (!user) {
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.warning || '⚠️'} Target Missing`,
                    description: 'Please mention a user or provide a valid user ID to whitelist.\nExample: `?antinuke wl @user`',
                    color: 0xF59E0B,
                    ephemeral: true
                });
            }

            if (user.id === guild.ownerId) {
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.info || 'ℹ️'} Already Immune`,
                    description: 'The **Server Owner** is permanently immune to Anti-Nuke and does not need to be whitelisted.',
                    color: 0x64748B,
                    ephemeral: true
                });
            }

            // Whitelist for all protection events by default for rapid setup
            const allEvents = Object.keys(EVENTS);
            const [record, created] = await AntinukeWhitelist.findOrCreate({
                where: { guildId: guild.id, userId: user.id },
                defaults: {
                    guildId: guild.id,
                    userId: user.id,
                    events: allEvents,
                    addedBy: member.id
                }
            });

            if (!created) {
                await record.update({ events: allEvents, addedBy: member.id });
            }

            try {
                await SecurityAuditLog.create({
                    guildId: guild.id,
                    module: 'ANTINUKE',
                    action: 'WHITELIST_ADD',
                    executorId: member.id,
                    targetId: user.id,
                    reason: 'Added to Anti-Nuke whitelist'
                });
            } catch (_) {}

            return sendSecurityReply(interactionOrMessage, {
                title: `${emojis.shield || '🛡️'} User Whitelisted`,
                description: `${emojis.success || '✅'} <@${user.id}> (\`${user.tag || user.username}\`) has been added to the **Anti-Nuke Whitelist**!\n\n` +
                    `• **Granted Scope:** All Protections (Bans, Kicks, Channels, Roles, Webhooks, Bots)\n` +
                    `• **Authorized By:** <@${member.id}>\n\n` +
                    `*To remove this user anytime, use \`?antinuke unwl @user\`.*`,
                color: 0x10B981,
                ephemeral: false
            });
        }

        if (action === 'remove') {
            if (!user) {
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.warning || '⚠️'} Target Missing`,
                    description: 'Please mention a user or provide a valid user ID to remove from whitelist.\nExample: `?antinuke unwl @user`',
                    color: 0xF59E0B,
                    ephemeral: true
                });
            }

            const existing = await AntinukeWhitelist.findOne({ where: { guildId: guild.id, userId: user.id } });
            if (!existing) {
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.info || 'ℹ️'} Not Whitelisted`,
                    description: `<@${user.id}> is not currently in the Anti-Nuke whitelist.`,
                    color: 0x64748B,
                    ephemeral: true
                });
            }

            await existing.destroy();

            try {
                await SecurityAuditLog.create({
                    guildId: guild.id,
                    module: 'ANTINUKE',
                    action: 'WHITELIST_REMOVE',
                    executorId: member.id,
                    targetId: user.id,
                    reason: 'Removed from Anti-Nuke whitelist'
                });
            } catch (_) {}

            return sendSecurityReply(interactionOrMessage, {
                title: `${emojis.cross || '❌'} Whitelist Removed`,
                description: `${emojis.success || '✅'} <@${user.id}> has been removed from the Anti-Nuke whitelist. They are now subject to all security thresholds.`,
                color: 0xEF4444,
                ephemeral: false
            });
        }

        // List action (or default)
        const whitelistedUsers = await AntinukeWhitelist.findAll({ where: { guildId: guild.id } });

        if (whitelistedUsers.length === 0) {
            return sendSecurityReply(interactionOrMessage, {
                title: `${emojis.shield || '🛡️'} Anti-Nuke Whitelist`,
                description: `No users are currently whitelisted on this server.\n\n*Add a trusted admin using \`?antinuke wl @user\`.*`,
                color: 0x5865F2,
                ephemeral: false
            });
        }

        const lines = whitelistedUsers.map((w, index) => {
            const evCount = Array.isArray(w.events) ? w.events.length : 0;
            return `\`${index + 1}.\` <@${w.userId}> — \`${evCount} filter(s) bypassed\``;
        });

        return sendSecurityReply(interactionOrMessage, {
            title: `${emojis.shield || '🛡️'} Anti-Nuke Whitelisted Users (${whitelistedUsers.length})`,
            description:
                `The following trusted administrators can perform actions without triggering Anti-Nuke thresholds:\n\n` +
                lines.join('\n') +
                `\n\n*Commands:*\n` +
                `• \`?antinuke wl @user\` — Whitelist a user\n` +
                `• \`?antinuke unwl @user\` — Remove a user\n` +
                `• \`?antinuke wlreset\` — Reset all whitelisted users`,
            color: 0x5865F2,
            ephemeral: false
        });
    }
};