// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Anti-Nuke Settings Subcommand
const { AntinukeConfig, AntinukeWhitelist, ExtraOwner } = require('../../../data/models');
const { isAuthorizedOwner, sendSecurityReply } = require('../../../lib/securityAuth');
const emojis = require('../../../emojis.json');

module.exports = {
    name: 'settings',
    description: 'View and edit current Anti-Nuke settings',

    async execute(interactionOrMessage) {
        const member = interactionOrMessage.member;
        const guild = interactionOrMessage.guild;

        if (!guild) return;

        const authorized = await isAuthorizedOwner(member, guild);
        if (!authorized) {
            return sendSecurityReply(interactionOrMessage, {
                title: `${emojis.cross || '❌'} Access Denied`,
                description: 'Only the **Server Owner** or authorized **Extra Owners** can view Anti-Nuke settings.',
                color: 0xEF4444,
                ephemeral: true
            });
        }

        const [config] = await AntinukeConfig.findOrCreate({
            where: { guildId: guild.id },
            defaults: {
                guildId: guild.id,
                enabled: false,
                threshold: 3,
                timeframe: 60,
                punishment: 'stripall'
            }
        });

        const whitelistCount = await AntinukeWhitelist.count({ where: { guildId: guild.id } });
        const extraOwnerCount = await ExtraOwner.count({ where: { guildId: guild.id } });

        const isEnabled = config.enabled;
        const statusEmoji = isEnabled ? (emojis.enabled || '🟢') : (emojis.disabled || '🔴');
        const shieldEmoji = emojis.target || emojis.shield || '🛡️';

        const f = (val) => val ? (emojis.check || '✅') : (emojis.cross || '❌');

        return sendSecurityReply(interactionOrMessage, {
            title: `${shieldEmoji} 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Anti-Nuke Settings`,
            description:
                `**System State:** ${statusEmoji} **${isEnabled ? 'ACTIVE & ENFORCING' : 'DISABLED'}**\n` +
                `**Threshold:** \`${config.threshold || 3} actions\` per \`${config.timeframe || 60} seconds\`\n` +
                `**Punishment:** \`${config.punishment || 'stripall'}\` (Revoke all administrative roles & permissions)\n` +
                `**Log Channel:** ${config.logChannelId ? `<#${config.logChannelId}>` : '*None configured*'}\n` +
                `**Dry-Run Mode:** \`${config.dryRun ? 'ON (Simulation only)' : 'OFF (Real punishment)'}\`\n` +
                `**Trusted Whitelist:** \`${whitelistCount}\` user(s)\n` +
                `**Extra Owners:** \`${extraOwnerCount}\` user(s)\n\n` +
                `**🛡️ Protection Modules Status:**\n` +
                `• ${f(config.antiBan !== false)} Anti-Ban\n` +
                `• ${f(config.antiKick !== false)} Anti-Kick\n` +
                `• ${f(config.antiMemberPrune !== false)} Anti-Prune\n` +
                `• ${f(config.antiRoleCreate !== false)} Anti-Role Create\n` +
                `• ${f(config.antiRoleDelete !== false)} Anti-Role Delete\n` +
                `• ${f(config.antiRoleUpdate !== false)} Anti-Role Dangerous Update\n` +
                `• ${f(config.antiChannelCreate !== false)} Anti-Channel Create\n` +
                `• ${f(config.antiChannelDelete !== false)} Anti-Channel Delete\n` +
                `• ${f(config.antiWebhook !== false)} Anti-Webhook\n` +
                `• ${f(config.antiBot !== false)} Anti-Bot Additions\n` +
                `• ${f(config.antiPermissionEscalation !== false)} Anti-Permission Escalation\n\n` +
                `*Quick Management:*\n` +
                `• \`?antinuke enable\` / \`?antinuke disable\`\n` +
                `• \`?antinuke wl @user\` / \`?antinuke unwl @user\`\n` +
                `• \`?extraowner set @user\` / \`?extraowner view\``,
            color: isEnabled ? 0x10B981 : 0x5865F2,
            ephemeral: false
        });
    }
};