// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Anti-Nuke Setup Wizard
const {
    ActionRowBuilder,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    ButtonBuilder,
    ButtonStyle,
    EmbedBuilder
} = require('discord.js');
const { AntinukeConfig } = require('../../../data/models');
const { isAuthorizedOwner, sendSecurityReply } = require('../../../lib/securityAuth');
const emojis = require('../../../emojis.json');

module.exports = {
    name: 'setup',
    description: 'Setup Anti-Nuke with interactive wizard (𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™)',

    async execute(interactionOrMessage) {
        const member = interactionOrMessage.member;
        const guild = interactionOrMessage.guild;

        if (!guild) return;

        const authorized = await isAuthorizedOwner(member, guild);
        if (!authorized) {
            return sendSecurityReply(interactionOrMessage, {
                title: `${emojis.cross || '❌'} Access Denied`,
                description: 'Only the **Server Owner** or authorized **Extra Owners** can configure Anti-Nuke.',
                color: 0xEF4444,
                ephemeral: true
            });
        }

        const [config] = await AntinukeConfig.findOrCreate({
            where: { guildId: guild.id },
            defaults: {
                guildId: guild.id,
                enabled: true,
                threshold: 3,
                timeframe: 60,
                punishment: 'stripall'
            }
        });

        const embed = new EmbedBuilder()
            .setTitle(`${emojis.shield || '🛡️'} 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Anti-Nuke Setup Wizard`)
            .setColor(0x5865F2)
            .setDescription(
                `Configure your server's Anti-Nuke protection settings below.\n\n` +
                `**Current Status:** \`${config.enabled ? 'ENABLED' : 'DISABLED'}\`\n` +
                `**Punishment:** \`${config.punishment || 'stripall'}\`\n` +
                `**Threshold:** \`${config.threshold || 3} actions\` per \`${config.timeframe || 60}s\`\n\n` +
                `*Quick Actions:*\n` +
                `• Use \`?antinuke enable\` to immediately activate all security modules with optimal defaults.\n` +
                `• Use \`?antinuke wl @user\` to whitelist your trusted administrators.\n` +
                `• Use \`?extraowner set @user\` to delegate ownership control.`
            )
            .setFooter({ text: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ • Step 1 of Wizard' });

        const selectRow = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('antinuke_setup_modules')
                .setPlaceholder('Select modules to toggle')
                .setMinValues(1)
                .setMaxValues(5)
                .addOptions(
                    new StringSelectMenuOptionBuilder()
                        .setLabel('Mass Bans Protection')
                        .setDescription('Ban abusers who mass-ban members')
                        .setValue('antiBan')
                        .setDefault(config.antiBan !== false),
                    new StringSelectMenuOptionBuilder()
                        .setLabel('Mass Kicks Protection')
                        .setDescription('Prevent rogue admins from mass-kicking')
                        .setValue('antiKick')
                        .setDefault(config.antiKick !== false),
                    new StringSelectMenuOptionBuilder()
                        .setLabel('Channel Tampering')
                        .setDescription('Block mass channel deletion and spam')
                        .setValue('antiChannelDelete')
                        .setDefault(config.antiChannelDelete !== false),
                    new StringSelectMenuOptionBuilder()
                        .setLabel('Role Tampering')
                        .setDescription('Block mass role deletion and admin escalation')
                        .setValue('antiRoleDelete')
                        .setDefault(config.antiRoleDelete !== false),
                    new StringSelectMenuOptionBuilder()
                        .setLabel('Bot Protection')
                        .setDescription('Block unauthorized bot additions')
                        .setValue('antiBot')
                        .setDefault(config.antiBot !== false)
                )
        );

        const btnRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('antinuke_enable_quick')
                .setLabel('Enable All Shields')
                .setEmoji(emojis.tick?.match(/\d+/)?.[0] || '✅')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('antinuke_setup_cancel')
                .setLabel('Close')
                .setStyle(ButtonStyle.Secondary)
        );

        const payload = { embeds: [embed], components: [selectRow, btnRow] };
        if (interactionOrMessage.isCommand?.()) {
            return interactionOrMessage.reply(payload);
        }
        return interactionOrMessage.reply(payload);
    }
};