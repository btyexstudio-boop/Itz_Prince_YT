// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Anti-Nuke Enable Subcommand
const { AntinukeConfig, LinkProtectionConfig, AntiSpamConfig, AntiRaidConfig, SecurityAuditLog } = require('../../../data/models');
const { isAuthorizedOwner, sendSecurityReply } = require('../../../lib/securityAuth');
const { takeFullServerSnapshot } = require('../../../gateway/antinuke/antinukeEvents');
const emojis = require('../../../emojis.json');

module.exports = {
    name: 'enable',
    description: 'Enable the Anti-Nuke protection system or specific modules',

    async execute(interactionOrMessage, args = []) {
        const member = interactionOrMessage.member;
        const guild = interactionOrMessage.guild;

        if (!guild) return;

        const authorized = await isAuthorizedOwner(member, guild);
        if (!authorized) {
            return sendSecurityReply(interactionOrMessage, {
                title: `${emojis.cross || '❌'} Access Denied`,
                description: 'Only the **Server Owner** or authorized **Extra Owners** can configure Anti-Nuke.',
                color: 0xEF4444,
                ephemeral: true
            });
        }

        const feature = args[0]?.toLowerCase();

        const [config] = await AntinukeConfig.findOrCreate({
            where: { guildId: guild.id },
            defaults: {
                guildId: guild.id,
                enabled: true,
                antiBan: true,
                antiKick: true,
                antiMemberPrune: true,
                antiRoleCreate: true,
                antiRoleDelete: true,
                antiRoleUpdate: true,
                antiChannelCreate: true,
                antiChannelDelete: true,
                antiChannelEdit: true,
                antiWebhook: true,
                antiBot: true,
                antiGuildUpdate: true,
                antiPermissionEscalation: true,
                threshold: 3,
                timeframe: 60,
                punishment: 'stripall',
                dryRun: false
            }
        });

        // Feature-specific toggles
        if (feature) {
            let updatePayload = {};
            let featureName = '';

            if (['channel', 'channels'].includes(feature)) {
                updatePayload = { antiChannelCreate: true, antiChannelDelete: true, antiChannelEdit: true };
                featureName = 'Channel Protection (Create/Delete/Edit)';
            } else if (['role', 'roles'].includes(feature)) {
                updatePayload = { antiRoleCreate: true, antiRoleDelete: true, antiRoleUpdate: true };
                featureName = 'Role Protection (Create/Delete/Update)';
            } else if (['bot', 'bots'].includes(feature)) {
                updatePayload = { antiBot: true };
                featureName = 'Anti-Bot Additions';
            } else if (['ban', 'bans'].includes(feature)) {
                updatePayload = { antiBan: true };
                featureName = 'Mass Ban Protection';
            } else if (['kick', 'kicks'].includes(feature)) {
                updatePayload = { antiKick: true };
                featureName = 'Mass Kick Protection';
            } else if (['webhook', 'webhooks'].includes(feature)) {
                updatePayload = { antiWebhook: true };
                featureName = 'Webhook Creation Protection';
            } else if (['strict'].includes(feature)) {
                updatePayload = { strict: true };
                featureName = 'Strict Instant Containment Mode';
            } else if (['recovery', 'autorecovery'].includes(feature)) {
                updatePayload = { autoRecovery: true };
                featureName = 'Channel & Role Auto-Recovery';
            } else if (['link', 'links', 'linkprotection'].includes(feature)) {
                const [linkCfg] = await LinkProtectionConfig.findOrCreate({ where: { guildId: guild.id } });
                await linkCfg.update({ enabled: true });
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.shield || '🛡️'} Link Protection Activated`,
                    description: `${emojis.success || '✅'} **Link Protection is now ENABLED!**\n\nOnly Server Owners, Extra Owners, and Administrators are authorized to post links in this server.`,
                    color: 0x10B981
                });
            } else if (['spam', 'antispam'].includes(feature)) {
                const [spamCfg] = await AntiSpamConfig.findOrCreate({ where: { guildId: guild.id } });
                await spamCfg.update({ enabled: true });
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.shield || '🛡️'} Anti-Spam Activated`,
                    description: `${emojis.success || '✅'} **Anti-Spam Module is now ENABLED!**`,
                    color: 0x10B981
                });
            } else if (['raid', 'antiraid'].includes(feature)) {
                const [raidCfg] = await AntiRaidConfig.findOrCreate({ where: { guildId: guild.id } });
                await raidCfg.update({ enabled: true });
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.shield || '🛡️'} Anti-Raid Activated`,
                    description: `${emojis.success || '✅'} **Anti-Raid Module is now ENABLED!**`,
                    color: 0x10B981
                });
            }

            if (Object.keys(updatePayload).length > 0) {
                await config.update({ ...updatePayload, enabled: true });
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.shield || '🛡️'} Module Activated`,
                    description: `${emojis.success || '✅'} **${featureName}** has been successfully **ENABLED**!`,
                    color: 0x10B981
                });
            }
        }

        // Global Enable
        await config.update({
            enabled: true,
            antiBan: true,
            antiKick: true,
            antiMemberPrune: true,
            antiRoleCreate: true,
            antiRoleDelete: true,
            antiRoleUpdate: true,
            antiChannelCreate: true,
            antiChannelDelete: true,
            antiWebhook: true,
            antiBot: true,
            antiPermissionEscalation: true
        });

        try {
            await SecurityAuditLog.create({
                guildId: guild.id,
                module: 'ANTINUKE',
                action: 'ENABLE',
                executorId: member.id,
                targetId: guild.id,
                reason: 'Anti-Nuke system enabled'
            });
        } catch (_) {}

        // Capture full channel and role snapshot immediately
        if (takeFullServerSnapshot) {
            takeFullServerSnapshot(guild).catch(() => {});
        }

        return sendSecurityReply(interactionOrMessage, {
            title: `${emojis.shield || '🛡️'} 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Shield Activated`,
            description: `${emojis.success || '✅'} **Anti-Nuke Protection is now ACTIVE & ENFORCING!**\n\n` +
                `Your server is protected against unauthorized channel/role deletion, rogue bots, mass bans, and nuke attacks.\n\n` +
                `**💡 Modular Controls:**\n` +
                `• \`?antinuke enable channel\` / \`disable channel\`\n` +
                `• \`?antinuke enable role\` / \`disable role\`\n` +
                `• \`?antinuke enable bot\` / \`disable bot\`\n` +
                `• \`?antinuke enable link\` / \`disable link\`\n` +
                `• \`?antinuke enable strict\` / \`disable strict\``,
            color: 0x10B981,
            ephemeral: false
        });
    }
};