// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Anti-Nuke Disable Subcommand
const { AntinukeConfig, LinkProtectionConfig, AntiSpamConfig, AntiRaidConfig, SecurityAuditLog } = require('../../../data/models');
const { isAuthorizedOwner, sendSecurityReply } = require('../../../lib/securityAuth');
const emojis = require('../../../emojis.json');

module.exports = {
    name: 'disable',
    description: 'Disable the Anti-Nuke protection system or specific modules',

    async execute(interactionOrMessage, args = []) {
        const member = interactionOrMessage.member;
        const guild = interactionOrMessage.guild;

        if (!guild) return;

        const authorized = await isAuthorizedOwner(member, guild);
        if (!authorized) {
            return sendSecurityReply(interactionOrMessage, {
                title: `${emojis.cross || '❌'} Access Denied`,
                description: 'Only the **Server Owner** or authorized **Extra Owners** can configure Anti-Nuke.',
                color: 0xEF4444,
                ephemeral: true
            });
        }

        const feature = args[0]?.toLowerCase();

        const config = await AntinukeConfig.findOne({ where: { guildId: guild.id } });

        // Feature-specific disable toggles
        if (feature && config) {
            let updatePayload = {};
            let featureName = '';

            if (['channel', 'channels'].includes(feature)) {
                updatePayload = { antiChannelCreate: false, antiChannelDelete: false, antiChannelEdit: false };
                featureName = 'Channel Protection';
            } else if (['role', 'roles'].includes(feature)) {
                updatePayload = { antiRoleCreate: false, antiRoleDelete: false, antiRoleUpdate: false };
                featureName = 'Role Protection';
            } else if (['bot', 'bots'].includes(feature)) {
                updatePayload = { antiBot: false };
                featureName = 'Anti-Bot Additions';
            } else if (['ban', 'bans'].includes(feature)) {
                updatePayload = { antiBan: false };
                featureName = 'Mass Ban Protection';
            } else if (['kick', 'kicks'].includes(feature)) {
                updatePayload = { antiKick: false };
                featureName = 'Mass Kick Protection';
            } else if (['webhook', 'webhooks'].includes(feature)) {
                updatePayload = { antiWebhook: false };
                featureName = 'Webhook Creation Protection';
            } else if (['strict'].includes(feature)) {
                updatePayload = { strict: false };
                featureName = 'Strict Instant Containment Mode';
            } else if (['recovery', 'autorecovery'].includes(feature)) {
                updatePayload = { autoRecovery: false };
                featureName = 'Channel & Role Auto-Recovery';
            } else if (['link', 'links', 'linkprotection'].includes(feature)) {
                const linkCfg = await LinkProtectionConfig.findOne({ where: { guildId: guild.id } });
                if (linkCfg) await linkCfg.update({ enabled: false });
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.warning || '⚠️'} Link Protection Disabled`,
                    description: `**Link Protection module is now DISABLED.**`,
                    color: 0xEF4444
                });
            } else if (['spam', 'antispam'].includes(feature)) {
                const spamCfg = await AntiSpamConfig.findOne({ where: { guildId: guild.id } });
                if (spamCfg) await spamCfg.update({ enabled: false });
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.warning || '⚠️'} Anti-Spam Disabled`,
                    description: `**Anti-Spam module is now DISABLED.**`,
                    color: 0xEF4444
                });
            } else if (['raid', 'antiraid'].includes(feature)) {
                const raidCfg = await AntiRaidConfig.findOne({ where: { guildId: guild.id } });
                if (raidCfg) await raidCfg.update({ enabled: false });
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.warning || '⚠️'} Anti-Raid Disabled`,
                    description: `**Anti-Raid module is now DISABLED.**`,
                    color: 0xEF4444
                });
            }

            if (Object.keys(updatePayload).length > 0) {
                await config.update(updatePayload);
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.warning || '⚠️'} Module Deactivated`,
                    description: `${emojis.cross || '❌'} **${featureName}** has been **DISABLED**!`,
                    color: 0xEF4444
                });
            }
        }

        if (!config || !config.enabled) {
            return sendSecurityReply(interactionOrMessage, {
                title: `${emojis.info || 'ℹ️'} Anti-Nuke Already Disabled`,
                description: 'Anti-Nuke protection is not currently active on this server.\nUse `?antinuke enable` to turn it on.',
                color: 0x64748B,
                ephemeral: true
            });
        }

        await config.update({ enabled: false });

        try {
            await SecurityAuditLog.create({
                guildId: guild.id,
                module: 'ANTINUKE',
                action: 'DISABLE',
                executorId: member.id,
                targetId: guild.id,
                reason: 'Anti-Nuke system disabled'
            });
        } catch (_) {}

        return sendSecurityReply(interactionOrMessage, {
            title: `${emojis.warning || '⚠️'} 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Shield Deactivated`,
            description: `${emojis.cross || '❌'} **Anti-Nuke Protection has been DISABLED.**\n\n` +
                `*To re-enable security anytime, type \`?antinuke enable\`.*`,
            color: 0xEF4444,
            ephemeral: false
        });
    }
};