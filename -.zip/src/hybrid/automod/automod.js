// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — AutoMod Command
const {
    SlashCommandBuilder
} = require('discord.js');
const { AutomodConfig, AutomodWhitelist, SecurityAuditLog } = require('../../data/models');
const { isAuthorizedOwner, sendSecurityReply } = require('../../lib/securityAuth');
const emojis = require('../../emojis.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('automod')
        .setDescription('Configure automatic message moderation (𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™)')
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable automod'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable automod'))
        .addSubcommand(sub => sub.setName('status').setDescription('View automod status'))
        .addSubcommand(sub => sub.setName('settings').setDescription('View and edit automod settings'))
        .addSubcommand(sub => sub.setName('rules').setDescription('List active automod protection rules'))
        .addSubcommand(sub => sub.setName('logs').setDescription('View automod logs and recent violations'))
        .addSubcommand(sub =>
            sub.setName('whitelist')
                .setDescription('Manage whitelisted users, roles, and channels')
                .addStringOption(opt =>
                    opt.setName('action')
                        .setDescription('Action')
                        .addChoices(
                            { name: 'add', value: 'add' },
                            { name: 'remove', value: 'remove' },
                            { name: 'list', value: 'list' }
                        )
                )
        )
        .addSubcommand(sub =>
            sub.setName('blacklist')
                .setDescription('Manage bad words blacklist')
                .addStringOption(opt =>
                    opt.setName('action')
                        .setDescription('add, remove, or list')
                        .addChoices(
                            { name: 'add', value: 'add' },
                            { name: 'remove', value: 'remove' },
                            { name: 'list', value: 'list' }
                        )
                )
                .addStringOption(opt => opt.setName('word').setDescription('Word to add or remove'))
        )
        .addSubcommand(sub => sub.setName('setup').setDescription('Run automod setup wizard'))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset automod to defaults')),

    name: 'automod',
    aliases: ['am', 'automoderation'],
    description: 'Configure automatic message moderation',

    async execute(interactionOrMessage, args = []) {
        const isSlash = interactionOrMessage.isCommand?.();
        let subcommand;

        if (isSlash) {
            subcommand = interactionOrMessage.options.getSubcommand();
        } else {
            subcommand = args[0]?.toLowerCase();
            args = args.slice(1);
        }

        if (subcommand === 'status' || !subcommand) {
            return this.handleStatus(interactionOrMessage);
        }
        if (subcommand === 'rules') {
            return this.handleRules(interactionOrMessage);
        }
        if (subcommand === 'logs') {
            return this.handleLogs(interactionOrMessage);
        }
        if (subcommand === 'blacklist') {
            return this.handleBlacklist(interactionOrMessage, args);
        }
        if (subcommand === 'whitelist') {
            const whitelistCmd = require('./subcommands/whitelist');
            return whitelistCmd.execute(interactionOrMessage, args);
        }

        if (['setup', 'settings', 'enable', 'disable', 'reset'].includes(subcommand)) {
            const subcommandFile = require(`./subcommands/${subcommand}`);
            return subcommandFile.execute(interactionOrMessage, args);
        }

        return this.handleStatus(interactionOrMessage);
    },

    async handleStatus(ctx) {
        const guild = ctx.guild;
        const [config] = await AutomodConfig.findOrCreate({
            where: { guildId: guild.id },
            defaults: {
                guildId: guild.id,
                enabled: false,
                punishment: 'delete',
                spamThreshold: 5,
                spamInterval: 5
            }
        });
        const whitelistCount = await AutomodWhitelist.count({ where: { guildId: guild.id } });

        const isEnabled = config?.enabled || false;
        const statusEmoji = isEnabled ? (emojis.enabled || '🟢') : (emojis.disabled || '🔴');

        let badWordsCount = 0;
        try {
            badWordsCount = JSON.parse(config?.badWords || '[]').length;
        } catch {
            badWordsCount = 0;
        }

        return sendSecurityReply(ctx, {
            title: `🤖 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — AutoMod Status`,
            description:
                `**System State:** ${statusEmoji} **${isEnabled ? 'ACTIVE & FILTERING' : 'DISABLED'}**\n` +
                `**Default Action:** \`${config?.punishment || 'delete'}\`\n` +
                `**Mute Duration:** \`${config?.muteDuration || 300}s\`\n` +
                `**Log Channel:** ${config?.logChannelId ? `<#${config.logChannelId}>` : '*None configured*'}\n` +
                `**Banned Words Filter:** \`${badWordsCount}\` word(s) registered\n` +
                `**Exemptions (Whitelist):** \`${whitelistCount}\` rule(s)\n\n` +
                `*Quick Commands:*\n` +
                `• \`?automod enable\` — Turn on AutoMod\n` +
                `• \`?automod disable\` — Turn off AutoMod\n` +
                `• \`?automod rules\` — View detailed filter rules\n` +
                `• \`?automod blacklist add <word>\` — Add forbidden word`,
            color: isEnabled ? 0x10B981 : 0x5865F2,
            ephemeral: false
        });
    },

    async handleRules(ctx) {
        const guild = ctx.guild;
        const [config] = await AutomodConfig.findOrCreate({
            where: { guildId: guild.id },
            defaults: { guildId: guild.id }
        });

        const f = (val) => val ? (emojis.check || '✅') : (emojis.cross || '❌');

        return sendSecurityReply(ctx, {
            title: `📜 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — AutoMod Rules & Thresholds`,
            description:
                `**Active Filter Configuration:**\n` +
                `• ${f(config.antiSpam !== false)} **Anti-Spam:** Max \`${config.spamThreshold || 5}\` msgs / \`${config.spamInterval || 5}s\`\n` +
                `• ${f(config.antiInvite !== false)} **Anti-Invite:** Blocks Discord invite links\n` +
                `• ${f(config.antiLink)} **Anti-Link:** Blocks external HTTP(S) links\n` +
                `• ${f(config.antiMassMention !== false)} **Anti-Mass-Mention:** Max \`${config.mentionLimit || 5}\` mentions\n` +
                `• ${f(config.antiCaps)} **Anti-Caps:** Max \`${config.capsPercentage || 70}%\` uppercase (min \`${config.capsMinLength || 10}\` chars)\n` +
                `• ${f(config.antiEmojiSpam)} **Anti-Emoji-Spam:** Max \`${config.emojiLimit || 6}\` emojis\n` +
                `• ${f(config.antiAttachmentSpam)} **Anti-Attachment-Spam:** Max \`${config.attachmentLimit || 3}\` files\n` +
                `• ${f(config.antiZalgoSpam)} **Anti-Zalgo-Spam:** Blocks corrupted zalgo fonts\n` +
                `• ${f(config.antiSimilarSpam)} **Similar-Message Spam:** Blocks repetitive duplicate messages\n` +
                `• ${f(config.antiCharacterSpam)} **Character-Limit Spam:** Max \`${config.characterLimit || 1000}\` chars\n` +
                `• ${f(config.antiNewlineSpam)} **Newline Spam:** Max \`${config.newlineLimit || 8}\` lines\n` +
                `• ${f(config.antiNsfwLink)} **Anti-NSFW-Link:** Blocks flagged adult / malicious URLs\n` +
                `• ${f(config.antiBadWords)} **Blacklisted Words:** Auto-deletes configured words`,
            color: 0x5865F2,
            ephemeral: false
        });
    },

    async handleLogs(ctx) {
        const guild = ctx.guild;
        const config = await AutomodConfig.findOne({ where: { guildId: guild.id } });
        const recentLogs = await SecurityAuditLog.findAll({
            where: { guildId: guild.id, module: 'AUTOMOD' },
            order: [['createdAt', 'DESC']],
            limit: 6
        });

        const logChannelText = config?.logChannelId ? `<#${config.logChannelId}>` : '*No dedicated log channel set*';
        let incidentText = recentLogs.length > 0
            ? recentLogs.map(l => `• \`${new Date(l.createdAt).toLocaleTimeString()}\` **${l.action}** — ${l.reason || 'Filtered'} (<@${l.executorId}>)`).join('\n')
            : '*No recent AutoMod violations.*';

        return sendSecurityReply(ctx, {
            title: `📜 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — AutoMod Incident Logs`,
            description:
                `**Log Channel:** ${logChannelText}\n\n` +
                `**Recent Violations:**\n${incidentText}`,
            color: 0x5865F2,
            ephemeral: false
        });
    },

    async handleBlacklist(ctx, args) {
        const guild = ctx.guild;
        const isSlash = ctx.isCommand?.();
        const action = (isSlash ? ctx.options.getString('action') : args[0])?.toLowerCase();
        const word = isSlash ? ctx.options.getString('word') : args.slice(1).join(' ').trim().toLowerCase();

        let [config] = await AutomodConfig.findOrCreate({
            where: { guildId: guild.id },
            defaults: { guildId: guild.id }
        });

        let badWords = [];
        try {
            badWords = JSON.parse(config.badWords || '[]');
        } catch {
            badWords = [];
        }

        if (action === 'add') {
            if (!word) {
                return sendSecurityReply(ctx, {
                    title: `${emojis.warning || '⚠️'} Word Missing`,
                    description: 'Specify the word to blacklist: `?automod blacklist add <word>`',
                    color: 0xF59E0B,
                    ephemeral: true
                });
            }
            if (badWords.includes(word)) {
                return sendSecurityReply(ctx, {
                    title: `${emojis.info || 'ℹ️'} Already Added`,
                    description: `\`${word}\` is already in the blacklist.`,
                    color: 0x64748B,
                    ephemeral: true
                });
            }
            badWords.push(word);
            config.badWords = JSON.stringify(badWords);
            config.antiBadWords = true;
            await config.save();
            return sendSecurityReply(ctx, {
                title: `${emojis.success || '✅'} Word Blacklisted`,
                description: `Added \`${word}\` to the blacklist and enabled word filtering.`,
                color: 0x10B981,
                ephemeral: false
            });
        }

        if (action === 'remove') {
            if (!word) {
                return sendSecurityReply(ctx, {
                    title: `${emojis.warning || '⚠️'} Word Missing`,
                    description: 'Specify the word to remove: `?automod blacklist remove <word>`',
                    color: 0xF59E0B,
                    ephemeral: true
                });
            }
            const idx = badWords.indexOf(word);
            if (idx === -1) {
                return sendSecurityReply(ctx, {
                    title: `${emojis.cross || '❌'} Word Not Found`,
                    description: `\`${word}\` was not found in the blacklist.`,
                    color: 0xEF4444,
                    ephemeral: true
                });
            }
            badWords.splice(idx, 1);
            config.badWords = JSON.stringify(badWords);
            await config.save();
            return sendSecurityReply(ctx, {
                title: `${emojis.success || '✅'} Word Removed`,
                description: `Removed \`${word}\` from the blacklist.`,
                color: 0x10B981,
                ephemeral: false
            });
        }

        // List
        const listText = badWords.length > 0
            ? badWords.map((w, i) => `\`${i + 1}.\` ||${w}||`).join(', ')
            : '*No words currently blacklisted.*';

        return sendSecurityReply(ctx, {
            title: `🚫 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Blacklisted Words (${badWords.length})`,
            description:
                `${listText}\n\n` +
                `*Commands:*\n` +
                `• \`?automod blacklist add <word>\`\n` +
                `• \`?automod blacklist remove <word>\``,
            color: 0x5865F2,
            ephemeral: false
        });
    }
};