// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — AutoMod Disable Subcommand
const { PermissionFlagsBits } = require('discord.js');
const { AutomodConfig, SecurityAuditLog } = require('../../../data/models');
const { isAuthorizedOwner, sendSecurityReply } = require('../../../lib/securityAuth');
const emojis = require('../../../emojis.json');

module.exports = {
    name: 'disable',
    description: 'Disable the AutoMod system (𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™)',

    async execute(interactionOrMessage) {
        const member = interactionOrMessage.member;
        const guild = interactionOrMessage.guild;

        if (!guild) return;

        const isOwner = await isAuthorizedOwner(member, guild);
        const hasPerms = member.permissions?.has(PermissionFlagsBits.ManageGuild) ||
                         member.permissions?.has(PermissionFlagsBits.Administrator);

        if (!isOwner && !hasPerms) {
            return sendSecurityReply(interactionOrMessage, {
                title: `${emojis.cross || '❌'} Access Denied`,
                description: 'You need **Manage Server** or **Administrator** permissions to disable AutoMod.',
                color: 0xEF4444,
                ephemeral: true
            });
        }

        const config = await AutomodConfig.findOne({ where: { guildId: guild.id } });

        if (!config || !config.enabled) {
            return sendSecurityReply(interactionOrMessage, {
                title: `${emojis.info || 'ℹ️'} AutoMod Already Disabled`,
                description: 'AutoMod is not currently active on this server.\nUse `?automod enable` to turn it on.',
                color: 0x64748B,
                ephemeral: true
            });
        }

        await config.update({ enabled: false });

        try {
            await SecurityAuditLog.create({
                guildId: guild.id,
                module: 'AUTOMOD',
                action: 'DISABLE',
                executorId: member.id,
                targetId: guild.id,
                reason: 'AutoMod system disabled via command'
            });
        } catch (_) {}

        return sendSecurityReply(interactionOrMessage, {
            title: `${emojis.warning || '⚠️'} AutoMod Disabled`,
            description: `${emojis.cross || '❌'} **AutoMod has been disabled.** Messages will no longer be automatically filtered.`,
            color: 0xEF4444,
            ephemeral: false
        });
    }
};