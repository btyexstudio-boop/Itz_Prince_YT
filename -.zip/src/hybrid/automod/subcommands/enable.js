// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — AutoMod Enable Subcommand
const { PermissionFlagsBits } = require('discord.js');
const { AutomodConfig, SecurityAuditLog } = require('../../../data/models');
const { isAuthorizedOwner, sendSecurityReply } = require('../../../lib/securityAuth');
const emojis = require('../../../emojis.json');

module.exports = {
    name: 'enable',
    description: 'Enable the AutoMod protection system (𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™)',

    async execute(interactionOrMessage) {
        const member = interactionOrMessage.member;
        const guild = interactionOrMessage.guild;

        if (!guild) return;

        const isOwner = await isAuthorizedOwner(member, guild);
        const hasPerms = member.permissions?.has(PermissionFlagsBits.ManageGuild) ||
                         member.permissions?.has(PermissionFlagsBits.Administrator);

        if (!isOwner && !hasPerms) {
            return sendSecurityReply(interactionOrMessage, {
                title: `${emojis.cross || '❌'} Access Denied`,
                description: 'You need **Manage Server** or **Administrator** permissions to configure AutoMod.',
                color: 0xEF4444,
                ephemeral: true
            });
        }

        const [config, created] = await AutomodConfig.findOrCreate({
            where: { guildId: guild.id },
            defaults: {
                guildId: guild.id,
                enabled: true,
                antiSpam: true,
                antiLink: true,
                antiInvite: true,
                antiBadWords: true,
                antiMassMention: true,
                antiCaps: true,
                antiEmojiSpam: true,
                antiAttachmentSpam: true,
                antiZalgoSpam: true,
                antiSimilarSpam: true,
                antiCharacterSpam: true,
                antiNewlineSpam: true,
                antiNsfwLink: true,
                punishment: 'delete',
                spamThreshold: 5,
                spamInterval: 5,
                mentionLimit: 5,
                capsPercentage: 70
            }
        });

        if (!created && config.enabled) {
            return sendSecurityReply(interactionOrMessage, {
                title: `🤖 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — AutoMod Status`,
                description: `${emojis.success || '✅'} **AutoMod is already active and moderating chat!**\n\n` +
                    `• **Default Action:** \`${config.punishment || 'delete'}\`\n` +
                    `• **Spam Threshold:** \`${config.spamThreshold || 5}\` messages / \`${config.spamInterval || 5}s\`\n` +
                    `• **Mention Limit:** \`${config.mentionLimit || 5}\` user mentions\n\n` +
                    `*Use \`?automod rules\` to inspect active filters or \`?automod settings\` to adjust thresholds.*`,
                color: 0x10B981,
                ephemeral: true
            });
        }

        if (!created) {
            await config.update({ enabled: true });
        }

        try {
            await SecurityAuditLog.create({
                guildId: guild.id,
                module: 'AUTOMOD',
                action: 'ENABLE',
                executorId: member.id,
                targetId: guild.id,
                reason: 'AutoMod system enabled via command'
            });
        } catch (_) {}

        return sendSecurityReply(interactionOrMessage, {
            title: `🤖 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — AutoMod Activated`,
            description: `${emojis.success || '✅'} **AutoMod is now ACTIVE & GUARDING CHANNELS!**\n\n` +
                `All incoming messages are now actively filtered against malicious and abusive content.\n\n` +
                `**🛡️ Active AutoMod Filters:**\n` +
                `• ${emojis.tick || '✅'} Anti-Spam (Rate limiting messages)\n` +
                `• ${emojis.tick || '✅'} Anti-Invite (Discord invite link protection)\n` +
                `• ${emojis.tick || '✅'} Anti-Link & Adult/Malicious URLs\n` +
                `• ${emojis.tick || '✅'} Anti-Mass-Mention (Ghost ping protection)\n` +
                `• ${emojis.tick || '✅'} Anti-Emoji & Attachment Floods\n` +
                `• ${emojis.tick || '✅'} Anti-Zalgo & Glitched Fonts\n` +
                `• ${emojis.tick || '✅'} Duplicate / Similar Message Spam\n` +
                `• ${emojis.tick || '✅'} Character & Wall-of-Newlines Spam\n\n` +
                `*Manage:*\n` +
                `• \`?automod rules\` — View detailed rules\n` +
                `• \`?automod whitelist add channel #chat\` — Whitelist a channel\n` +
                `• \`?automod blacklist add word\` — Filter specific words`,
            color: 0x10B981,
            ephemeral: false
        });
    }
};