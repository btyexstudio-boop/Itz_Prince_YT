// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Extra Owner Management
const {
    SlashCommandBuilder
} = require('discord.js');
const { ExtraOwner, SecurityAuditLog } = require('../../data/models');
const { getGuildOwnerId, isAuthorizedOwner, sendSecurityReply } = require('../../lib/securityAuth');
const config = require('../../config');
const emojis = require('../../emojis.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('extraowner')
        .setDescription('Manage trusted Extra Owners for server security (𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™)')
        .addSubcommand(sub =>
            sub.setName('set')
                .setDescription('Assign an Extra Owner')
                .addUserOption(opt => opt.setName('user').setDescription('User to add as Extra Owner').setRequired(true))
        )
        .addSubcommand(sub => sub.setName('view').setDescription('View current Extra Owners'))
        .addSubcommand(sub => sub.setName('reset').setDescription('Clear all Extra Owners'))
        .addSubcommand(sub => sub.setName('clear').setDescription('Clear all Extra Owners')),

    name: 'extraowner',
    aliases: ['eo', 'extraowners'],
    description: 'Manage trusted Extra Owners for server security',

    async execute(interactionOrMessage, args = []) {
        const isSlash = interactionOrMessage.isCommand?.();
        const guild = interactionOrMessage.guild;
        const member = interactionOrMessage.member;

        if (!guild) return;

        let subcommand;
        let targetUser;

        if (isSlash) {
            subcommand = interactionOrMessage.options.getSubcommand();
            targetUser = interactionOrMessage.options.getUser('user');
        } else {
            subcommand = args[0]?.toLowerCase();
            const userMentionOrId = args[1]?.replace(/[<@!>]/g, '');
            if (userMentionOrId) {
                try {
                    targetUser = await interactionOrMessage.client.users.fetch(userMentionOrId);
                } catch {
                    targetUser = null;
                }
            }
        }

        const realOwnerId = await getGuildOwnerId(guild);
        const isServerOwner = (realOwnerId && member.id === String(realOwnerId)) ||
                              (member.id === String(config.OWNER_ID));

        if (subcommand === 'set') {
            if (!isServerOwner) {
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.cross || '❌'} Access Denied`,
                    description: `Only the **Server Owner** (<@${realOwnerId || 'Server Owner'}>) can assign Extra Owners.`,
                    color: 0xEF4444,
                    ephemeral: true
                });
            }

            if (!targetUser) {
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.warning || '⚠️'} Target Required`,
                    description: 'Please mention a valid user to assign as Extra Owner.\nUsage: `?extraowner set @user`',
                    color: 0xF59E0B,
                    ephemeral: true
                });
            }

            if (realOwnerId && targetUser.id === String(realOwnerId)) {
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.info || 'ℹ️'} Already Owner`,
                    description: 'The Server Owner already holds supreme authority.',
                    color: 0x64748B,
                    ephemeral: true
                });
            }

            if (targetUser.bot) {
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.cross || '❌'} Invalid Target`,
                    description: 'Bots cannot be designated as Extra Owners.',
                    color: 0xEF4444,
                    ephemeral: true
                });
            }

            const currentCount = await ExtraOwner.count({ where: { guildId: guild.id } });
            if (currentCount >= 5) {
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.warning || '⚠️'} Limit Reached`,
                    description: 'Maximum limit of 5 Extra Owners reached for this server. Use `?extraowner reset` to clear.',
                    color: 0xF59E0B,
                    ephemeral: true
                });
            }

            await ExtraOwner.findOrCreate({
                where: { guildId: guild.id, userId: targetUser.id },
                defaults: {
                    guildId: guild.id,
                    userId: targetUser.id,
                    addedBy: member.id
                }
            });

            try {
                await SecurityAuditLog.create({
                    guildId: guild.id,
                    module: 'EXTRAOWNER',
                    action: 'SET',
                    executorId: member.id,
                    targetId: targetUser.id,
                    reason: 'Granted Extra Owner privileges'
                });
            } catch (_) {}

            return sendSecurityReply(interactionOrMessage, {
                title: `${emojis.crown || '👑'} Extra Owner Assigned`,
                description: `${emojis.success || '✅'} Successfully appointed <@${targetUser.id}> (\`${targetUser.tag || targetUser.username}\`) as an **Extra Owner**!\n\n` +
                    `• They now have authorization to manage Anti-Nuke and AutoMod settings.\n` +
                    `• Authorized by Server Owner <@${member.id}>.`,
                color: 0x10B981,
                ephemeral: false
            });
        }

        if (subcommand === 'reset' || subcommand === 'clear') {
            if (!isServerOwner) {
                return sendSecurityReply(interactionOrMessage, {
                    title: `${emojis.cross || '❌'} Access Denied`,
                    description: 'Only the **Server Owner** can clear Extra Owners.',
                    color: 0xEF4444,
                    ephemeral: true
                });
            }

            const removed = await ExtraOwner.destroy({ where: { guildId: guild.id } });

            try {
                await SecurityAuditLog.create({
                    guildId: guild.id,
                    module: 'EXTRAOWNER',
                    action: 'RESET',
                    executorId: member.id,
                    reason: 'Cleared all Extra Owners'
                });
            } catch (_) {}

            return sendSecurityReply(interactionOrMessage, {
                title: `${emojis.success || '✅'} Extra Owners Cleared`,
                description: `Successfully removed **${removed}** Extra Owner(s) from this server.`,
                color: 0x10B981,
                ephemeral: false
            });
        }

        // View / Default
        const extraOwners = await ExtraOwner.findAll({ where: { guildId: guild.id } });

        if (extraOwners.length === 0) {
            return sendSecurityReply(interactionOrMessage, {
                title: `${emojis.crown || '👑'} 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Extra Owners`,
                description: `No Extra Owners are assigned to this server.\n\n*Server Owner can assign up to 5 Extra Owners using \`?extraowner set @user\`.*`,
                color: 0x5865F2,
                ephemeral: false
            });
        }

        const lines = extraOwners.map((eo, idx) => `\`${idx + 1}.\` <@${eo.userId}> (\`${eo.userId}\`) — Added by <@${eo.addedBy}>`);

        return sendSecurityReply(interactionOrMessage, {
            title: `${emojis.crown || '👑'} Extra Owners (${extraOwners.length}/5)`,
            description:
                `The following users have secondary owner permissions:\n\n` +
                lines.join('\n') +
                `\n\n*Commands:*\n` +
                `• \`?extraowner set @user\` — Add an Extra Owner\n` +
                `• \`?extraowner reset\` — Remove all Extra Owners`,
            color: 0x5865F2,
            ephemeral: false
        });
    }
};
