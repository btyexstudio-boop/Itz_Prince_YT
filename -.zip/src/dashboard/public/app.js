// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Single Page Application (SPA) Controller

let state = {
  currentPage: 'landing',
  currentGuildId: '123456789012345678',
  user: null,
  botStatus: null,
  guilds: [],
  currentGuild: null,
  antinuke: null,
  automod: null,
  logging: null,
  modlogs: [],
  subscription: null,
  plans: null,
  auditLogs: [],
  devCodes: []
};

// ==========================================
// API Helpers
// ==========================================
async function apiGet(endpoint) {
  try {
    const res = await fetch(endpoint);
    return await res.json();
  } catch (err) {
    console.error(`API GET ${endpoint} error:`, err);
    return null;
  }
}

async function apiPost(endpoint, body = {}) {
  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    return await res.json();
  } catch (err) {
    console.error(`API POST ${endpoint} error:`, err);
    return { success: false, error: err.message };
  }
}

async function apiDelete(endpoint) {
  try {
    const res = await fetch(endpoint, { method: 'DELETE' });
    return await res.json();
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ==========================================
// Initialization & Navigation
// ==========================================
async function initApp() {
  // Fetch auth & bot status
  const [authData, statusData] = await Promise.all([
    apiGet('/api/auth/me'),
    apiGet('/api/status')
  ]);

  state.user = authData?.user || null;
  state.botStatus = statusData || null;

  renderAuthHeader();

  // Load initial page from URL hash or default to landing
  const initialPage = window.location.hash.replace('#', '') || 'landing';
  navigate(initialPage);
}

function navigate(page, guildId = null) {
  state.currentPage = page;
  if (guildId) state.currentGuildId = guildId;
  window.location.hash = page;

  // Update navbar active state
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.classList.remove('text-sky-400', 'bg-[#141B28]');
  });

  const content = document.getElementById('app-content');
  content.innerHTML = '<div class="flex items-center justify-center py-24"><div class="w-8 h-8 border-2 border-sky-500 border-t-transparent rounded-full animate-spin"></div></div>';

  renderPage();
}

function renderAuthHeader() {
  const container = document.getElementById('auth-header-section');
  if (!container) return;

  if (state.user) {
    container.innerHTML = `
      <div class="flex items-center space-x-3 bg-[#0D111A] border border-[#1B2433] rounded-lg px-2.5 py-1.5">
        <div class="w-7 h-7 rounded-full bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-xs font-bold text-white uppercase">
          ${(state.user.username || 'U')[0]}
        </div>
        <div class="hidden sm:block text-left">
          <p class="text-xs font-semibold text-white leading-none">${state.user.username}</p>
          <p class="text-[10px] text-sky-400 font-mono mt-0.5">${state.user.isDev ? 'Developer' : 'Admin'}</p>
        </div>
      </div>
      <button onclick="navigate('account')" class="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-[#141B28] transition" title="Account Settings">
        <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
      </button>
    `;
  } else {
    container.innerHTML = `
      <button onclick="navigate('login')" class="px-3 py-1.5 text-xs font-semibold rounded-lg bg-sky-600 hover:bg-sky-500 text-white transition flex items-center space-x-1.5 shadow-md shadow-sky-600/20">
        <span>Login with Discord</span>
      </button>
    `;
  }
}

// ==========================================
// Page Router
// ==========================================
async function renderPage() {
  const content = document.getElementById('app-content');
  const page = state.currentPage;

  switch (page) {
    case 'landing':
      renderLandingPage(content);
      break;
    case 'login':
      renderLoginPage(content);
      break;
    case 'dashboard':
      await renderDashboardOverview(content);
      break;
    case 'servers':
      await renderServerSelection(content);
      break;
    case 'server-overview':
      await renderServerOverview(content);
      break;
    case 'antinuke':
      await renderAntinukeConfig(content);
      break;
    case 'automod':
      await renderAutomodConfig(content);
      break;
    case 'logging':
      await renderLoggingConfig(content);
      break;
    case 'modlogs':
      await renderModlogs(content);
      break;
    case 'whitelist':
      await renderWhitelistManagement(content);
      break;
    case 'plans':
      await renderPlansPage(content);
      break;
    case 'subscription':
      await renderSubscriptionPage(content);
      break;
    case 'redeem':
      renderRedeemPage(content);
      break;
    case 'account':
      renderAccountPage(content);
      break;
    case 'admin':
      await renderAdminPage(content);
      break;
    case 'simulator':
      renderThreatSimulator(content);
      break;
    default:
      renderErrorPage(content, '404 — Page Not Found', 'The requested security view does not exist.');
      break;
  }
}

// ==========================================
// 1. Landing Page
// ==========================================
function renderLandingPage(content) {
  content.innerHTML = `
    <div class="py-12 space-y-16">
      <!-- Hero Section -->
      <div class="text-center max-w-3xl mx-auto space-y-6">
        <div class="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-sky-950/60 border border-sky-800/60 text-sky-400 text-xs font-semibold">
          <span class="w-2 h-2 rounded-full bg-sky-400 animate-ping"></span>
          <span>Next-Generation Discord Security Architecture</span>
        </div>
        <h1 class="text-4xl sm:text-6xl font-extrabold tracking-tight text-white leading-tight">
          Uncompromised Security for <span class="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-indigo-400">Your Discord Server</span>
        </h1>
        <p class="text-base sm:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
          𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ delivers millisecond Anti-Nuke defense, granular AutoMod filters, full audit trails, and unified web configuration.
        </p>
        <div class="flex flex-wrap items-center justify-center gap-4 pt-2">
          <button onclick="navigate('dashboard')" class="px-6 py-3 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-semibold shadow-lg shadow-sky-500/20 transition flex items-center space-x-2">
            <span>Open Dashboard</span>
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
          </button>
          <button onclick="navigate('simulator')" class="px-6 py-3 rounded-xl bg-[#0D111A] hover:bg-[#141B28] text-slate-300 font-semibold border border-[#1B2433] transition flex items-center space-x-2">
            <span>Launch Threat Simulator</span>
          </button>
          <button onclick="navigate('plans')" class="px-6 py-3 rounded-xl bg-transparent hover:bg-slate-900 text-sky-400 font-semibold transition">
            <span>View Subscription Plans</span>
          </button>
        </div>
      </div>

      <!-- Feature Grid -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-3 hover:border-sky-500/40 transition">
          <div class="w-12 h-12 rounded-xl bg-sky-950/80 border border-sky-800/80 flex items-center justify-center text-sky-400">
            <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
          </div>
          <h3 class="text-lg font-bold text-white">Military-Grade Anti-Nuke</h3>
          <p class="text-sm text-slate-400 leading-relaxed">
            Automatic containment against mass bans, unauthorized bot additions, channel deletions, and role escalation with rollback guidance.
          </p>
        </div>

        <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-3 hover:border-sky-500/40 transition">
          <div class="w-12 h-12 rounded-xl bg-indigo-950/80 border border-indigo-800/80 flex items-center justify-center text-indigo-400">
            <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
          </div>
          <h3 class="text-lg font-bold text-white">Advanced AutoMod Engine</h3>
          <p class="text-sm text-slate-400 leading-relaxed">
            Eliminate link scams, invite spam, zalgo text, mention floods, and adult domains before disruption occurs.
          </p>
        </div>

        <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-3 hover:border-sky-500/40 transition">
          <div class="w-12 h-12 rounded-xl bg-emerald-950/80 border border-emerald-800/80 flex items-center justify-center text-emerald-400">
            <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </div>
          <h3 class="text-lg font-bold text-white">Premium Subscriptions</h3>
          <p class="text-sm text-slate-400 leading-relaxed">
            Multi-server licensing, lifetime activations, license code redemption, and dedicated high-priority queue processing.
          </p>
        </div>
      </div>
    </div>
  `;
}

// ==========================================
// 2. Login Page
// ==========================================
function renderLoginPage(content) {
  content.innerHTML = `
    <div class="max-w-md mx-auto py-16 text-center space-y-6">
      <div class="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center shadow-xl shadow-sky-500/20">
        <svg class="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
      </div>
      <div>
        <h2 class="text-2xl font-bold text-white">Authenticate with Discord</h2>
        <p class="text-sm text-slate-400 mt-1">Sign in to manage your server security configurations</p>
      </div>

      <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-4 text-left">
        <div class="flex items-center space-x-3 text-xs text-slate-300">
          <svg class="w-4 h-4 text-emerald-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
          <span>Verify guild administrator rights</span>
        </div>
        <div class="flex items-center space-x-3 text-xs text-slate-300">
          <svg class="w-4 h-4 text-emerald-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
          <span>Enforce role hierarchy and server isolation</span>
        </div>
        <div class="flex items-center space-x-3 text-xs text-slate-300">
          <svg class="w-4 h-4 text-emerald-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
          <span>No sensitive credentials or bot tokens stored in browser</span>
        </div>

        <button onclick="handleDemoLogin()" class="w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold transition flex items-center justify-center space-x-2">
          <span>Continue as Administrator</span>
          <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
        </button>
      </div>
    </div>
  `;
}

async function handleDemoLogin() {
  await apiPost('/api/auth/demo-login', { username: 'ZorvixAdmin', isDev: true });
  const authData = await apiGet('/api/auth/me');
  state.user = authData?.user;
  renderAuthHeader();
  navigate('dashboard');
}

// ==========================================
// 3. Dashboard Overview
// ==========================================
async function renderDashboardOverview(content) {
  const [status, guildsData] = await Promise.all([
    apiGet('/api/status'),
    apiGet('/api/guilds')
  ]);

  const guilds = guildsData?.guilds || [];
  const activeProtected = guilds.filter(g => g.antinuke).length;

  content.innerHTML = `
    <div class="space-y-6">
      <!-- Title & Live Status -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1B2433] pb-4">
        <div>
          <h2 class="text-2xl font-bold text-white tracking-tight">Security Command Center</h2>
          <p class="text-xs text-slate-400 mt-0.5">Real-time status of 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ cluster</p>
        </div>
        <div class="flex items-center space-x-3">
          <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-950/80 border border-emerald-800 text-emerald-400">
            <span class="w-2 h-2 rounded-full bg-emerald-400 mr-1.5 animate-pulse"></span>
            ${status?.status || 'ONLINE'}
          </span>
          <button onclick="navigate('simulator')" class="px-3 py-1.5 rounded-lg bg-sky-950 text-sky-400 border border-sky-800 text-xs font-semibold hover:bg-sky-900 transition">
            Test Attack Defense
          </button>
        </div>
      </div>

      <!-- Quick Metrics -->
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="p-5 rounded-2xl bg-[#0D111A] border border-[#1B2433]">
          <p class="text-xs text-slate-400 font-medium">Global Shield Health</p>
          <div class="flex items-baseline space-x-2 mt-2">
            <span class="text-2xl font-extrabold text-white">99.8%</span>
            <span class="text-xs text-emerald-400 font-semibold">Optimal</span>
          </div>
          <div class="w-full bg-[#141B28] rounded-full h-1.5 mt-3">
            <div class="bg-emerald-500 h-1.5 rounded-full" style="width: 99.8%"></div>
          </div>
        </div>

        <div class="p-5 rounded-2xl bg-[#0D111A] border border-[#1B2433]">
          <p class="text-xs text-slate-400 font-medium">Protected Servers</p>
          <div class="flex items-baseline space-x-2 mt-2">
            <span class="text-2xl font-extrabold text-white">${guilds.length}</span>
            <span class="text-xs text-sky-400 font-semibold">${activeProtected} Active</span>
          </div>
          <p class="text-[11px] text-slate-500 mt-2 font-mono">Isolated DB records</p>
        </div>

        <div class="p-5 rounded-2xl bg-[#0D111A] border border-[#1B2433]">
          <p class="text-xs text-slate-400 font-medium">Threats Intercepted</p>
          <div class="flex items-baseline space-x-2 mt-2">
            <span class="text-2xl font-extrabold text-white">1,482</span>
            <span class="text-xs text-purple-400 font-semibold">24h</span>
          </div>
          <p class="text-[11px] text-slate-500 mt-2 font-mono">0 false positives</p>
        </div>

        <div class="p-5 rounded-2xl bg-[#0D111A] border border-[#1B2433]">
          <p class="text-xs text-slate-400 font-medium">Gateway Latency</p>
          <div class="flex items-baseline space-x-2 mt-2">
            <span class="text-2xl font-extrabold text-white">${status?.ping || 24}ms</span>
            <span class="text-xs text-emerald-400 font-semibold">Fast</span>
          </div>
          <p class="text-[11px] text-slate-500 mt-2 font-mono">Sharded Gateway</p>
        </div>
      </div>

      <!-- Quick Server Management Navigation -->
      <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-4">
        <div class="flex items-center justify-between">
          <h3 class="text-base font-bold text-white">Your Managed Servers</h3>
          <button onclick="navigate('servers')" class="text-xs text-sky-400 hover:text-sky-300 font-semibold">View All (${guilds.length}) &rarr;</button>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          ${guilds.map(g => `
            <div class="p-4 rounded-xl bg-[#07090E] border border-[#1B2433] hover:border-sky-500/50 transition flex items-center justify-between">
              <div>
                <p class="text-sm font-semibold text-white">${g.name}</p>
                <p class="text-xs text-slate-400">${g.memberCount} members · Score: <span class="text-emerald-400 font-bold">${g.securityScore}%</span></p>
              </div>
              <button onclick="navigate('server-overview', '${g.id}')" class="px-3 py-1 text-xs rounded-lg bg-sky-950 text-sky-400 border border-sky-800 hover:bg-sky-900 transition">
                Manage
              </button>
            </div>
          `).join('')}
        </div>
      </div>

      <!-- Quick Nav Action Tiles -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <button onclick="navigate('antinuke')" class="p-4 rounded-xl bg-[#0D111A] border border-[#1B2433] hover:border-sky-500/40 text-left transition space-y-1">
          <p class="text-sm font-bold text-white flex items-center gap-1.5">🛡️ Anti-Nuke</p>
          <p class="text-xs text-slate-400">Thresholds & mass raid containment</p>
        </button>
        <button onclick="navigate('automod')" class="p-4 rounded-xl bg-[#0D111A] border border-[#1B2433] hover:border-sky-500/40 text-left transition space-y-1">
          <p class="text-sm font-bold text-white flex items-center gap-1.5">🤖 AutoMod</p>
          <p class="text-xs text-slate-400">Invite, link, zalgo & bad words filters</p>
        </button>
        <button onclick="navigate('whitelist')" class="p-4 rounded-xl bg-[#0D111A] border border-[#1B2433] hover:border-sky-500/40 text-left transition space-y-1">
          <p class="text-sm font-bold text-white flex items-center gap-1.5">👑 Whitelist & Extra</p>
          <p class="text-xs text-slate-400">Trusted admins and bypass management</p>
        </button>
        <button onclick="navigate('redeem')" class="p-4 rounded-xl bg-[#0D111A] border border-[#1B2433] hover:border-sky-500/40 text-left transition space-y-1">
          <p class="text-sm font-bold text-white flex items-center gap-1.5">💎 Redeem Key</p>
          <p class="text-xs text-slate-400">Activate premium license codes</p>
        </button>
      </div>
    </div>
  `;
}

// ==========================================
// 4. Server Selection
// ==========================================
async function renderServerSelection(content) {
  const data = await apiGet('/api/guilds');
  const guilds = data?.guilds || [];

  content.innerHTML = `
    <div class="space-y-6">
      <div>
        <h2 class="text-2xl font-bold text-white">Select a Server</h2>
        <p class="text-xs text-slate-400 mt-0.5">Configure 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ protections per server</p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        ${guilds.map(g => `
          <div class="p-5 rounded-2xl bg-[#0D111A] border border-[#1B2433] hover:border-sky-500/50 transition flex flex-col justify-between space-y-4">
            <div class="flex items-start space-x-3">
              <div class="w-12 h-12 rounded-xl bg-[#141B28] border border-[#1B2433] flex items-center justify-center font-bold text-white text-base">
                ${g.name.split(' ').map(w => w[0]).join('').slice(0, 3)}
              </div>
              <div>
                <h4 class="text-base font-bold text-white">${g.name}</h4>
                <p class="text-xs text-slate-400 font-mono">ID: ${g.id}</p>
                <div class="flex items-center space-x-2 mt-2">
                  <span class="text-[10px] px-2 py-0.5 rounded font-semibold ${g.antinuke ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-red-950 text-red-400 border border-red-800'}">
                    Anti-Nuke: ${g.antinuke ? 'ON' : 'OFF'}
                  </span>
                  <span class="text-[10px] px-2 py-0.5 rounded font-semibold bg-sky-950 text-sky-400 border border-sky-800">
                    Score: ${g.securityScore}%
                  </span>
                </div>
              </div>
            </div>

            <div class="pt-2 border-t border-[#1B2433] flex items-center justify-between">
              <span class="text-xs text-slate-400">${g.memberCount} members</span>
              <button onclick="navigate('server-overview', '${g.id}')" class="px-4 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs transition">
                Configure Protection
              </button>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

// ==========================================
// 5. Server Security Overview
// ==========================================
async function renderServerOverview(content) {
  const guildId = state.currentGuildId;
  const overview = await apiGet(`/api/guilds/${guildId}/overview`);

  content.innerHTML = `
    <div class="space-y-6">
      <!-- Breadcrumb & Title -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1B2433] pb-4">
        <div>
          <button onclick="navigate('servers')" class="text-xs text-slate-400 hover:text-white flex items-center gap-1 mb-1">&larr; Back to Servers</button>
          <h2 class="text-2xl font-bold text-white tracking-tight">Server Security Overview</h2>
          <p class="text-xs text-slate-400 font-mono">Guild ID: ${guildId}</p>
        </div>
        <div class="flex items-center space-x-2">
          <button onclick="navigate('antinuke')" class="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold transition">
            Anti-Nuke Settings
          </button>
          <button onclick="navigate('automod')" class="px-3 py-1.5 rounded-lg bg-[#141B28] hover:bg-[#1E293B] text-slate-300 text-xs font-semibold border border-[#1B2433] transition">
            AutoMod Rules
          </button>
        </div>
      </div>

      <!-- Shield Score Card -->
      <div class="p-6 rounded-2xl bg-gradient-to-br from-[#0D111A] to-[#141B28] border border-[#1B2433] flex flex-col md:flex-row items-center justify-between gap-6">
        <div class="space-y-2 text-center md:text-left">
          <div class="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-800 text-emerald-400 text-xs font-semibold">
            <span>🛡️ Active Shield Verified</span>
          </div>
          <h3 class="text-3xl font-extrabold text-white">Security Score: ${overview?.securityScore || 85}%</h3>
          <p class="text-xs text-slate-400 max-w-lg">
            This score reflects active protections against mass bans, channel tampering, rogue bots, spam floods, and webhook injections.
          </p>
        </div>
        <div class="w-28 h-28 rounded-full border-4 border-sky-500/30 flex items-center justify-center relative bg-[#07090E]">
          <span class="text-2xl font-black text-sky-400">${overview?.securityScore || 85}%</span>
        </div>
      </div>

      <!-- Subsystem Status Tiles -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div onclick="navigate('antinuke')" class="p-4 rounded-xl bg-[#0D111A] border border-[#1B2433] cursor-pointer hover:border-sky-500/40 transition">
          <p class="text-xs text-slate-400">Anti-Nuke</p>
          <p class="text-lg font-bold text-white mt-1">${overview?.antinuke?.enabled ? '🟢 Enabled' : '🔴 Disabled'}</p>
          <p class="text-[11px] text-slate-500 mt-1">${overview?.antinuke?.punishment || 'stripall'} punishment</p>
        </div>
        <div onclick="navigate('automod')" class="p-4 rounded-xl bg-[#0D111A] border border-[#1B2433] cursor-pointer hover:border-sky-500/40 transition">
          <p class="text-xs text-slate-400">AutoMod</p>
          <p class="text-lg font-bold text-white mt-1">${overview?.automod?.enabled ? '🟢 Enabled' : '🔴 Disabled'}</p>
          <p class="text-[11px] text-slate-500 mt-1">${overview?.automod?.punishment || 'delete'} on spam/invites</p>
        </div>
        <div onclick="navigate('whitelist')" class="p-4 rounded-xl bg-[#0D111A] border border-[#1B2433] cursor-pointer hover:border-sky-500/40 transition">
          <p class="text-xs text-slate-400">Trusted Access</p>
          <p class="text-lg font-bold text-white mt-1">${overview?.extraOwnersCount || 0} Extra Owners</p>
          <p class="text-[11px] text-slate-500 mt-1">${overview?.whitelistCount || 0} Whitelisted Admins</p>
        </div>
        <div onclick="navigate('subscription')" class="p-4 rounded-xl bg-[#0D111A] border border-[#1B2433] cursor-pointer hover:border-sky-500/40 transition">
          <p class="text-xs text-slate-400">Server Tier</p>
          <p class="text-lg font-bold text-white mt-1">${overview?.premium?.isPremium ? '👑 PREMIUM' : '🛡️ FREE'}</p>
          <p class="text-[11px] text-slate-500 mt-1">${overview?.premium?.plan || 'Free Shield'}</p>
        </div>
      </div>
    </div>
  `;
}

// ==========================================
// 6. Anti-Nuke Configuration Page
// ==========================================
async function renderAntinukeConfig(content) {
  const guildId = state.currentGuildId;
  const config = await apiGet(`/api/guilds/${guildId}/antinuke`);

  content.innerHTML = `
    <div class="space-y-6">
      <div class="flex items-center justify-between border-b border-[#1B2433] pb-4">
        <div>
          <button onclick="navigate('server-overview')" class="text-xs text-slate-400 hover:text-white flex items-center gap-1 mb-1">&larr; Back to Overview</button>
          <h2 class="text-2xl font-bold text-white">Anti-Nuke Protection Settings</h2>
          <p class="text-xs text-slate-400">Configure raid thresholds, attack rate-limits, and containment punishments</p>
        </div>
        <button id="save-antinuke-btn" onclick="saveAntinukeSettings()" class="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs shadow-md transition">
          Save Settings
        </button>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Main Toggles & Actions -->
        <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-4">
          <h3 class="text-base font-bold text-white">Core Enforcement</h3>

          <div>
            <label class="text-xs font-semibold text-slate-300">System Master Toggle</label>
            <div class="flex items-center justify-between mt-2 p-3 bg-[#07090E] rounded-xl border border-[#1B2433]">
              <span class="text-sm font-medium text-white">Anti-Nuke Active</span>
              <input type="checkbox" id="an-enabled" ${config?.enabled ? 'checked' : ''} class="w-5 h-5 text-sky-600 rounded bg-[#141B28] border-slate-700">
            </div>
          </div>

          <div>
            <label class="text-xs font-semibold text-slate-300">Containment Punishment</label>
            <select id="an-punishment" class="w-full mt-2 p-2.5 bg-[#07090E] rounded-xl border border-[#1B2433] text-sm text-white focus:border-sky-500 outline-none">
              <option value="stripall" ${config?.punishment === 'stripall' ? 'selected' : ''}>Strip All Roles (Recommended)</option>
              <option value="kick" ${config?.punishment === 'kick' ? 'selected' : ''}>Kick Attacker</option>
              <option value="ban" ${config?.punishment === 'ban' ? 'selected' : ''}>Ban Attacker</option>
            </select>
          </div>

          <div>
            <label class="text-xs font-semibold text-slate-300">Action Threshold (Count)</label>
            <input type="number" id="an-threshold" value="${config?.threshold || 3}" min="1" max="10" class="w-full mt-2 p-2.5 bg-[#07090E] rounded-xl border border-[#1B2433] text-sm text-white focus:border-sky-500 outline-none">
            <span class="text-[11px] text-slate-500">Actions before containment triggers</span>
          </div>

          <div>
            <label class="text-xs font-semibold text-slate-300">Timeframe Window (Seconds)</label>
            <input type="number" id="an-timeframe" value="${config?.timeframe || 60}" min="5" max="300" class="w-full mt-2 p-2.5 bg-[#07090E] rounded-xl border border-[#1B2433] text-sm text-white focus:border-sky-500 outline-none">
            <span class="text-[11px] text-slate-500">Evaluation sliding window duration</span>
          </div>

          <div class="flex items-center justify-between p-3 bg-[#07090E] rounded-xl border border-[#1B2433]">
            <div>
              <p class="text-xs font-semibold text-white">Dry-Run / Test Mode</p>
              <p class="text-[10px] text-slate-500">Log threats without applying punishments</p>
            </div>
            <input type="checkbox" id="an-dryrun" ${config?.dryRun ? 'checked' : ''} class="w-5 h-5 text-sky-600 rounded bg-[#141B28] border-slate-700">
          </div>
        </div>

        <!-- Protected Event Filters -->
        <div class="md:col-span-2 p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-4">
          <h3 class="text-base font-bold text-white">Protected Event Modules</h3>
          <p class="text-xs text-slate-400">Toggle individual protections monitored by the Anti-Nuke gateway.</p>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            ${[
              { id: 'an-ban', key: 'antiBan', title: 'Mass Ban Defense', desc: 'Detects rapid server member bans' },
              { id: 'an-kick', key: 'antiKick', title: 'Mass Kick Defense', desc: 'Detects rapid server member kicks' },
              { id: 'an-ch-del', key: 'antiChannelDelete', title: 'Channel Delete Defense', desc: 'Blocks unauthorized channel purges' },
              { id: 'an-ch-crt', key: 'antiChannelCreate', title: 'Channel Spam Defense', desc: 'Blocks spam channel creations' },
              { id: 'an-rl-del', key: 'antiRoleDelete', title: 'Role Delete Defense', desc: 'Blocks bulk deletion of server roles' },
              { id: 'an-rl-crt', key: 'antiRoleCreate', title: 'Role Create Defense', desc: 'Blocks spam role creations' },
              { id: 'an-rl-upd', key: 'antiRoleUpdate', title: 'Role Escalation Defense', desc: 'Blocks unauthorized admin grants to roles' },
              { id: 'an-webhook', key: 'antiWebhook', title: 'Webhook Abuse Defense', desc: 'Blocks unauthorized webhook generation' },
              { id: 'an-bot', key: 'antiBot', title: 'Unauthorized Bot Defense', desc: 'Auto-kicks unverified invited bots' },
              { id: 'an-guild', key: 'antiGuildUpdate', title: 'Guild Settings Defense', desc: 'Protects vanity URL, name & icon' },
              { id: 'an-prune', key: 'antiMemberPrune', title: 'Member Prune Defense', desc: 'Blocks mass inactive member pruning' },
              { id: 'an-escalate', key: 'antiPermissionEscalation', title: 'Permission Escalation', desc: 'Blocks rogue privilege grants' },
            ].map(m => `
              <div class="p-3 bg-[#07090E] rounded-xl border border-[#1B2433] flex items-center justify-between">
                <div>
                  <p class="text-xs font-semibold text-white">${m.title}</p>
                  <p class="text-[10px] text-slate-400">${m.desc}</p>
                </div>
                <input type="checkbox" id="${m.id}" ${config?.[m.key] !== false ? 'checked' : ''} class="w-4 h-4 text-sky-600 rounded bg-[#141B28] border-slate-700">
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    </div>
  `;
}

async function saveAntinukeSettings() {
  const guildId = state.currentGuildId;
  const btn = document.getElementById('save-antinuke-btn');
  btn.textContent = 'Saving...';

  const body = {
    enabled: document.getElementById('an-enabled').checked,
    punishment: document.getElementById('an-punishment').value,
    threshold: parseInt(document.getElementById('an-threshold').value) || 3,
    timeframe: parseInt(document.getElementById('an-timeframe').value) || 60,
    dryRun: document.getElementById('an-dryrun').checked,
    antiBan: document.getElementById('an-ban').checked,
    antiKick: document.getElementById('an-kick').checked,
    antiChannelDelete: document.getElementById('an-ch-del').checked,
    antiChannelCreate: document.getElementById('an-ch-crt').checked,
    antiRoleDelete: document.getElementById('an-rl-del').checked,
    antiRoleCreate: document.getElementById('an-rl-crt').checked,
    antiRoleUpdate: document.getElementById('an-rl-upd').checked,
    antiWebhook: document.getElementById('an-webhook').checked,
    antiBot: document.getElementById('an-bot').checked,
    antiGuildUpdate: document.getElementById('an-guild').checked,
    antiMemberPrune: document.getElementById('an-prune').checked,
    antiPermissionEscalation: document.getElementById('an-escalate').checked
  };

  const res = await apiPost(`/api/guilds/${guildId}/antinuke`, body);
  btn.textContent = 'Saved!';
  setTimeout(() => { btn.textContent = 'Save Settings'; }, 2000);
}

// ==========================================
// 7. AutoMod Configuration Page
// ==========================================
async function renderAutomodConfig(content) {
  const guildId = state.currentGuildId;
  const config = await apiGet(`/api/guilds/${guildId}/automod`);

  let badWords = [];
  try { badWords = JSON.parse(config?.badWords || '[]'); } catch { badWords = []; }

  content.innerHTML = `
    <div class="space-y-6">
      <div class="flex items-center justify-between border-b border-[#1B2433] pb-4">
        <div>
          <button onclick="navigate('server-overview')" class="text-xs text-slate-400 hover:text-white flex items-center gap-1 mb-1">&larr; Back to Overview</button>
          <h2 class="text-2xl font-bold text-white">Advanced AutoMod Settings</h2>
          <p class="text-xs text-slate-400">Real-time content moderation, link guards, and spam mitigation</p>
        </div>
        <button id="save-automod-btn" onclick="saveAutomodSettings()" class="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs shadow-md transition">
          Save Settings
        </button>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Master Config -->
        <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-4">
          <h3 class="text-base font-bold text-white">AutoMod Configuration</h3>

          <div class="flex items-center justify-between p-3 bg-[#07090E] rounded-xl border border-[#1B2433]">
            <span class="text-sm font-medium text-white">AutoMod Active</span>
            <input type="checkbox" id="am-enabled" ${config?.enabled ? 'checked' : ''} class="w-5 h-5 text-sky-600 rounded bg-[#141B28]">
          </div>

          <div>
            <label class="text-xs font-semibold text-slate-300">Default Action</label>
            <select id="am-punishment" class="w-full mt-2 p-2.5 bg-[#07090E] rounded-xl border border-[#1B2433] text-sm text-white focus:border-sky-500 outline-none">
              <option value="delete" ${config?.punishment === 'delete' ? 'selected' : ''}>Delete Message Only</option>
              <option value="warn" ${config?.punishment === 'warn' ? 'selected' : ''}>Warn User & Delete</option>
              <option value="mute" ${config?.punishment === 'mute' ? 'selected' : ''}>Timeout/Mute User & Delete</option>
              <option value="kick" ${config?.punishment === 'kick' ? 'selected' : ''}>Kick User</option>
              <option value="ban" ${config?.punishment === 'ban' ? 'selected' : ''}>Ban User</option>
            </select>
          </div>

          <div>
            <label class="text-xs font-semibold text-slate-300">Timeout Duration (Seconds)</label>
            <input type="number" id="am-mute" value="${config?.muteDuration || 300}" class="w-full mt-2 p-2.5 bg-[#07090E] rounded-xl border border-[#1B2433] text-sm text-white outline-none">
          </div>

          <!-- Blacklisted Words Box -->
          <div class="pt-2 border-t border-[#1B2433]">
            <label class="text-xs font-semibold text-slate-300">Blacklisted Words / Phrases</label>
            <p class="text-[11px] text-slate-500 mb-2">Comma separated list</p>
            <textarea id="am-badwords" rows="4" class="w-full p-2.5 bg-[#07090E] rounded-xl border border-[#1B2433] text-xs text-white outline-none font-mono">${badWords.join(', ')}</textarea>
          </div>
        </div>

        <!-- Filter Rules -->
        <div class="md:col-span-2 p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-4">
          <h3 class="text-base font-bold text-white">Active Content Filters</h3>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            ${[
              { id: 'am-spam', key: 'antiSpam', title: 'Anti-Spam Rate Limit', desc: 'Max 5 msgs in 5 seconds' },
              { id: 'am-invite', key: 'antiInvite', title: 'Anti-Invite Guard', desc: 'Blocks discord.gg invite links' },
              { id: 'am-link', key: 'antiLink', title: 'Anti-Link Guard', desc: 'Blocks all external HTTP(S) links' },
              { id: 'am-mention', key: 'antiMassMention', title: 'Anti-Mass Mention', desc: 'Blocks >5 user/role mentions' },
              { id: 'am-caps', key: 'antiCaps', title: 'Anti-Caps Flood', desc: 'Blocks >70% uppercase text' },
              { id: 'am-emoji', key: 'antiEmojiSpam', title: 'Anti-Emoji Spam', desc: 'Blocks >6 emojis per message' },
              { id: 'am-attach', key: 'antiAttachmentSpam', title: 'Anti-Attachment Spam', desc: 'Blocks >3 files per message' },
              { id: 'am-zalgo', key: 'antiZalgoSpam', title: 'Anti-Zalgo Text', desc: 'Blocks corrupted glitch characters' },
              { id: 'am-similar', key: 'antiSimilarSpam', title: 'Similar-Message Spam', desc: 'Blocks repetitive copypasta' },
              { id: 'am-nsfw', key: 'antiNsfwLink', title: 'Anti-NSFW Link Guard', desc: 'Blocks known explicit domains' },
              { id: 'am-words', key: 'antiBadWords', title: 'Blacklisted Words Filter', desc: 'Deletes configured bad words' },
              { id: 'am-newline', key: 'antiNewlineSpam', title: 'Anti-Newline Wall', desc: 'Blocks excessive whitespace' },
            ].map(f => `
              <div class="p-3 bg-[#07090E] rounded-xl border border-[#1B2433] flex items-center justify-between">
                <div>
                  <p class="text-xs font-semibold text-white">${f.title}</p>
                  <p class="text-[10px] text-slate-400">${f.desc}</p>
                </div>
                <input type="checkbox" id="${f.id}" ${config?.[f.key] !== false ? 'checked' : ''} class="w-4 h-4 text-sky-600 rounded bg-[#141B28]">
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    </div>
  `;
}

async function saveAutomodSettings() {
  const guildId = state.currentGuildId;
  const btn = document.getElementById('save-automod-btn');
  btn.textContent = 'Saving...';

  const badWordsRaw = document.getElementById('am-badwords').value;
  const badWordsArray = badWordsRaw.split(',').map(s => s.trim().toLowerCase()).filter(Boolean);

  const body = {
    enabled: document.getElementById('am-enabled').checked,
    punishment: document.getElementById('am-punishment').value,
    muteDuration: parseInt(document.getElementById('am-mute').value) || 300,
    badWords: JSON.stringify(badWordsArray),
    antiSpam: document.getElementById('am-spam').checked,
    antiInvite: document.getElementById('am-invite').checked,
    antiLink: document.getElementById('am-link').checked,
    antiMassMention: document.getElementById('am-mention').checked,
    antiCaps: document.getElementById('am-caps').checked,
    antiEmojiSpam: document.getElementById('am-emoji').checked,
    antiAttachmentSpam: document.getElementById('am-attach').checked,
    antiZalgoSpam: document.getElementById('am-zalgo').checked,
    antiSimilarSpam: document.getElementById('am-similar').checked,
    antiNsfwLink: document.getElementById('am-nsfw').checked,
    antiBadWords: document.getElementById('am-words').checked,
    antiNewlineSpam: document.getElementById('am-newline').checked
  };

  await apiPost(`/api/guilds/${guildId}/automod`, body);
  btn.textContent = 'Saved!';
  setTimeout(() => { btn.textContent = 'Save Settings'; }, 2000);
}

// ==========================================
// 8. Logging Configuration Page
// ==========================================
async function renderLoggingConfig(content) {
  const guildId = state.currentGuildId;
  const logging = await apiGet(`/api/guilds/${guildId}/logging`);

  content.innerHTML = `
    <div class="space-y-6">
      <div class="flex items-center justify-between border-b border-[#1B2433] pb-4">
        <div>
          <button onclick="navigate('server-overview')" class="text-xs text-slate-400 hover:text-white flex items-center gap-1 mb-1">&larr; Back to Overview</button>
          <h2 class="text-2xl font-bold text-white">Logging Channels Configuration</h2>
          <p class="text-xs text-slate-400">Direct real-time alerts and audit logs to dedicated Discord channels</p>
        </div>
        <button id="save-log-btn" onclick="saveLoggingSettings()" class="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs shadow-md transition">
          Save Channels
        </button>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        ${[
          { id: 'log-main', key: 'logChannelId', title: 'Main Security Alert Channel' },
          { id: 'log-an', key: 'antinukeLogChannelId', title: 'Anti-Nuke Incident Channel' },
          { id: 'log-am', key: 'automodLogChannelId', title: 'AutoMod Violation Channel' },
          { id: 'log-mod', key: 'modLogChannelId', title: 'Staff Moderation Logs' },
          { id: 'log-mbr', key: 'memberLogChannelId', title: 'Member Join / Leave Channel' },
          { id: 'log-msg', key: 'messageLogChannelId', title: 'Message Edit / Delete Channel' },
        ].map(l => `
          <div class="p-5 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-2">
            <label class="text-xs font-semibold text-white">${l.title}</label>
            <input type="text" id="${l.id}" value="${logging?.[l.key] || ''}" placeholder="Discord Channel ID (e.g. 123456789012345678)" class="w-full p-2.5 bg-[#07090E] rounded-xl border border-[#1B2433] text-sm text-white font-mono outline-none focus:border-sky-500">
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

async function saveLoggingSettings() {
  const guildId = state.currentGuildId;
  const btn = document.getElementById('save-log-btn');
  btn.textContent = 'Saving...';

  const body = {
    logChannelId: document.getElementById('log-main').value,
    antinukeLogChannelId: document.getElementById('log-an').value,
    automodLogChannelId: document.getElementById('log-am').value,
    modLogChannelId: document.getElementById('log-mod').value,
    memberLogChannelId: document.getElementById('log-mbr').value,
    messageLogChannelId: document.getElementById('log-msg').value
  };

  await apiPost(`/api/guilds/${guildId}/logging`, body);
  btn.textContent = 'Saved!';
  setTimeout(() => { btn.textContent = 'Save Channels'; }, 2000);
}

// ==========================================
// 9. Moderation History & Cases
// ==========================================
async function renderModlogs(content) {
  const guildId = state.currentGuildId;
  const data = await apiGet(`/api/guilds/${guildId}/modlogs`);
  const logs = data?.logs || [];

  content.innerHTML = `
    <div class="space-y-6">
      <div class="flex items-center justify-between border-b border-[#1B2433] pb-4">
        <div>
          <button onclick="navigate('server-overview')" class="text-xs text-slate-400 hover:text-white flex items-center gap-1 mb-1">&larr; Back to Overview</button>
          <h2 class="text-2xl font-bold text-white">Moderation Cases & Audit Trail</h2>
          <p class="text-xs text-slate-400">Permanent record of automated and staff moderation actions</p>
        </div>
      </div>

      <div class="rounded-2xl bg-[#0D111A] border border-[#1B2433] overflow-hidden">
        <table class="w-full text-left text-xs text-slate-300">
          <thead class="bg-[#141B28] text-slate-400 font-semibold border-b border-[#1B2433]">
            <tr>
              <th class="p-3.5">Case ID</th>
              <th class="p-3.5">Action</th>
              <th class="p-3.5">Target</th>
              <th class="p-3.5">Moderator</th>
              <th class="p-3.5">Reason</th>
              <th class="p-3.5">Date</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-[#1B2433]">
            ${logs.length > 0 ? logs.map(l => `
              <tr class="hover:bg-[#141B28]/50 transition">
                <td class="p-3.5 font-mono text-slate-400">#${l.id}</td>
                <td class="p-3.5">
                  <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                    l.action === 'ban' ? 'bg-red-950 text-red-400 border border-red-800' :
                    l.action === 'timeout' || l.action === 'mute' ? 'bg-amber-950 text-amber-400 border border-amber-800' :
                    'bg-sky-950 text-sky-400 border border-sky-800'
                  }">
                    ${l.action}
                  </span>
                </td>
                <td class="p-3.5 font-medium text-white">${l.targetTag || l.targetId}</td>
                <td class="p-3.5 text-slate-300">${l.moderatorTag || '𝐙𝐨𝐫𝐯𝐢𝐱'}</td>
                <td class="p-3.5 text-slate-400">${l.reason || 'No reason specified'}</td>
                <td class="p-3.5 text-slate-500 font-mono">${new Date(l.createdAt).toLocaleDateString()}</td>
              </tr>
            `).join('') : `
              <tr>
                <td colspan="6" class="p-8 text-center text-slate-500">No moderation cases recorded yet.</td>
              </tr>
            `}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

// ==========================================
// 10. Whitelist & Extra Owner Management
// ==========================================
async function renderWhitelistManagement(content) {
  const guildId = state.currentGuildId;
  const [wlData, eoData] = await Promise.all([
    apiGet(`/api/guilds/${guildId}/antinuke/whitelist`),
    apiGet(`/api/guilds/${guildId}/extraowners`)
  ]);

  const whitelist = wlData?.whitelist || [];
  const extraOwners = eoData?.extraOwners || [];

  content.innerHTML = `
    <div class="space-y-6">
      <div class="flex items-center justify-between border-b border-[#1B2433] pb-4">
        <div>
          <button onclick="navigate('server-overview')" class="text-xs text-slate-400 hover:text-white flex items-center gap-1 mb-1">&larr; Back to Overview</button>
          <h2 class="text-2xl font-bold text-white">Whitelist & Extra Owner Administration</h2>
          <p class="text-xs text-slate-400">Manage high-privilege users exempt from Anti-Nuke restrictions</p>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Extra Owners Section -->
        <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-4">
          <div class="flex items-center justify-between">
            <h3 class="text-base font-bold text-white">👑 Extra Owners</h3>
            <span class="text-xs text-slate-400">${extraOwners.length} users</span>
          </div>
          <p class="text-xs text-slate-400">Extra Owners share trusted administrative access next to the server owner.</p>

          <div class="flex space-x-2">
            <input type="text" id="new-eo-id" placeholder="Discord User ID" class="flex-1 p-2 bg-[#07090E] rounded-xl border border-[#1B2433] text-xs text-white outline-none">
            <button onclick="addExtraOwner()" class="px-3 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs transition">Add Owner</button>
          </div>

          <div class="space-y-2 pt-2">
            ${extraOwners.length > 0 ? extraOwners.map(eo => `
              <div class="p-3 bg-[#07090E] rounded-xl border border-[#1B2433] flex items-center justify-between">
                <div>
                  <p class="text-xs font-semibold text-white font-mono">${eo.userId}</p>
                  <p class="text-[10px] text-slate-500">Added: ${new Date(eo.createdAt).toLocaleDateString()}</p>
                </div>
                <button onclick="removeExtraOwner('${eo.userId}')" class="text-xs text-red-400 hover:text-red-300 font-semibold">Remove</button>
              </div>
            `).join('') : '<p class="text-xs text-slate-500 text-center py-4">No Extra Owners registered.</p>'}
          </div>
        </div>

        <!-- Whitelisted Users Section -->
        <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-4">
          <div class="flex items-center justify-between">
            <h3 class="text-base font-bold text-white">🛡️ Anti-Nuke Whitelist</h3>
            <span class="text-xs text-slate-400">${whitelist.length} users</span>
          </div>
          <p class="text-xs text-slate-400">Whitelisted users can perform administrative actions without triggering nuke alerts.</p>

          <div class="flex space-x-2">
            <input type="text" id="new-wl-id" placeholder="Discord User ID" class="flex-1 p-2 bg-[#07090E] rounded-xl border border-[#1B2433] text-xs text-white outline-none">
            <button onclick="addWhitelistedUser()" class="px-3 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs transition">Add User</button>
          </div>

          <div class="space-y-2 pt-2">
            ${whitelist.length > 0 ? whitelist.map(wl => `
              <div class="p-3 bg-[#07090E] rounded-xl border border-[#1B2433] flex items-center justify-between">
                <div>
                  <p class="text-xs font-semibold text-white font-mono">${wl.userId}</p>
                  <p class="text-[10px] text-slate-500">Events: ${wl.events ? 'Custom' : 'All Events'}</p>
                </div>
                <button onclick="removeWhitelistedUser('${wl.userId}')" class="text-xs text-red-400 hover:text-red-300 font-semibold">Remove</button>
              </div>
            `).join('') : '<p class="text-xs text-slate-500 text-center py-4">No users whitelisted.</p>'}
          </div>
        </div>
      </div>
    </div>
  `;
}

async function addExtraOwner() {
  const userId = document.getElementById('new-eo-id').value.trim();
  if (!userId) return;
  await apiPost(`/api/guilds/${state.currentGuildId}/extraowners`, { userId });
  renderWhitelistManagement(document.getElementById('app-content'));
}

async function removeExtraOwner(userId) {
  await apiDelete(`/api/guilds/${state.currentGuildId}/extraowners/${userId}`);
  renderWhitelistManagement(document.getElementById('app-content'));
}

async function addWhitelistedUser() {
  const userId = document.getElementById('new-wl-id').value.trim();
  if (!userId) return;
  await apiPost(`/api/guilds/${state.currentGuildId}/antinuke/whitelist`, { userId });
  renderWhitelistManagement(document.getElementById('app-content'));
}

async function removeWhitelistedUser(userId) {
  await apiDelete(`/api/guilds/${state.currentGuildId}/antinuke/whitelist/${userId}`);
  renderWhitelistManagement(document.getElementById('app-content'));
}

// ==========================================
// 11. Plans Page
// ==========================================
async function renderPlansPage(content) {
  content.innerHTML = `
    <div class="py-6 space-y-8 max-w-5xl mx-auto">
      <div class="text-center space-y-2">
        <h2 class="text-3xl font-extrabold text-white">Protection Tiers & Subscriptions</h2>
        <p class="text-sm text-slate-400">Scale your server defense with persistent entitlements</p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <!-- Free Tier -->
        <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] flex flex-col justify-between space-y-6">
          <div class="space-y-3">
            <h3 class="text-lg font-bold text-white">Free Shield</h3>
            <p class="text-3xl font-black text-white">$0 <span class="text-xs font-normal text-slate-400">/ forever</span></p>
            <ul class="text-xs text-slate-400 space-y-2 pt-2">
              <li class="flex items-center gap-1.5"><span class="text-emerald-400 font-bold">✓</span> Essential Anti-Nuke</li>
              <li class="flex items-center gap-1.5"><span class="text-emerald-400 font-bold">✓</span> Basic AutoMod filters</li>
              <li class="flex items-center gap-1.5"><span class="text-emerald-400 font-bold">✓</span> Moderation log channel</li>
              <li class="flex items-center gap-1.5 text-slate-600">✗ Custom thresholds</li>
            </ul>
          </div>
          <button class="w-full py-2 rounded-xl bg-[#141B28] text-slate-300 font-semibold text-xs border border-[#1B2433]">Current Default</button>
        </div>

        <!-- Premium Tier -->
        <div class="p-6 rounded-2xl bg-gradient-to-b from-[#0D111A] to-[#141B28] border-2 border-sky-500/60 shadow-xl shadow-sky-500/10 flex flex-col justify-between space-y-6">
          <div class="space-y-3">
            <div class="flex items-center justify-between">
              <h3 class="text-lg font-bold text-white">Premium</h3>
              <span class="text-[10px] px-2 py-0.5 rounded-full bg-sky-500 text-white font-bold">POPULAR</span>
            </div>
            <p class="text-3xl font-black text-white">$4.99 <span class="text-xs font-normal text-slate-400">/ month</span></p>
            <ul class="text-xs text-slate-300 space-y-2 pt-2">
              <li class="flex items-center gap-1.5"><span class="text-sky-400 font-bold">✓</span> 1 Server Protection Slot</li>
              <li class="flex items-center gap-1.5"><span class="text-sky-400 font-bold">✓</span> Advanced AutoMod (Zalgo, NSFW, Emojis)</li>
              <li class="flex items-center gap-1.5"><span class="text-sky-400 font-bold">✓</span> Granular Threshold Customization</li>
              <li class="flex items-center gap-1.5"><span class="text-sky-400 font-bold">✓</span> Full Web Dashboard access</li>
            </ul>
          </div>
          <button onclick="handleCheckout('PREMIUM')" class="w-full py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow-md transition">Subscribe</button>
        </div>

        <!-- Lifetime Tier -->
        <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] flex flex-col justify-between space-y-6">
          <div class="space-y-3">
            <h3 class="text-lg font-bold text-white">Lifetime Citadel</h3>
            <p class="text-3xl font-black text-white">$49.99 <span class="text-xs font-normal text-slate-400">/ one-time</span></p>
            <ul class="text-xs text-slate-400 space-y-2 pt-2">
              <li class="flex items-center gap-1.5"><span class="text-emerald-400 font-bold">✓</span> 3 Server Protection Slots</li>
              <li class="flex items-center gap-1.5"><span class="text-emerald-400 font-bold">✓</span> Never expires</li>
              <li class="flex items-center gap-1.5"><span class="text-emerald-400 font-bold">✓</span> Custom quarantine roles</li>
              <li class="flex items-center gap-1.5"><span class="text-emerald-400 font-bold">✓</span> VIP Developer Support</li>
            </ul>
          </div>
          <button onclick="handleCheckout('LIFETIME')" class="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition">Purchase Lifetime</button>
        </div>

        <!-- Enterprise -->
        <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] flex flex-col justify-between space-y-6">
          <div class="space-y-3">
            <h3 class="text-lg font-bold text-white">Enterprise</h3>
            <p class="text-3xl font-black text-white">Custom</p>
            <ul class="text-xs text-slate-400 space-y-2 pt-2">
              <li class="flex items-center gap-1.5"><span class="text-emerald-400 font-bold">✓</span> 10+ Server Slots</li>
              <li class="flex items-center gap-1.5"><span class="text-emerald-400 font-bold">✓</span> Dedicated Bot Instance option</li>
              <li class="flex items-center gap-1.5"><span class="text-emerald-400 font-bold">✓</span> Custom branding & SLAs</li>
            </ul>
          </div>
          <button onclick="handleCheckout('ENTERPRISE')" class="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition">Contact Developer</button>
        </div>
      </div>
    </div>
  `;
}

async function handleCheckout(planKey) {
  const res = await apiPost('/api/checkout', { planKey });
  if (res.orderId) {
    // In test environment, automatically trigger test payment simulator
    const confirmPayment = confirm(`[Zorvix Payment Gateway] Simulate $${res.plan.price} ${res.plan.name} test payment now?`);
    if (confirmPayment) {
      const payRes = await apiPost('/api/checkout/simulate-payment', { orderId: res.orderId });
      alert(payRes.message || 'Payment successful!');
      navigate('subscription');
    }
  }
}

// ==========================================
// 12. Subscription Status Page
// ==========================================
async function renderSubscriptionPage(content) {
  const [subData, guildsData] = await Promise.all([
    apiGet('/api/premium/subscription'),
    apiGet('/api/guilds')
  ]);

  const sub = subData?.subscription;
  const slots = subData?.slots || [];
  const guilds = guildsData?.guilds || [];

  content.innerHTML = `
    <div class="space-y-6 max-w-4xl mx-auto">
      <div class="flex items-center justify-between border-b border-[#1B2433] pb-4">
        <div>
          <h2 class="text-2xl font-bold text-white">Your Premium Subscription</h2>
          <p class="text-xs text-slate-400">Manage server slots and entitlements</p>
        </div>
        <button onclick="navigate('redeem')" class="px-3 py-1.5 rounded-lg bg-sky-950 text-sky-400 border border-sky-800 text-xs font-semibold hover:bg-sky-900 transition">
          Redeem License Code
        </button>
      </div>

      <!-- Subscription Overview -->
      <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] flex items-center justify-between">
        <div>
          <p class="text-xs text-slate-400">Current Subscription Tier</p>
          <h3 class="text-2xl font-extrabold text-white mt-1">${subData?.plan || 'FREE'}</h3>
          <p class="text-xs text-slate-400 mt-1">
            ${sub?.endDate ? `Expires: ${new Date(sub.endDate).toLocaleDateString()}` : 'Permanent / Never Expires'}
          </p>
        </div>
        <div class="text-right">
          <p class="text-xs text-slate-400">Server Capacity</p>
          <p class="text-xl font-bold text-sky-400 mt-1">${subData?.usedSlots || 0} / ${subData?.maxSlots || 0} Slots Used</p>
        </div>
      </div>

      <!-- Active Server Slots Table -->
      <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-4">
        <h4 class="text-base font-bold text-white">Activated Server Slots</h4>
        <div class="space-y-2">
          ${slots.length > 0 ? slots.map(s => `
            <div class="p-4 bg-[#07090E] rounded-xl border border-[#1B2433] flex items-center justify-between">
              <div>
                <p class="text-sm font-semibold text-white">Guild ID: ${s.guildId}</p>
                <p class="text-xs text-slate-500">Activated: ${new Date(s.activatedAt).toLocaleDateString()}</p>
              </div>
              <button onclick="deactivateSlot('${s.guildId}')" class="px-3 py-1 rounded bg-red-950 text-red-400 border border-red-800 text-xs font-semibold hover:bg-red-900 transition">
                Revoke Slot
              </button>
            </div>
          `).join('') : '<p class="text-xs text-slate-500 text-center py-4">No servers currently activated. Use your slots below.</p>'}
        </div>

        ${subData?.usedSlots < subData?.maxSlots ? `
          <div class="pt-4 border-t border-[#1B2433] flex items-center gap-3">
            <select id="slot-guild-select" class="flex-1 p-2 bg-[#07090E] rounded-xl border border-[#1B2433] text-xs text-white outline-none">
              ${guilds.map(g => `<option value="${g.id}">${g.name} (${g.id})</option>`).join('')}
            </select>
            <button onclick="activateSlot()" class="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs transition">
              Activate Selected Server
            </button>
          </div>
        ` : ''}
      </div>
    </div>
  `;
}

async function activateSlot() {
  const guildId = document.getElementById('slot-guild-select').value;
  const res = await apiPost('/api/premium/activate', { guildId });
  alert(res.message);
  renderSubscriptionPage(document.getElementById('app-content'));
}

async function deactivateSlot(guildId) {
  const res = await apiPost('/api/premium/deactivate', { guildId });
  alert(res.message);
  renderSubscriptionPage(document.getElementById('app-content'));
}

// ==========================================
// 13. Redeem Code Page
// ==========================================
function renderRedeemPage(content) {
  content.innerHTML = `
    <div class="max-w-md mx-auto py-12 space-y-6 text-center">
      <div class="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-sky-500/20">
        <svg class="w-7 h-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg>
      </div>

      <div>
        <h2 class="text-2xl font-bold text-white">Redeem License Code</h2>
        <p class="text-xs text-slate-400 mt-1">Enter your 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ code to unlock premium server slots</p>
      </div>

      <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-4">
        <input type="text" id="redeem-code-input" placeholder="ZORVIX-PREM-XXXXX" class="w-full p-3 bg-[#07090E] rounded-xl border border-[#1B2433] text-sm text-center font-mono text-white outline-none focus:border-sky-500 uppercase tracking-widest">
        <button id="redeem-btn" onclick="submitRedeemCode()" class="w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-sm transition shadow-md shadow-sky-600/20">
          Redeem Code
        </button>
        <p id="redeem-status" class="text-xs text-slate-400"></p>
      </div>
    </div>
  `;
}

async function submitRedeemCode() {
  const code = document.getElementById('redeem-code-input').value.trim();
  const status = document.getElementById('redeem-status');
  if (!code) {
    status.textContent = 'Please enter a valid code.';
    status.className = 'text-xs text-amber-400';
    return;
  }

  status.textContent = 'Verifying code...';
  const res = await apiPost('/api/premium/redeem', { code });

  if (res.success) {
    status.textContent = res.message;
    status.className = 'text-xs text-emerald-400 font-semibold';
    setTimeout(() => navigate('subscription'), 1500);
  } else {
    status.textContent = res.message || 'Invalid or expired code.';
    status.className = 'text-xs text-red-400 font-semibold';
  }
}

// ==========================================
// 14. User Account Settings
// ==========================================
function renderAccountPage(content) {
  content.innerHTML = `
    <div class="max-w-2xl mx-auto py-8 space-y-6">
      <div class="border-b border-[#1B2433] pb-4">
        <h2 class="text-2xl font-bold text-white">Account Settings</h2>
        <p class="text-xs text-slate-400">Your profile, privileges, and session management</p>
      </div>

      <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-4">
        <div class="flex items-center space-x-4">
          <div class="w-16 h-16 rounded-2xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center font-bold text-2xl text-white">
            ${(state.user?.username || 'U')[0]}
          </div>
          <div>
            <h3 class="text-lg font-bold text-white">${state.user?.username || 'User'}</h3>
            <p class="text-xs text-slate-400 font-mono">Discord ID: ${state.user?.id || 'Unknown'}</p>
            <span class="inline-block mt-2 text-[10px] px-2 py-0.5 rounded font-semibold bg-sky-950 text-sky-400 border border-sky-800">
              ${state.user?.isDev ? 'Developer Authority' : 'Server Administrator'}
            </span>
          </div>
        </div>

        <div class="pt-4 border-t border-[#1B2433] flex items-center justify-between">
          <div>
            <p class="text-sm font-semibold text-white">Developer Administration</p>
            <p class="text-xs text-slate-400">Access developer commands, code generator & audit records</p>
          </div>
          <button onclick="navigate('admin')" class="px-4 py-2 rounded-xl bg-[#141B28] hover:bg-[#1E293B] text-sky-400 border border-[#1B2433] text-xs font-semibold transition">
            Developer Panel
          </button>
        </div>
      </div>
    </div>
  `;
}

// ==========================================
// 15. Developer-Only Administration
// ==========================================
async function renderAdminPage(content) {
  const [codesData, auditData] = await Promise.all([
    apiGet('/api/developer/codes'),
    apiGet('/api/developer/audit')
  ]);

  const codes = codesData?.codes || [];
  const logs = auditData?.logs || [];

  content.innerHTML = `
    <div class="space-y-6">
      <div class="flex items-center justify-between border-b border-[#1B2433] pb-4">
        <div>
          <h2 class="text-2xl font-bold text-white">Developer Command Center</h2>
          <p class="text-xs text-slate-400">Generate license keys, inspect global subscriptions and view audit logs</p>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Generate Code Tool -->
        <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-4">
          <h3 class="text-base font-bold text-white">🔑 Generate License Code</h3>

          <div>
            <label class="text-xs font-semibold text-slate-300">Plan Tier</label>
            <select id="gen-plan" class="w-full mt-1.5 p-2.5 bg-[#07090E] rounded-xl border border-[#1B2433] text-sm text-white outline-none">
              <option value="PREMIUM">PREMIUM (Standard)</option>
              <option value="LIFETIME">LIFETIME (Permanent)</option>
              <option value="ENTERPRISE">ENTERPRISE (Multi-Slot)</option>
            </select>
          </div>

          <div>
            <label class="text-xs font-semibold text-slate-300">Duration (Days)</label>
            <input type="number" id="gen-days" value="30" class="w-full mt-1.5 p-2 bg-[#07090E] rounded-xl border border-[#1B2433] text-sm text-white outline-none">
            <span class="text-[10px] text-slate-500">Set 0 for permanent lifetime</span>
          </div>

          <div>
            <label class="text-xs font-semibold text-slate-300">Server Slots</label>
            <input type="number" id="gen-slots" value="1" min="1" max="50" class="w-full mt-1.5 p-2 bg-[#07090E] rounded-xl border border-[#1B2433] text-sm text-white outline-none">
          </div>

          <button onclick="handleGenerateCode()" class="w-full py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs transition">
            Generate Code
          </button>
          <div id="gen-result" class="text-xs font-mono text-center text-emerald-400"></div>
        </div>

        <!-- Recent Codes -->
        <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-4">
          <h3 class="text-base font-bold text-white">Generated Codes (${codes.length})</h3>
          <div class="space-y-2 max-h-80 overflow-y-auto custom-scroll">
            ${codes.length > 0 ? codes.map(c => `
              <div class="p-2.5 bg-[#07090E] rounded-xl border border-[#1B2433] text-xs">
                <div class="flex items-center justify-between">
                  <span class="font-mono font-bold text-sky-400">${c.code}</span>
                  <span class="text-[10px] font-semibold ${c.isRedeemed ? 'text-slate-500' : 'text-emerald-400'}">${c.isRedeemed ? 'Redeemed' : 'Active'}</span>
                </div>
                <p class="text-[10px] text-slate-500 mt-0.5">${c.plan} · ${c.durationDays || 'Lifetime'}d · ${c.slots} slots</p>
              </div>
            `).join('') : '<p class="text-xs text-slate-500 text-center py-4">No codes generated yet.</p>'}
          </div>
        </div>

        <!-- Global Audit Logs -->
        <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-4">
          <h3 class="text-base font-bold text-white">System Audit Logs</h3>
          <div class="space-y-2 max-h-80 overflow-y-auto custom-scroll">
            ${logs.length > 0 ? logs.map(l => `
              <div class="p-2.5 bg-[#07090E] rounded-xl border border-[#1B2433] text-xs space-y-0.5">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-white uppercase text-[10px]">[${l.module}] ${l.action}</span>
                  <span class="text-[10px] text-slate-500 font-mono">${new Date(l.createdAt).toLocaleTimeString()}</span>
                </div>
                <p class="text-[11px] text-slate-400">${l.reason || ''}</p>
              </div>
            `).join('') : '<p class="text-xs text-slate-500 text-center py-4">No audit logs recorded.</p>'}
          </div>
        </div>
      </div>
    </div>
  `;
}

async function handleGenerateCode() {
  const plan = document.getElementById('gen-plan').value;
  const durationDays = document.getElementById('gen-days').value;
  const slots = document.getElementById('gen-slots').value;

  const res = await apiPost('/api/developer/codes', { plan, durationDays, slots });
  const resultDiv = document.getElementById('gen-result');
  if (res.code) {
    resultDiv.textContent = `Generated: ${res.code.code}`;
    setTimeout(() => renderAdminPage(document.getElementById('app-content')), 1500);
  }
}

// ==========================================
// 16. Threat Simulator (Live Attack Testing)
// ==========================================
function renderThreatSimulator(content) {
  content.innerHTML = `
    <div class="space-y-6 max-w-4xl mx-auto">
      <div class="flex items-center justify-between border-b border-[#1B2433] pb-4">
        <div>
          <h2 class="text-2xl font-bold text-white">Live Threat Simulator</h2>
          <p class="text-xs text-slate-400">Safely test 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ containment algorithms against simulated attack vectors</p>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Attack Trigger Controls -->
        <div class="p-6 rounded-2xl bg-[#0D111A] border border-[#1B2433] space-y-4">
          <h3 class="text-base font-bold text-white">Select Attack Vector</h3>

          <div>
            <label class="text-xs font-semibold text-slate-300">Attack Type</label>
            <select id="sim-threat-type" class="w-full mt-1.5 p-2.5 bg-[#07090E] rounded-xl border border-[#1B2433] text-sm text-white outline-none">
              <option value="ANTINUKE_MASS_BAN">Anti-Nuke: Rapid Mass Ban Raid (4 bans in 2s)</option>
              <option value="AUTOMOD_INVITE">AutoMod: Discord Invite Link Spam</option>
              <option value="AUTOMOD_ZALGO">AutoMod: Corrupted Zalgo/Glitch Text</option>
              <option value="AUTOMOD_SPAM">AutoMod: High-Frequency Message Spam</option>
            </select>
          </div>

          <div>
            <label class="text-xs font-semibold text-slate-300">Payload / Custom Message (Optional)</label>
            <input type="text" id="sim-content" placeholder="Leave empty for default attack vector" class="w-full mt-1.5 p-2 bg-[#07090E] rounded-xl border border-[#1B2433] text-xs text-white outline-none">
          </div>

          <button onclick="runAttackSimulation()" class="w-full py-3 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-bold text-xs shadow-lg transition">
            Execute Simulated Attack
          </button>
        </div>

        <!-- Attack Response Terminal -->
        <div class="p-6 rounded-2xl bg-[#07090E] border border-[#1B2433] space-y-3 flex flex-col justify-between font-mono text-xs">
          <div>
            <div class="flex items-center space-x-2 text-slate-400 border-b border-[#1B2433] pb-2">
              <span class="w-2.5 h-2.5 rounded-full bg-red-500 inline-block"></span>
              <span class="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block"></span>
              <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span>
              <span class="text-[11px] text-slate-500 font-sans ml-2">containment_terminal.log</span>
            </div>
            <div id="sim-log-terminal" class="py-4 space-y-2 text-slate-300">
              <p class="text-slate-500">[SYSTEM] Simulator initialized. Ready for attack vector input.</p>
            </div>
          </div>
          <div class="text-[10px] text-slate-500 border-t border-[#1B2433] pt-2">
            Status: Isolated sandbox environment
          </div>
        </div>
      </div>
    </div>
  `;
}

async function runAttackSimulation() {
  const threatType = document.getElementById('sim-threat-type').value;
  const content = document.getElementById('sim-content').value;
  const terminal = document.getElementById('sim-log-terminal');

  terminal.innerHTML += `<p class="text-amber-400 mt-2">&gt; Launching simulation vector [${threatType}]...</p>`;

  const res = await apiPost(`/api/guilds/${state.currentGuildId}/simulate`, { threatType, content });

  setTimeout(() => {
    terminal.innerHTML += `
      <p class="text-emerald-400 font-bold">&gt; ${res.result}</p>
      <p class="text-slate-500">&gt; Timestamp: ${res.timestamp}</p>
    `;
    terminal.scrollTop = terminal.scrollHeight;
  }, 300);
}

// ==========================================
// 17. Error Page
// ==========================================
function renderErrorPage(content, title, message) {
  content.innerHTML = `
    <div class="max-w-md mx-auto py-16 text-center space-y-4">
      <div class="w-16 h-16 mx-auto rounded-2xl bg-red-950/80 border border-red-800 text-red-400 flex items-center justify-center">
        <svg class="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
      </div>
      <h3 class="text-xl font-bold text-white">${title}</h3>
      <p class="text-xs text-slate-400">${message}</p>
      <button onclick="navigate('dashboard')" class="mt-4 px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs transition">
        Return to Dashboard
      </button>
    </div>
  `;
}

// Boot up app on DOM load
window.addEventListener('DOMContentLoaded', initApp);
