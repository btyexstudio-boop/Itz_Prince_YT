// © Author: itsfizys
// https://discord.gg/aerox



const {
    EmbedBuilder,
    PermissionFlagsBits
} = require('discord.js');
const { AutomodConfig, AutomodWhitelist, ModLog } = require('../../data/models');
const { isAuthorizedOwner } = require('../../lib/securityAuth');
const emojis = require('../../emojis.json');

const INVITE_REGEX = /(discord\.(gg|io|me|li)|discordapp\.com\/invite|discord\.com\/invite)\/[a-zA-Z0-9]+/i;
const LINK_REGEX = /(https?:\/\/[^\s]+)/i;

const messageTracker = new Map();

const automodConfigCache = new Map();
const whitelistCache = new Map();
const botMemberCache = new Map();
const AUTOMOD_CACHE_TTL = 30000;
const WHITELIST_CACHE_TTL = 30000;
const BOT_MEMBER_CACHE_TTL = 300000;

function getCachedConfig(guildId) {
    const entry = automodConfigCache.get(guildId);
    if (entry && Date.now() - entry.ts < AUTOMOD_CACHE_TTL) return entry.val;
    return undefined;
}
function setCachedConfig(guildId, val) {
    automodConfigCache.set(guildId, { val, ts: Date.now() });
}

function getCachedWhitelist(guildId, targetId) {
    const key = `${guildId}:${targetId}`;
    const entry = whitelistCache.get(key);
    if (entry && Date.now() - entry.ts < WHITELIST_CACHE_TTL) return entry.val;
    return undefined;
}
function setCachedWhitelist(guildId, targetId, val) {
    whitelistCache.set(`${guildId}:${targetId}`, { val, ts: Date.now() });
}

function getTrackerKey(guildId, userId) {
    return `${guildId}-${userId}`;
}

function trackMessage(guildId, userId) {
    const key = getTrackerKey(guildId, userId);
    const now = Date.now();

    if (!messageTracker.has(key)) {
        messageTracker.set(key, []);
    }

    messageTracker.get(key).push(now);
}

function getMessageCount(guildId, userId, intervalMs) {
    const key = getTrackerKey(guildId, userId);
    const now = Date.now();

    if (!messageTracker.has(key)) {
        return 0;
    }

    const messages = messageTracker.get(key).filter(time => now - time < intervalMs);

    if (messages.length === 0) {
        messageTracker.delete(key);
    } else {
        messageTracker.set(key, messages);
    }

    return messages.length;
}

function cleanupOldMessages() {
    const now = Date.now();
    const maxAge = 7200000;

    for (const [key, times] of messageTracker.entries()) {
        const recentTimes = times.filter(time => now - time < maxAge);
        if (recentTimes.length === 0) {
            messageTracker.delete(key);
        } else if (recentTimes.length !== times.length) {
            messageTracker.set(key, recentTimes);
        }
    }

    const cacheNow = Date.now();
    for (const [key, entry] of automodConfigCache.entries()) {
        if (cacheNow - entry.ts >= AUTOMOD_CACHE_TTL * 10) automodConfigCache.delete(key);
    }
    for (const [key, entry] of whitelistCache.entries()) {
        if (cacheNow - entry.ts >= WHITELIST_CACHE_TTL * 10) whitelistCache.delete(key);
    }
}

async function isWhitelisted(guildId, targetId, targetType, module) {
    let entry = getCachedWhitelist(guildId, targetId);
    if (entry === undefined) {
        entry = await AutomodWhitelist.findOne({ where: { guildId, targetId } });
        setCachedWhitelist(guildId, targetId, entry);
    }
    if (!entry) return false;

    const modules = entry.getModules();
    if (!modules || modules.length === 0) return true;

    return modules.includes(module);
}

async function checkWhitelist(message, module) {
    const guildId = message.guild.id;
    const ids = [message.author.id, ...message.member.roles.cache.keys(), message.channel.id];
    const results = await Promise.all(ids.map(id => isWhitelisted(guildId, id, null, module)));
    return results.some(Boolean);
}

async function getBotMember(guild) {
    const cached = botMemberCache.get(guild.id);
    if (cached && Date.now() - cached.ts < BOT_MEMBER_CACHE_TTL) return cached.val;
    const member = await guild.members.fetch(guild.client.user.id).catch(() => null);
    botMemberCache.set(guild.id, { val: member, ts: Date.now() });
    return member;
}

async function sendLog(guild, config, message, reason, action) {
    if (!config.logChannelId) return;

    try {
        const channel = guild.channels.cache.get(config.logChannelId);
        if (!channel) return;

        const actionLabels = {
            delete: 'Message Deleted',
            warn: 'User Warned',
            mute: 'User Muted',
            kick: 'User Kicked',
            ban: 'User Banned'
        };

        const embed = new EmbedBuilder()
            .setColor(0xED4245)
            .setTitle(`${emojis.warning || '⚠️'} 𝐙𝐨𝐫𝐯𝐢𝐱 𝐀𝐮𝐭𝐨𝐌𝐨𝐝 — Violation Detected`)
            .setDescription(
                `${emojis.user || '👤'} **Offender:** ${message.author.tag} (\`${message.author.id}\`)\n` +
                `${emojis.dots || '•'} **Channel:** <#${message.channel.id}>\n` +
                `${emojis.warning || '⚠️'} **Violation:** ${reason}\n` +
                `${emojis.zap || '⚡'} **Action Enforced:** \`${actionLabels[action] || action}\`\n` +
                `${emojis.timer || '⏱️'} **Time:** <t:${Math.floor(Date.now() / 1000)}:F>`
            )
            .setFooter({ text: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ • 24/7 Shield Engine', iconURL: guild.client.user?.displayAvatarURL?.() })
            .setTimestamp();

        await channel.send({ embeds: [embed] }).catch(() => {});
    } catch (error) {
        console.error('AutoMod log error:', error);
    }
}

async function executePunishment(message, config, reason, moduleName) {
    try {
        await message.delete().catch(() => {});

        const member = message.member;
        if (!member) return;

        const guild = message.guild;
        if (await isAuthorizedOwner(member, guild)) return;

        const botMember = await getBotMember(guild);
        if (!botMember) return;

        if (member.roles.highest.position >= botMember.roles.highest.position) return;

        const punishmentKey = moduleName ? moduleName + 'Punishment' : null;
        const punishment = (punishmentKey && config[punishmentKey]) || config.punishment || 'delete';

        switch (punishment) {
            case 'warn':
                break;
            case 'mute':
                await member.timeout((config.muteDuration || 60) * 1000, `AutoMod: ${reason}`).catch(() => {});
                break;
            case 'kick':
                await member.kick(`AutoMod: ${reason}`).catch(() => {});
                break;
            case 'ban':
                await guild.members.ban(member.id, { reason: `AutoMod: ${reason}` }).catch(() => {});
                break;
        }

        await sendLog(guild, config, message, reason, punishment);

        try {
            await ModLog.create({
                guildId: guild.id,
                moderatorId: guild.client.user.id,
                moderatorTag: guild.client.user.tag,
                targetId: message.author.id,
                targetTag: message.author.tag,
                action: punishment,
                reason: reason,
                channelId: message.channel.id,
                source: 'automod'
            });
        } catch (dbError) {
            console.error('ModLog save error:', dbError.message);
        }
    } catch (error) {
        console.error('AutoMod punishment error:', error);
    }
}

function containsInvite(content) {
    return INVITE_REGEX.test(content);
}

function containsLink(content) {
    return LINK_REGEX.test(content);
}

function containsBadWord(content, badWords) {
    const lowerContent = content.toLowerCase();
    return badWords.some(word => lowerContent.includes(word.toLowerCase()));
}

function getMentionCount(message) {
    return message.mentions.users.size + message.mentions.roles.size;
}

function getCapsPercentage(content) {
    const letters = content.replace(/[^a-zA-Z]/g, '');
    if (letters.length === 0) return 0;
    const caps = letters.replace(/[^A-Z]/g, '').length;
    return (caps / letters.length) * 100;
}

module.exports = {
    name: 'automodEvents',

    async init(client) {
        setInterval(cleanupOldMessages, 300000);
        client.on('messageCreate', async (message) => {
            if (!message.guild) return;
            if (message.author.bot) return;
            if (message.system) return;

            let config = getCachedConfig(message.guild.id);
            if (config === undefined) {
                config = await AutomodConfig.findOne({ where: { guildId: message.guild.id } });
                setCachedConfig(message.guild.id, config);
            }
            if (!config?.enabled) return;

            if (message.member?.permissions.has(PermissionFlagsBits.ManageMessages)) return;

            const content = message.content;

            if (config.antiSpam) {
                if (!await checkWhitelist(message, 'antiSpam')) {
                    trackMessage(message.guild.id, message.author.id);
                    const count = getMessageCount(message.guild.id, message.author.id, config.spamInterval * 1000);

                    if (count > config.spamThreshold) {
                        await executePunishment(message, config, `Spam detected (${count} messages in ${config.spamInterval}s)`, 'antiSpam');
                        return;
                    }
                }
            }

            if (config.antiInvite) {
                if (!await checkWhitelist(message, 'antiInvite')) {
                    if (containsInvite(content)) {
                        await executePunishment(message, config, 'Discord invite link', 'antiInvite');
                        return;
                    }
                }
            }

            if (config.antiLink) {
                if (!await checkWhitelist(message, 'antiLink')) {
                    if (containsLink(content)) {
                        await executePunishment(message, config, 'External link', 'antiLink');
                        return;
                    }
                }
            }

            if (config.antiBadWords) {
                if (!await checkWhitelist(message, 'antiBadWords')) {
                    const badWords = config.getBadWords();
                    if (badWords.length > 0 && containsBadWord(content, badWords)) {
                        await executePunishment(message, config, 'Blacklisted word', 'antiBadWords');
                        return;
                    }
                }
            }

            if (config.antiMassMention) {
                if (!await checkWhitelist(message, 'antiMassMention')) {
                    const mentionCount = getMentionCount(message);
                    if (mentionCount > config.mentionLimit) {
                        await executePunishment(message, config, `Mass mention (${mentionCount} mentions)`, 'antiMassMention');
                        return;
                    }
                }
            }

            if (config.antiPing) {
                if (!await checkWhitelist(message, 'antiPing')) {
                    if (message.mentions.everyone) {
                        await executePunishment(message, config, 'Ping (@everyone / @here)', 'antiPing');
                        return;
                    }
                }
            }

            if (config.antiCaps) {
                if (!await checkWhitelist(message, 'antiCaps')) {
                    if (content.length >= config.capsMinLength) {
                        const capsPercent = getCapsPercentage(content);
                        if (capsPercent > config.capsPercentage) {
                            await executePunishment(message, config, `Excessive caps (${Math.round(capsPercent)}%)`, 'antiCaps');
                            return;
                        }
                    }
                }
            }

            // Extended AutoMod filters
            if (config.antiEmojiSpam) {
                if (!await checkWhitelist(message, 'antiEmojiSpam')) {
                    const customEmojis = (content.match(/<a?:\w+:\d+>/g) || []).length;
                    const unicodeEmojis = (content.match(/[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu) || []).length;
                    const totalEmojis = customEmojis + unicodeEmojis;
                    if (totalEmojis > (config.emojiLimit || 6)) {
                        await executePunishment(message, config, `Emoji spam (${totalEmojis} emojis)`, 'antiEmojiSpam');
                        return;
                    }
                }
            }

            if (config.antiAttachmentSpam) {
                if (!await checkWhitelist(message, 'antiAttachmentSpam')) {
                    if (message.attachments.size > (config.attachmentLimit || 3)) {
                        await executePunishment(message, config, `Attachment spam (${message.attachments.size} files)`, 'antiAttachmentSpam');
                        return;
                    }
                }
            }

            if (config.antiZalgoSpam) {
                if (!await checkWhitelist(message, 'antiZalgoSpam')) {
                    const zalgoRegex = /[\u0300-\u036f\u0483-\u0489\u1dc0-\u1dff\u20d0-\u20ff\u2de0-\u2dff\ua640-\ua69f\ufe20-\ufe2f]{3,}/;
                    if (zalgoRegex.test(content)) {
                        await executePunishment(message, config, 'Zalgo / Glitched text spam', 'antiZalgoSpam');
                        return;
                    }
                }
            }

            if (config.antiCharacterSpam) {
                if (!await checkWhitelist(message, 'antiCharacterSpam')) {
                    if (content.length > (config.characterLimit || 1000)) {
                        await executePunishment(message, config, `Character limit exceeded (${content.length} chars)`, 'antiCharacterSpam');
                        return;
                    }
                }
            }

            if (config.antiNewlineSpam) {
                if (!await checkWhitelist(message, 'antiNewlineSpam')) {
                    const lines = (content.match(/\n/g) || []).length;
                    if (lines > (config.newlineLimit || 8)) {
                        await executePunishment(message, config, `Newline spam (${lines} newlines)`, 'antiNewlineSpam');
                        return;
                    }
                }
            }

            if (config.antiNsfwLink) {
                if (!await checkWhitelist(message, 'antiNsfwLink')) {
                    const nsfwRegex = /(pornhub|xvideos|redtube|xnxx|chaturbate|onlyfans|rule34|hentai|xxx|nsfw)\.[a-z]{2,}/i;
                    if (nsfwRegex.test(content)) {
                        await executePunishment(message, config, 'Suspected adult/NSFW domain link', 'antiNsfwLink');
                        return;
                    }
                }
            }
        });
    }
};

/**
 * Project: Melon
 * Author: itsfizys (Aegis)
 * Organization: AeroX Development
 * GitHub: https://github.com/itsfizys
 * License: Custom
 * © 2026 AeroX Development. All rights reserved.
 */