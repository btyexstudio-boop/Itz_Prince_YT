// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Advanced High-Efficiency Anti-Nuke Shield Engine
const {
    EmbedBuilder,
    AuditLogEvent,
    PermissionFlagsBits,
    ChannelType
} = require('discord.js');
const { AntinukeConfig, AntinukeWhitelist, ExtraOwner, SecurityAuditLog, SecuritySnapshot } = require('../../data/models');
const { getGuildOwnerId, isAuthorizedOwner } = require('../../lib/securityAuth');
const config = require('../../config');
const emojis = require('../../emojis.json');

const actionTracker = new Map();
const pendingPunishments = new Set();
const processedAuditEntries = new Set();
const selfCreatedChannelIds = new Set();
const trustedChannelIds = new Map();
const pendingRecoveries = new Set();
const recentCreatedChannels = new Map();

const antinukeConfigCache = new Map();
const whitelistCache = new Map();
const channelSnapshotCache = new Map();
const roleSnapshotCache = new Map();

const ANTINUKE_CACHE_TTL = 30000;
const WHITELIST_CACHE_TTL = 30000;

function getCachedConfig(guildId) {
    const entry = antinukeConfigCache.get(guildId);
    if (entry && Date.now() - entry.ts < ANTINUKE_CACHE_TTL) return entry.val;
    return undefined;
}
function setCachedConfig(guildId, val) {
    antinukeConfigCache.set(guildId, { val, ts: Date.now() });
}

function getCachedWhitelist(guildId, userId) {
    const key = `${guildId}:${userId}`;
    const entry = whitelistCache.get(key);
    if (entry && Date.now() - entry.ts < WHITELIST_CACHE_TTL) return entry.val;
    return undefined;
}
function setCachedWhitelist(guildId, userId, val) {
    whitelistCache.set(`${guildId}:${userId}`, { val, ts: Date.now() });
}

function getTrackerKey(guildId, userId, action) {
    return `${guildId}-${userId}-${action}`;
}

function trackAction(guildId, userId, action) {
    const key = getTrackerKey(guildId, userId, action);
    const now = Date.now();

    if (!actionTracker.has(key)) {
        actionTracker.set(key, []);
    }

    actionTracker.get(key).push(now);
}

function getActionCount(guildId, userId, action, timeframeMs) {
    const key = getTrackerKey(guildId, userId, action);
    const now = Date.now();

    if (!actionTracker.has(key)) return 0;

    const actions = actionTracker.get(key).filter(time => now - time < timeframeMs);
    if (actions.length === 0) {
        actionTracker.delete(key);
    } else {
        actionTracker.set(key, actions);
    }

    return actions.length;
}

function cleanupOldTrackers() {
    const now = Date.now();
    const maxAge = 3600000;

    for (const [key, times] of actionTracker.entries()) {
        const recentTimes = times.filter(time => now - time < maxAge);
        if (recentTimes.length === 0) {
            actionTracker.delete(key);
        } else if (recentTimes.length !== times.length) {
            actionTracker.set(key, recentTimes);
        }
    }

    if (processedAuditEntries.size > 2000) {
        processedAuditEntries.clear();
    }
}

async function getConfig(guildId) {
    let cfg = getCachedConfig(guildId);
    if (cfg === undefined) {
        cfg = await AntinukeConfig.findOne({ where: { guildId } });
        setCachedConfig(guildId, cfg);
    }
    return cfg;
}

async function isWhitelisted(guildId, userId, eventType = null) {
    let entry = getCachedWhitelist(guildId, userId);
    if (entry === undefined) {
        entry = await AntinukeWhitelist.findOne({ where: { guildId, userId } });
        setCachedWhitelist(guildId, userId, entry);
    }
    if (!entry) return false;

    const events = entry.events;
    if (!events || events.length === 0) return true;

    if (eventType && events.includes(eventType)) return true;

    return !eventType;
}

async function isExempt(guild, user, action = null) {
    if (!user || !guild) return true;
    if (user.id === guild.client.user.id) return true;

    // Check Bot Owner & Global Developers
    const botOwnerId = String(config.OWNER_ID);
    if (String(user.id) === botOwnerId) return true;
    if (Array.isArray(config.DEVELOPER_IDS) && config.DEVELOPER_IDS.includes(String(user.id))) return true;

    // Check Real Server Owner
    const ownerId = await getGuildOwnerId(guild);
    if (ownerId && String(user.id) === String(ownerId)) return true;

    // Check Extra Owner ONLY
    try {
        const isExtra = await ExtraOwner.isExtraOwner(guild.id, String(user.id));
        if (isExtra) return true;
    } catch (_) {}

    // Check Whitelist
    if (await isWhitelisted(guild.id, user.id, action)) return true;

    // NON-EXTRA OWNERS AND REGULAR ADMINISTRATORS ARE STRICTLY NOT EXEMPT FROM ANTI-NUKE DESTRUCTIVE ACTIONS!
    return false;
}

/**
 * Fetch Audit Log Entry with Bounded Backoff Retries to handle Discord API delays.
 */
async function getAuditLogExecutorWithRetry(guild, auditType, targetId = null, maxRetries = 5, initialDelayMs = 0) {
    if (!guild || !guild.members.me?.permissions.has(PermissionFlagsBits.ViewAuditLog)) {
        return { executor: null, entry: null };
    }

    let delay = initialDelayMs || 50;

    for (let attempt = 0; attempt < maxRetries; attempt++) {
        try {
            const auditLogs = await guild.fetchAuditLogs({ type: auditType, limit: 6 });
            const now = Date.now();

            for (const entry of auditLogs.entries.values()) {
                if ((now - entry.createdTimestamp) < 30000) {
                    const entryTargetId = entry.target?.id || entry.targetId;
                    const matchesTarget = !targetId || entryTargetId === targetId;
                    if (matchesTarget && entry.executor) {
                        return { executor: entry.executor, entry };
                    }
                }
            }
        } catch (_) {}

        if (attempt < maxRetries - 1) {
            await new Promise(r => setTimeout(r, delay));
            delay = Math.min(delay * 2, 800);
        }
    }

    // Fallback: Fetch most recent audit log entry for this auditType in last 15s
    try {
        const auditLogs = await guild.fetchAuditLogs({ type: auditType, limit: 3 });
        for (const entry of auditLogs.entries.values()) {
            if (entry.executor && (Date.now() - entry.createdTimestamp) < 15000) {
                return { executor: entry.executor, entry };
            }
        }
    } catch (_) {}

    return { executor: null, entry: null };
}

function trackRecentChannelCreate(guildId, channel) {
    const now = Date.now();
    if (!recentCreatedChannels.has(guildId)) {
        recentCreatedChannels.set(guildId, []);
    }
    const list = recentCreatedChannels.get(guildId).filter(item => now - item.timestamp < 10000);
    list.push({ channelId: channel.id, timestamp: now });
    recentCreatedChannels.set(guildId, list);
    return list.length;
}

/**
 * Detect if a channel or snapshot represents a support ticket, order, application, or modmail channel
 */
function isTicketChannel(channel) {
    if (!channel || !channel.name) return false;
    const rawName = String(channel.name || '');
    // Normalize: remove non-alphanumeric except dashes/underscores for clean matching
    const cleanName = rawName.toLowerCase().replace(/[^\w\s-]/g, '').trim();

    // 1. Direct name patterns & keywords
    const ticketKeywords = [
        'ticket', 'tickets', 'tkt', 'support', 'order', 'orders',
        'claim', 'billing', 'appeal', 'apply', 'application',
        'modmail', 'report', 'donation', 'donate', 'transcript',
        'closed', 'close', 'help-desk', 'helpdesk'
    ];

    if (ticketKeywords.some(kw => cleanName.startsWith(kw) || cleanName.includes(kw))) {
        return true;
    }

    // Pattern like t-0001 or t_0001 or 0001-ticket
    if (/^t[-_]\d+/i.test(cleanName) || /\d+[-_]ticket/i.test(cleanName)) {
        return true;
    }

    // 2. Parent Category name check
    if (channel.parent) {
        const parentName = String(channel.parent.name || '').toLowerCase();
        const parentClean = parentName.replace(/[^\w\s-]/g, '').trim();
        const catKeywords = ['ticket', 'support', 'order', 'modmail', 'appeal', 'billing', 'apply', 'desk', 'customer', 'inquiry', 'claim'];
        if (catKeywords.some(kw => parentName.includes(kw) || parentClean.includes(kw))) {
            return true;
        }
    }

    // 3. Topic check
    if (channel.topic) {
        const topic = String(channel.topic).toLowerCase();
        const topicKeywords = ['ticket', 'opened by', 'ticket id', 'ticket-id', 'support', 'ticket tool', 'transcript', 'user id', 'claimed by', 'creator:'];
        if (topicKeywords.some(kw => topic.includes(kw))) {
            return true;
        }
    }

    // 4. Overwrite check: @everyone denied ViewChannel and specific member allowed
    try {
        if (channel.permissionOverwrites?.cache) {
            const everyoneOw = channel.permissionOverwrites.cache.get(channel.guild?.id);
            if (everyoneOw && everyoneOw.deny?.has?.(PermissionFlagsBits.ViewChannel)) {
                for (const [id, ow] of channel.permissionOverwrites.cache) {
                    if (id !== channel.guild?.id && ow.allow?.has?.(PermissionFlagsBits.ViewChannel)) {
                        const member = channel.guild?.members?.cache?.get(id);
                        if (member && !member.user.bot) {
                            return true;
                        }
                    }
                }
            }
        }
    } catch (_) {}

    return false;
}

/**
 * Sweep and purge any unauthorized random spam channels created during an attack
 */
async function sweepAndPurgeRogueChannels(guild, attacker = null) {
    if (!guild || !guild.members.me?.permissions.has(PermissionFlagsBits.ManageChannels)) return;
    try {
        const trustedSet = trustedChannelIds.get(guild.id) || new Set();
        const now = Date.now();
        const channelsToDelete = [];

        for (const [id, ch] of guild.channels.cache) {
            if (selfCreatedChannelIds.has(id)) continue;
            // NEVER delete ticket channels
            if (isTicketChannel(ch)) continue;

            const isUntrusted = !trustedSet.has(id);
            const isRecent = (now - ch.createdTimestamp) < 300000;

            if (isUntrusted && isRecent) {
                channelsToDelete.push(ch);
            }
        }

        for (const ch of channelsToDelete) {
            await ch.delete('𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Mass purge unauthorized random nuke spam channel').catch(() => {});
        }

        if (channelsToDelete.length > 0) {
            console.log(`[ANTINUKE] Purged ${channelsToDelete.length} unauthorized spam channels in ${guild.name} (${guild.id})`);
        }
    } catch (err) {
        console.error('[ANTINUKE] Sweep channels error:', err.message);
    }
}

/**
 * Automatically restore any channels deleted during a nuke attack
 */
async function restoreAllMissingChannels(guild, attacker = null) {
    if (!guild || !guild.members.me?.permissions.has(PermissionFlagsBits.ManageChannels)) return;
    try {
        const config = await getConfig(guild.id);
        if (!config || config.autoRecovery === false) return;

        const snapshots = await SecuritySnapshot.findAll({
            where: { guildId: guild.id, type: 'channel' }
        });

        // Filter missing channels
        const missing = snapshots.filter(s => !guild.channels.cache.has(s.targetId));

        // Prioritize restoring categories first so child channels can link to them
        missing.sort((a, b) => {
            const aData = a.getSnapshotData?.() || JSON.parse(a.data || '{}');
            const bData = b.getSnapshotData?.() || JSON.parse(b.data || '{}');
            const aIsCat = aData.type === ChannelType.GuildCategory ? 1 : 0;
            const bIsCat = bData.type === ChannelType.GuildCategory ? 1 : 0;
            return bIsCat - aIsCat;
        });

        for (const snapRecord of missing) {
            const channelId = snapRecord.targetId;
            const snapData = snapRecord.getSnapshotData?.() || JSON.parse(snapRecord.data || '{}');
            if (isTicketChannel(snapData)) continue;

            const recKey = `${guild.id}:${channelId}`;
            if (pendingRecoveries.has(recKey)) continue;
            pendingRecoveries.add(recKey);
            setTimeout(() => pendingRecoveries.delete(recKey), 15000);

            await recoverChannel(guild, channelId, snapRecord.name, attacker);
        }
    } catch (err) {
        console.error('[ANTINUKE] Restore all channels error:', err.message);
    }
}

/**
 * Proactively capture complete server channel and role snapshot
 */
async function takeFullServerSnapshot(guild) {
    if (!guild || !guild.channels) return;
    try {
        if (!trustedChannelIds.has(guild.id)) {
            trustedChannelIds.set(guild.id, new Set());
        }
        const trustedSet = trustedChannelIds.get(guild.id);

        for (const channel of guild.channels.cache.values()) {
            trustedSet.add(channel.id);
            await saveChannelSnapshot(channel);
        }

        for (const role of guild.roles.cache.values()) {
            await saveRoleSnapshot(role);
        }
    } catch (err) {
        console.error('[ANTINUKE] Full snapshot error:', err.message);
    }
}

/**
 * Save Snapshot of Channel for Auto-Recovery
 */
async function saveChannelSnapshot(channel) {
    if (!channel || !channel.guild) return;
    try {
        const overwrites = channel.permissionOverwrites?.cache?.map(o => ({
            id: o.id,
            type: o.type,
            allow: o.allow.bitfield.toString(),
            deny: o.deny.bitfield.toString()
        })) || [];

        const snapData = {
            name: channel.name,
            type: channel.type,
            topic: channel.topic || null,
            parentId: channel.parentId || null,
            position: channel.position,
            rateLimitPerUser: channel.rateLimitPerUser || 0,
            nsfw: channel.nsfw || false,
            bitrate: channel.bitrate || null,
            userLimit: channel.userLimit || null,
            permissionOverwrites: overwrites
        };

        const key = `${channel.guild.id}:${channel.id}`;
        channelSnapshotCache.set(key, snapData);

        await SecuritySnapshot.upsert({
            guildId: channel.guild.id,
            targetId: channel.id,
            type: 'channel',
            name: channel.name,
            data: JSON.stringify(snapData)
        }).catch(() => {});
    } catch (_) {}
}

/**
 * Save Snapshot of Role for Auto-Recovery
 */
async function saveRoleSnapshot(role) {
    if (!role || !role.guild || role.managed || role.id === role.guild.id) return;
    try {
        const snapData = {
            name: role.name,
            color: role.color,
            hoist: role.hoist,
            position: role.position,
            permissions: role.permissions.bitfield.toString(),
            mentionable: role.mentionable
        };

        const key = `${role.guild.id}:${role.id}`;
        roleSnapshotCache.set(key, snapData);

        await SecuritySnapshot.upsert({
            guildId: role.guild.id,
            targetId: role.id,
            type: 'role',
            name: role.name,
            data: JSON.stringify(snapData)
        }).catch(() => {});
    } catch (_) {}
}

/**
 * Recreate Deleted Channel from Saved Snapshot
 */
async function recoverChannel(guild, channelId, fallbackName = 'recovered-channel', attackerUser = null) {
    try {
        const key = `${guild.id}:${channelId}`;
        let snap = channelSnapshotCache.get(key);

        if (!snap) {
            const dbRecord = await SecuritySnapshot.findOne({
                where: { guildId: guild.id, targetId: channelId, type: 'channel' }
            });
            if (dbRecord) snap = dbRecord.getSnapshotData();
        }

        let recreated = null;
        if (!snap) {
            recreated = await guild.channels.create({
                name: fallbackName,
                type: ChannelType.GuildText,
                reason: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Anti-Nuke Recovery (No saved snapshot)'
            }).catch(() => null);
        } else {
            const isCategory = snap.type === ChannelType.GuildCategory;
            const options = {
                name: snap.name,
                type: snap.type,
                position: snap.position,
                reason: `𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Anti-Nuke Channel/Category Auto-Recovery`
            };

            if (!isCategory) {
                options.topic = snap.topic;
                options.parent = snap.parentId;
                options.rateLimitPerUser = snap.rateLimitPerUser;
                options.nsfw = snap.nsfw;
                if (snap.bitrate) options.bitrate = snap.bitrate;
                if (snap.userLimit) options.userLimit = snap.userLimit;
            }

            recreated = await guild.channels.create(options).catch(() => null);

            if (recreated && snap.permissionOverwrites && Array.isArray(snap.permissionOverwrites)) {
                for (const ow of snap.permissionOverwrites) {
                    try {
                        await recreated.permissionOverwrites.edit(ow.id, {
                            allow: BigInt(ow.allow),
                            deny: BigInt(ow.deny)
                        }).catch(() => {});
                    } catch (_) {}
                }
            }
        }

        if (recreated) {
            selfCreatedChannelIds.add(recreated.id);
            if (!trustedChannelIds.has(guild.id)) {
                trustedChannelIds.set(guild.id, new Set());
            }
            trustedChannelIds.get(guild.id).add(recreated.id);
            await saveChannelSnapshot(recreated);

            return `Recreated <#${recreated.id}> with saved permissions & structure.`;
        }

        return 'Failed (Missing Manage Channels permission)';
    } catch (err) {
        return `Recovery attempt failed: ${err.message}`;
    }
}

/**
 * Recreate Deleted Role from Saved Snapshot
 */
async function recoverRole(guild, roleId, fallbackName = 'recovered-role') {
    try {
        const key = `${guild.id}:${roleId}`;
        let snap = roleSnapshotCache.get(key);

        if (!snap) {
            const dbRecord = await SecuritySnapshot.findOne({
                where: { guildId: guild.id, targetId: roleId, type: 'role' }
            });
            if (dbRecord) snap = dbRecord.getSnapshotData();
        }

        if (!snap) {
            const created = await guild.roles.create({
                name: fallbackName,
                reason: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Anti-Nuke Role Recovery (No saved snapshot)'
            }).catch(() => null);
            return created ? `Recreated role @${created.name}` : 'Failed (Missing Manage Roles permission)';
        }

        const recreated = await guild.roles.create({
            name: snap.name,
            color: snap.color,
            hoist: snap.hoist,
            permissions: BigInt(snap.permissions || '0'),
            mentionable: snap.mentionable,
            reason: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Anti-Nuke Role Auto-Recovery'
        });

        return `Recreated role <@&${recreated.id}> with saved permissions & hierarchy options.`;
    } catch (err) {
        return `Recovery attempt failed: ${err.message}`;
    }
}

/**
 * Execute Containment Policy & Punish Offender
 * CRITICAL FIX: If offender is a BOT or if target performed channel/role nuke, BAN INSTANTLY.
 * Never silently fail due to role hierarchy — always BAN if bot has Ban Members permission!
 */
async function executePunishment(guild, user, cfg, reason, recoveryStatus = null) {
    try {
        if (await isExempt(guild, user)) return;

        const isBot = user.bot === true;
        const isNukeAction = reason.toLowerCase().includes('channel') || reason.toLowerCase().includes('role') || reason.toLowerCase().includes('bot') || reason.toLowerCase().includes('ban');

        // Dry Run check
        if (cfg.dryRun) {
            await sendLog(guild, cfg, user, `[SIMULATED] ${reason}`, 'dry_run', recoveryStatus);
            return;
        }

        // BOTS or CRITICAL NUKE ACTIONS MUST BE BANNED INSTANTLY
        if (isBot || cfg.punishment === 'ban' || (isNukeAction && cfg.strict !== false)) {
            const banned = await guild.members.ban(user.id, { reason: `𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ Anti-Nuke: ${reason}` }).catch(() => null);
            if (banned) {
                await recordLogAndAlert(guild, cfg, user, reason, 'ban', recoveryStatus);
                return;
            }
        }

        const member = await guild.members.fetch(user.id).catch(() => null);
        const botMember = guild.members.me;

        if (member && botMember) {
            // Attempt Role Stripping
            if (cfg.punishment === 'stripall' || !cfg.punishment) {
                const rolesToRemove = member.roles.cache
                    .filter(r => r.id !== guild.id && r.position < botMember.roles.highest.position);

                if (rolesToRemove.size > 0) {
                    await member.roles.remove(rolesToRemove, `𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: ${reason}`).catch(() => {});
                }

                // Fail-safe: If member still has Administrator or Manage Guild perms after stripping, BAN THEM!
                const recheckMember = await guild.members.fetch(user.id).catch(() => null);
                if (recheckMember && recheckMember.permissions.has(PermissionFlagsBits.Administrator)) {
                    await guild.members.ban(user.id, { reason: `𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ Fail-Safe Ban: ${reason}` }).catch(() => {});
                    await recordLogAndAlert(guild, cfg, user, reason, 'ban', recoveryStatus);
                    return;
                }

                await recordLogAndAlert(guild, cfg, user, reason, 'stripall', recoveryStatus);
                return;
            }

            if (cfg.punishment === 'kick') {
                await member.kick(`𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: ${reason}`).catch(() => {});
                await recordLogAndAlert(guild, cfg, user, reason, 'kick', recoveryStatus);
                return;
            }
        }

        // Final Fallback: Force ban if target could not be kicked or stripped
        await guild.members.ban(user.id, { reason: `𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ Fallback Ban: ${reason}` }).catch(() => {});
        await recordLogAndAlert(guild, cfg, user, reason, 'ban', recoveryStatus);
    } catch {}
}

async function recordLogAndAlert(guild, cfg, user, reason, punishment, recoveryStatus) {
    try {
        await SecurityAuditLog.create({
            guildId: guild.id,
            module: 'ANTINUKE',
            action: punishment,
            executorId: user.id,
            targetId: user.id,
            reason,
            details: { recoveryStatus }
        }).catch(() => {});
    } catch (_) {}

    await sendLog(guild, cfg, user, reason, punishment, recoveryStatus);
}

async function sendLog(guild, cfg, user, reason, punishment, recoveryStatus = null) {
    if (!cfg?.logChannelId) return;

    try {
        const channel = guild.channels.cache.get(cfg.logChannelId);
        if (!channel) return;

        const punishmentLabels = {
            stripall: 'Administrative Roles Stripped',
            kick: 'Kicked From Guild',
            ban: 'Permanently Banned',
            dry_run: 'Simulated Warning (Dry Run)'
        };

        const embed = new EmbedBuilder()
            .setColor(0xED4245)
            .setTitle(`${emojis.shield || '🛡️'} 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Anti-Nuke Threat Neutralized`)
            .setDescription(
                `${emojis.warning || '⚠️'} **Nuke Attack Detected & Stopped!**\n\n` +
                `${emojis.user || '👤'} **Offender:** ${user.tag || user.username} (\`${user.id}\`) ${user.bot ? '🤖 [BOT]' : '👤 [USER]'}\n` +
                `${emojis.dots || '•'} **Violation:** ${reason}\n` +
                `${emojis.zap || '⚡'} **Containment Action:** \`${punishmentLabels[punishment] || punishment}\`\n` +
                (recoveryStatus ? `${emojis.check || '✅'} **Auto-Recovery Status:** ${recoveryStatus}\n` : '') +
                `${emojis.timer || '⏱️'} **Time:** <t:${Math.floor(Date.now() / 1000)}:F> (<t:${Math.floor(Date.now() / 1000)}:R>)`
            )
            .setFooter({ text: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ • 24/7 Shield Engine', iconURL: guild.client.user?.displayAvatarURL?.() })
            .setTimestamp();

        await channel.send({ embeds: [embed] }).catch(() => {});
    } catch {}
}

async function handleAntiAction(guild, executor, action, cfg, recoveryStatus = null) {
    if (!executor) return;
    if (await isExempt(guild, executor, action)) return;

    trackAction(guild.id, executor.id, action);
    const count = getActionCount(guild.id, executor.id, action, (cfg.timeframe || 60) * 1000);

    const isDestructive = ['channel_delete', 'channel_create', 'role_delete', 'role_create', 'webhook_create', 'bot_add', 'guild_update'].includes(action);
    const threshold = (cfg.strict !== false || isDestructive || executor.bot) ? 1 : (cfg.threshold || 3);

    if (count >= threshold) {
        const punishKey = `${guild.id}:${executor.id}`;
        if (pendingPunishments.has(punishKey)) return;
        pendingPunishments.add(punishKey);
        setTimeout(() => pendingPunishments.delete(punishKey), 10000);

        await executePunishment(
            guild,
            executor,
            cfg,
            `Unauthorized ${action.replace('_', ' ')} detected (${count} action${count > 1 ? 's' : ''})`,
            recoveryStatus
        );
    }
}

module.exports = {
    name: 'antinukeEvents',

    async init(client) {
        setInterval(cleanupOldTrackers, 300000);

        const runFullSnapshots = async () => {
            for (const guild of client.guilds.cache.values()) {
                await takeFullServerSnapshot(guild);
            }
        };

        if (client.isReady && client.isReady()) {
            runFullSnapshots().catch(() => {});
        }
        client.on('ready', () => {
            runFullSnapshots().catch(() => {});
        });
        setInterval(runFullSnapshots, 600000);

        client.on('guildBanAdd', async (ban) => {
            const config = await getConfig(ban.guild.id);
            if (!config?.enabled || !config.antiBan) return;

            const { executor } = await getAuditLogExecutorWithRetry(ban.guild, AuditLogEvent.MemberBanAdd, ban.user.id);
            await handleAntiAction(ban.guild, executor, 'ban', config);
        });

        client.on('guildMemberRemove', async (member) => {
            const config = await getConfig(member.guild.id);
            if (!config?.enabled || !config.antiKick) return;

            const { executor } = await getAuditLogExecutorWithRetry(member.guild, AuditLogEvent.MemberKick, member.id);
            if (executor) {
                await handleAntiAction(member.guild, executor, 'kick', config);
            }
        });

        // CHANNEL CREATION HANDLER: If unauthorized channel created (e.g. channel nuke re-creation), delete channel & ban attacker!
        client.on('channelCreate', async (channel) => {
            if (!channel.guild) return;

            // If this channel was just created by our own auto-recovery system, mark trusted and ignore
            if (selfCreatedChannelIds.has(channel.id)) {
                selfCreatedChannelIds.delete(channel.id);
                if (!trustedChannelIds.has(channel.guild.id)) {
                    trustedChannelIds.set(channel.guild.id, new Set());
                }
                trustedChannelIds.get(channel.guild.id).add(channel.id);
                await saveChannelSnapshot(channel);
                return;
            }

            // TICKET PROTECTION: Automatically recognize and protect support/ticket channels (Ticket Tool, Tickets, Ticketmaster, ModMail, etc.)
            if (isTicketChannel(channel)) {
                if (!trustedChannelIds.has(channel.guild.id)) {
                    trustedChannelIds.set(channel.guild.id, new Set());
                }
                trustedChannelIds.get(channel.guild.id).add(channel.id);
                await saveChannelSnapshot(channel);
                return;
            }

            const config = await getConfig(channel.guild.id);
            if (!config?.enabled || config.antiChannelCreate === false) {
                await saveChannelSnapshot(channel);
                return;
            }

            const { executor } = await getAuditLogExecutorWithRetry(channel.guild, AuditLogEvent.ChannelCreate, channel.id);
            if (executor) {
                // If creator is a ticket bot or support bot, allow creation and add to trusted channels
                const isTicketBot = executor.bot && (
                    (executor.username || '').toLowerCase().includes('ticket') ||
                    (executor.tag || '').toLowerCase().includes('ticket') ||
                    (executor.username || '').toLowerCase().includes('modmail') ||
                    (executor.username || '').toLowerCase().includes('support')
                );

                if (isTicketBot || await isExempt(channel.guild, executor, 'channel_create')) {
                    // Authorized creation (Real Owner, Extra Owner, Whitelisted, or Ticket Bot)
                    if (!trustedChannelIds.has(channel.guild.id)) {
                        trustedChannelIds.set(channel.guild.id, new Set());
                    }
                    trustedChannelIds.get(channel.guild.id).add(channel.id);
                    await saveChannelSnapshot(channel);
                    return;
                }

                // UNAUTHORIZED CHANNEL CREATION (Nuke Attack / Admin abuse / Bot abuse)
                // 1. Delete unauthorized channel immediately
                await channel.delete('𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Unauthorized channel creation (Anti-Nuke)').catch(() => {});
                // 2. Ban attacker immediately (even if Administrator or Bot)
                await channel.guild.members.ban(executor.id, { reason: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Unauthorized channel creation (Anti-Nuke)' }).catch(() => {});
                // 3. Purge any other rogue channels created in this nuke burst
                await sweepAndPurgeRogueChannels(channel.guild, executor);
                // 4. Restore any missing legitimate channels
                if (config.autoRecovery !== false) {
                    await restoreAllMissingChannels(channel.guild, executor);
                }
                await handleAntiAction(channel.guild, executor, 'channel_create', config, 'Deleted unauthorized channel(s), swept rogue channels & banned attacker');
            } else {
                // Audit log not immediately ready: check burst volume
                const burstCount = trackRecentChannelCreate(channel.guild.id, channel);
                const isTrusted = trustedChannelIds.has(channel.guild.id) && trustedChannelIds.get(channel.guild.id).has(channel.id);

                if (!isTrusted && burstCount >= 2) {
                    // Rapid rogue channel creation detected!
                    await channel.delete('𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Rapid unauthorized channel creation detected').catch(() => {});
                    await sweepAndPurgeRogueChannels(channel.guild, null);
                    if (config.autoRecovery !== false) {
                        await restoreAllMissingChannels(channel.guild, null);
                    }

                    // Background retry to ban attacker
                    setTimeout(async () => {
                        const lateAudit = await getAuditLogExecutorWithRetry(channel.guild, AuditLogEvent.ChannelCreate, channel.id, 5, 200);
                        if (lateAudit.executor && !await isExempt(channel.guild, lateAudit.executor, 'channel_create')) {
                            await channel.guild.members.ban(lateAudit.executor.id, { reason: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Unauthorized channel nuke creation' }).catch(() => {});
                            await handleAntiAction(channel.guild, lateAudit.executor, 'channel_create', config, 'Deleted rogue channels & banned attacker');
                        }
                    }, 500);
                }
            }
        });

        // CHANNEL DELETION HANDLER: If channel deleted, recover channel from snapshot & ban attacker!
        client.on('channelDelete', async (channel) => {
            if (!channel.guild) return;

            // TICKET PROTECTION: Closed/resolved tickets being deleted by a bot or staff member should not trigger anti-nuke
            if (isTicketChannel(channel)) {
                if (trustedChannelIds.has(channel.guild.id)) {
                    trustedChannelIds.get(channel.guild.id).delete(channel.id);
                }
                return;
            }

            const config = await getConfig(channel.guild.id);
            if (!config?.enabled || !config.antiChannelDelete) return;

            const { executor } = await getAuditLogExecutorWithRetry(channel.guild, AuditLogEvent.ChannelDelete, channel.id);
            if (executor) {
                if (await isExempt(channel.guild, executor, 'channel_delete')) {
                    // Legitimate deletion by Server Owner or Extra Owner
                    if (trustedChannelIds.has(channel.guild.id)) {
                        trustedChannelIds.get(channel.guild.id).delete(channel.id);
                    }
                    return;
                }

                // Instantly ban unauthorized actor
                await channel.guild.members.ban(executor.id, { reason: `𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ Anti-Nuke: Unauthorized channel deletion (${channel.name})` }).catch(() => {});

                let recoveryMsg = null;
                if (config.autoRecovery !== false) {
                    recoveryMsg = await recoverChannel(channel.guild, channel.id, channel.name, executor);
                    await sweepAndPurgeRogueChannels(channel.guild, executor);
                    await restoreAllMissingChannels(channel.guild, executor);
                }
                await handleAntiAction(channel.guild, executor, 'channel_delete', config, recoveryMsg);
            } else {
                // If executor not returned immediately due to Discord lag, still trigger recovery & purge
                if (config.autoRecovery !== false) {
                    await recoverChannel(channel.guild, channel.id, channel.name, null);
                    await sweepAndPurgeRogueChannels(channel.guild, null);
                    await restoreAllMissingChannels(channel.guild, null);
                }

                setTimeout(async () => {
                    const lateAudit = await getAuditLogExecutorWithRetry(channel.guild, AuditLogEvent.ChannelDelete, channel.id, 5, 200);
                    if (lateAudit.executor && !await isExempt(channel.guild, lateAudit.executor, 'channel_delete')) {
                        await channel.guild.members.ban(lateAudit.executor.id, { reason: `𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Unauthorized channel deletion (${channel.name})` }).catch(() => {});
                        await handleAntiAction(channel.guild, lateAudit.executor, 'channel_delete', config, `Recovered channel & banned attacker`);
                    }
                }, 500);
            }
        });

        client.on('roleCreate', async (role) => {
            const config = await getConfig(role.guild.id);
            if (!config?.enabled || !config.antiRoleCreate) {
                await saveRoleSnapshot(role);
                return;
            }

            const { executor } = await getAuditLogExecutorWithRetry(role.guild, AuditLogEvent.RoleCreate, role.id);
            if (executor) {
                if (await isExempt(role.guild, executor, 'role_create')) {
                    await saveRoleSnapshot(role);
                    return;
                }

                // UNAUTHORIZED ROLE CREATION
                // 1. Delete unauthorized role immediately
                await role.delete('𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Unauthorized role creation').catch(() => {});
                // 2. Ban attacker immediately
                await role.guild.members.ban(executor.id, {
                    reason: `𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ Anti-Nuke: Unauthorized role creation (${role.name})`
                }).catch(() => {});
                await handleAntiAction(role.guild, executor, 'role_create', config, 'Deleted unauthorized role & banned attacker');
            }
        });

        client.on('roleDelete', async (role) => {
            const config = await getConfig(role.guild.id);
            if (!config?.enabled || !config.antiRoleDelete) return;

            const { executor } = await getAuditLogExecutorWithRetry(role.guild, AuditLogEvent.RoleDelete, role.id);
            if (executor) {
                if (await isExempt(role.guild, executor, 'role_delete')) return;

                // 1. INSTANT BAN the unauthorized attacker
                await role.guild.members.ban(executor.id, {
                    reason: `𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ Anti-Nuke: Unauthorized role deletion (${role.name})`
                }).catch(() => {});

                // 2. INSTANT RECREATE role from saved snapshot
                let recoveryMsg = null;
                if (config.autoRecovery !== false) {
                    recoveryMsg = await recoverRole(role.guild, role.id, role.name);
                }
                await handleAntiAction(role.guild, executor, 'role_delete', config, recoveryMsg);
            } else {
                // If executor not returned immediately due to Discord lag, still trigger recovery immediately
                if (config.autoRecovery !== false) {
                    await recoverRole(role.guild, role.id, role.name);
                }

                setTimeout(async () => {
                    const lateAudit = await getAuditLogExecutorWithRetry(role.guild, AuditLogEvent.RoleDelete, role.id, 5, 200);
                    if (lateAudit.executor && !await isExempt(role.guild, lateAudit.executor, 'role_delete')) {
                        await role.guild.members.ban(lateAudit.executor.id, {
                            reason: `𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Unauthorized role deletion (${role.name})`
                        }).catch(() => {});
                        await handleAntiAction(role.guild, lateAudit.executor, 'role_delete', config, `Recovered role & banned attacker`);
                    }
                }, 500);
            }
        });

        client.on('roleUpdate', async (oldRole, newRole) => {
            // If we are currently reverting this role, ignore to prevent feedback loop
            const revertKey = `reverting_role:${newRole.id}`;
            if (pendingPunishments.has(revertKey)) return;

            const config = await getConfig(newRole.guild.id);
            if (!config?.enabled || !config.antiRoleUpdate) {
                await saveRoleSnapshot(newRole);
                return;
            }

            const nameChanged = oldRole.name !== newRole.name;
            const colorChanged = oldRole.color !== newRole.color;
            const permsChanged = oldRole.permissions.bitfield !== newRole.permissions.bitfield;
            const hoistChanged = oldRole.hoist !== newRole.hoist;
            const mentionableChanged = oldRole.mentionable !== newRole.mentionable;

            if (!nameChanged && !colorChanged && !permsChanged && !hoistChanged && !mentionableChanged) {
                return;
            }

            const { executor } = await getAuditLogExecutorWithRetry(newRole.guild, AuditLogEvent.RoleUpdate, newRole.id);
            if (executor) {
                if (await isExempt(newRole.guild, executor, 'role_update')) {
                    await saveRoleSnapshot(newRole);
                    return;
                }

                // UNAUTHORIZED ROLE EDIT
                // 1. Mark revert key
                pendingPunishments.add(revertKey);
                setTimeout(() => pendingPunishments.delete(revertKey), 5000);

                // 2. INSTANT BAN the attacker
                await newRole.guild.members.ban(executor.id, {
                    reason: `𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ Anti-Nuke: Unauthorized role edit (${oldRole.name} -> ${newRole.name})`
                }).catch(() => {});

                // 3. INSTANT REVERT role back to previous state
                await newRole.edit({
                    name: oldRole.name,
                    color: oldRole.color,
                    hoist: oldRole.hoist,
                    permissions: oldRole.permissions,
                    mentionable: oldRole.mentionable,
                    reason: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Reverted unauthorized role edit'
                }).catch(() => {});

                await handleAntiAction(newRole.guild, executor, 'role_update', config, 'Reverted role edit & banned attacker');
            } else {
                // If delayed audit log and name or permissions changed
                if (nameChanged || permsChanged) {
                    pendingPunishments.add(revertKey);
                    setTimeout(() => pendingPunishments.delete(revertKey), 5000);
                    await newRole.edit({
                        name: oldRole.name,
                        permissions: oldRole.permissions,
                        reason: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Auto-reverted unauthorized role change'
                    }).catch(() => {});

                    setTimeout(async () => {
                        const lateAudit = await getAuditLogExecutorWithRetry(newRole.guild, AuditLogEvent.RoleUpdate, newRole.id, 5, 200);
                        if (lateAudit.executor && !await isExempt(newRole.guild, lateAudit.executor, 'role_update')) {
                            await newRole.guild.members.ban(lateAudit.executor.id, {
                                reason: `𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Unauthorized role edit`
                            }).catch(() => {});
                            await handleAntiAction(newRole.guild, lateAudit.executor, 'role_update', config, 'Reverted role edit & banned attacker');
                        }
                    }, 500);
                }
            }
        });

        client.on('webhookCreate', async (webhook) => {
            const config = await getConfig(webhook.guildId);
            if (!config?.enabled || !config.antiWebhook) return;

            const guild = client.guilds.cache.get(webhook.guildId);
            if (!guild) return;

            const { executor } = await getAuditLogExecutorWithRetry(guild, AuditLogEvent.WebhookCreate, webhook.id);
            if (executor && !await isExempt(guild, executor, 'webhook_create')) {
                try {
                    await webhook.delete('𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Deleted unauthorized webhook').catch(() => {});
                } catch (_) {}
                await handleAntiAction(guild, executor, 'webhook_create', config, 'Deleted unauthorized webhook');
            }
        });

        client.on('guildMemberAdd', async (member) => {
            if (!member.user.bot) return;

            const config = await getConfig(member.guild.id);
            if (!config?.enabled || config.antiBot === false) return;

            const { executor } = await getAuditLogExecutorWithRetry(member.guild, AuditLogEvent.BotAdd, member.id);
            if (!executor || !await isExempt(member.guild, executor, 'bot_add')) {
                // INSTANTLY BAN THE ROGUE BOT BEFORE IT CAN PROCESS ANY DISCORD API CALL
                await member.ban({ reason: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Unauthorized nuke bot join (Anti-Nuke)' }).catch(async () => {
                    await member.kick('𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Unauthorized nuke bot join (Anti-Nuke)').catch(() => {});
                });

                // INSTANTLY BAN THE INVITER (EVEN IF ADMINISTRATOR)
                if (executor && !await isExempt(member.guild, executor, 'bot_add')) {
                    await member.guild.members.ban(executor.id, { reason: `𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Invited unauthorized bot (${member.user.tag})` }).catch(() => {});
                }

                await executePunishment(member.guild, executor || member.user, config, `Unauthorized bot addition: ${member.user.tag}`, `Permanently banned unauthorized bot <@${member.id}> and inviter`);
            }
        });

        client.on('guildMemberUpdate', async (oldMember, newMember) => {
            const config = await getConfig(newMember.guild.id);
            if (!config?.enabled || config.antiPermissionEscalation === false) return;

            const dangerousPerms = [
                PermissionFlagsBits.Administrator,
                PermissionFlagsBits.ManageGuild,
                PermissionFlagsBits.ManageRoles,
                PermissionFlagsBits.BanMembers
            ];

            const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
            if (addedRoles.size === 0) return;

            const dangerousRolesAdded = addedRoles.filter(role =>
                dangerousPerms.some(perm => role.permissions.has(perm))
            );

            if (dangerousRolesAdded.size === 0) return;

            const { executor } = await getAuditLogExecutorWithRetry(newMember.guild, AuditLogEvent.MemberRoleUpdate, newMember.id);
            if (executor && !await isExempt(newMember.guild, executor, 'permission_escalation')) {
                try {
                    await newMember.roles.remove(dangerousRolesAdded, '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Reverted unauthorized admin role escalation').catch(() => {});
                } catch (_) {}

                await executePunishment(
                    newMember.guild,
                    executor,
                    config,
                    `Unauthorized admin role escalation granted to ${newMember.user.tag}`,
                    'Removed unauthorized admin role(s)'
                );
            }
        });

        client.on('guildUpdate', async (oldGuild, newGuild) => {
            const config = await getConfig(newGuild.id);
            if (!config?.enabled || !config.antiGuildUpdate) return;

            const { executor } = await getAuditLogExecutorWithRetry(newGuild, AuditLogEvent.GuildUpdate);
            await handleAntiAction(newGuild, executor, 'guild_update', config);
        });

        client.on('emojiCreate', async (emoji) => {
            const config = await getConfig(emoji.guild.id);
            if (!config?.enabled || !config.antiEmoji) return;

            const { executor } = await getAuditLogExecutorWithRetry(emoji.guild, AuditLogEvent.EmojiCreate, emoji.id);
            await handleAntiAction(emoji.guild, executor, 'emoji_create', config);
        });

        client.on('emojiDelete', async (emoji) => {
            const config = await getConfig(emoji.guild.id);
            if (!config?.enabled || !config.antiEmoji) return;

            const { executor } = await getAuditLogExecutorWithRetry(emoji.guild, AuditLogEvent.EmojiDelete, emoji.id);
            await handleAntiAction(emoji.guild, executor, 'emoji_delete', config);
        });

        client.on('channelUpdate', async (oldChannel, newChannel) => {
            if (!newChannel.guild) return;

            // TICKET PROTECTION: Ticket channels are frequently claimed, renamed, or have permissions added/removed by ticket bots
            if (isTicketChannel(oldChannel) || isTicketChannel(newChannel)) {
                await saveChannelSnapshot(newChannel);
                return;
            }

            // If we are currently reverting this channel, ignore to prevent feedback loop
            const revertKey = `reverting_channel:${newChannel.id}`;
            if (pendingPunishments.has(revertKey)) return;

            const config = await getConfig(newChannel.guild.id);
            if (!config?.enabled || !config.antiChannelEdit) {
                await saveChannelSnapshot(newChannel);
                return;
            }

            const nameChanged = oldChannel.name !== newChannel.name;
            const topicChanged = oldChannel.topic !== newChannel.topic;
            const parentChanged = oldChannel.parentId !== newChannel.parentId;
            const nsfwChanged = oldChannel.nsfw !== newChannel.nsfw;
            const rateLimitChanged = oldChannel.rateLimitPerUser !== newChannel.rateLimitPerUser;

            if (!nameChanged && !topicChanged && !parentChanged && !nsfwChanged && !rateLimitChanged) {
                return;
            }

            const { executor } = await getAuditLogExecutorWithRetry(newChannel.guild, AuditLogEvent.ChannelUpdate, newChannel.id);
            if (executor) {
                if (await isExempt(newChannel.guild, executor, 'channel_edit')) {
                    await saveChannelSnapshot(newChannel);
                    return;
                }

                // UNAUTHORIZED CHANNEL/CATEGORY EDIT
                // 1. Mark revert key
                pendingPunishments.add(revertKey);
                setTimeout(() => pendingPunishments.delete(revertKey), 5000);

                // 2. INSTANT BAN the attacker
                await newChannel.guild.members.ban(executor.id, {
                    reason: `𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ Anti-Nuke: Unauthorized channel/category edit (${oldChannel.name} -> ${newChannel.name})`
                }).catch(() => {});

                // 3. INSTANT REVERT channel/category back to previous state
                const isCat = oldChannel.type === ChannelType.GuildCategory;
                const revertData = {
                    name: oldChannel.name,
                    position: oldChannel.position,
                    reason: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Reverted unauthorized channel/category edit'
                };
                if (!isCat) {
                    revertData.topic = oldChannel.topic || null;
                    revertData.parent = oldChannel.parentId || null;
                    revertData.nsfw = oldChannel.nsfw || false;
                    revertData.rateLimitPerUser = oldChannel.rateLimitPerUser || 0;
                    if (oldChannel.bitrate) revertData.bitrate = oldChannel.bitrate;
                    if (oldChannel.userLimit) revertData.userLimit = oldChannel.userLimit;
                }

                await newChannel.edit(revertData).catch(() => {});

                // Restore permission overwrites if present
                if (oldChannel.permissionOverwrites) {
                    try {
                        await newChannel.permissionOverwrites.set(
                            oldChannel.permissionOverwrites.cache.map(ow => ({
                                id: ow.id,
                                type: ow.type,
                                allow: ow.allow,
                                deny: ow.deny
                            })),
                            '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Reverted unauthorized channel permissions'
                        ).catch(() => {});
                    } catch (_) {}
                }

                await handleAntiAction(newChannel.guild, executor, 'channel_edit', config, 'Reverted channel/category edit & banned attacker');
            } else {
                // If delayed audit log and name changed suspiciously
                if (nameChanged) {
                    pendingPunishments.add(revertKey);
                    setTimeout(() => pendingPunishments.delete(revertKey), 5000);
                    await newChannel.setName(oldChannel.name, '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Auto-reverted unauthorized rename').catch(() => {});

                    setTimeout(async () => {
                        const lateAudit = await getAuditLogExecutorWithRetry(newChannel.guild, AuditLogEvent.ChannelUpdate, newChannel.id, 5, 200);
                        if (lateAudit.executor && !await isExempt(newChannel.guild, lateAudit.executor, 'channel_edit')) {
                            await newChannel.guild.members.ban(lateAudit.executor.id, {
                                reason: `𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™: Unauthorized channel/category edit`
                            }).catch(() => {});
                            await handleAntiAction(newChannel.guild, lateAudit.executor, 'channel_edit', config, 'Reverted channel/category rename & banned attacker');
                        }
                    }, 500);
                }
            }
        });
    },

    takeFullServerSnapshot,
    recoverChannel,
    sweepAndPurgeRogueChannels,
    restoreAllMissingChannels,
    isTicketChannel
};