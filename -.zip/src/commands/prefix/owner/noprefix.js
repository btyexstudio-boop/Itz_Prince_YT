// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — NoPrefix Owner Command
const { EmbedBuilder } = require('discord.js');
const { NoPrefix } = require('../../../data/models');
const config = require('../../../config');
const emojis = require('../../../emojis.json');
const ms = require('ms');

module.exports = {
    name: 'noprefix',
    aliases: ['np', 'nopref'],
    description: 'Add or remove a user from the no-prefix system',
    usage: 'np add <user> [duration] | np remove <user> | np list | np check <user> | np setup',
    category: 'owner',
    ownerOnly: true,

    async execute(message, args) {
        const devIds = config.DEVELOPER_IDS || [config.OWNER_ID];
        if (!devIds.includes(message.author.id) && message.author.id !== config.OWNER_ID) {
            return message.reply(`${emojis.error || '❌'} You do not have authorization to manage the NoPrefix system.`);
        }

        const action = args[0]?.toLowerCase();

        if (action === 'add') {
            const targetUser = message.mentions.users.first() || await message.client.users.fetch(args[1]).catch(() => null);
            if (!targetUser) return message.reply('Please mention a user or provide a valid user ID.');

            const durationStr = args[2] || 'permanent';
            let expiresAt = null;
            if (durationStr !== 'permanent') {
                const durationMs = ms(durationStr);
                if (!durationMs) return message.reply('Invalid duration. Use formats like 1h, 7d, or permanent.');
                expiresAt = new Date(Date.now() + durationMs);
            }

            await NoPrefix.upsert({
                userId: targetUser.id,
                username: targetUser.username,
                grantedBy: message.author.id,
                grantedByUsername: message.author.username,
                expiresAt,
                duration: durationStr
            });

            NoPrefix.invalidateCache(targetUser.id);

            const embed = new EmbedBuilder()
                .setTitle(`${emojis.zap || '⚡'} No-Prefix Access Granted`)
                .setColor(0x10B981)
                .setDescription(
                    `${emojis.success || '✅'} Granted **No-Prefix** privilege to **${targetUser.tag || targetUser.username}** (<@${targetUser.id}>)!\n\n` +
                    `• **Duration:** \`${durationStr}\`\n` +
                    `• **Expires:** ${expiresAt ? `<t:${Math.floor(expiresAt.getTime() / 1000)}:R>` : '`Never (Permanent)`'}\n` +
                    `• **Granted By:** <@${message.author.id}>`
                )
                .setFooter({ text: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ • NoPrefix Entitlement' })
                .setTimestamp();

            return message.reply({ embeds: [embed] });
        }

        if (action === 'remove') {
            const targetUser = message.mentions.users.first() || await message.client.users.fetch(args[1]).catch(() => null);
            const targetId = targetUser?.id || args[1];

            if (!targetId) return message.reply('Please specify a user to remove: `?np remove @user`');

            const existing = await NoPrefix.findOne({ where: { userId: targetId } });
            if (!existing) {
                return message.reply(`${emojis.info || 'ℹ️'} User \`${targetId}\` is not in the no-prefix list.`);
            }

            await existing.destroy();
            NoPrefix.invalidateCache(targetId);

            const embed = new EmbedBuilder()
                .setTitle(`${emojis.cross || '❌'} No-Prefix Removed`)
                .setColor(0xEF4444)
                .setDescription(`${emojis.success || '✅'} Removed <@${targetId}> (\`${targetId}\`) from the no-prefix list.`)
                .setFooter({ text: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™' })
                .setTimestamp();

            return message.reply({ embeds: [embed] });
        }

        if (action === 'list') {
            const records = await NoPrefix.findAll();

            if (records.length === 0) {
                return message.reply(`${emojis.info || 'ℹ️'} No users are currently in the no-prefix list.`);
            }

            const list = records.map((r, i) => {
                const expiry = r.expiresAt ? `<t:${Math.floor(new Date(r.expiresAt).getTime() / 1000)}:R>` : '`Permanent`';
                return `\`${i + 1}.\` <@${r.userId}> (\`${r.username || r.userId}\`) — ${expiry}`;
            }).join('\n');

            const embed = new EmbedBuilder()
                .setTitle(`${emojis.crown || '👑'} Active No-Prefix Users (${records.length})`)
                .setColor(0x5865F2)
                .setDescription(list)
                .setFooter({ text: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ • Owner System' })
                .setTimestamp();

            return message.reply({ embeds: [embed] });
        }

        if (action === 'check') {
            const targetUser = message.mentions.users.first() || await message.client.users.fetch(args[1]).catch(() => null);
            const targetId = targetUser?.id || args[1];
            if (!targetId) return message.reply('Specify a user to check: `?np check @user`');

            const record = await NoPrefix.findOne({ where: { userId: targetId } });
            if (!record) {
                return message.reply(`${emojis.info || 'ℹ️'} User \`${targetId}\` does not have NoPrefix enabled.`);
            }

            const expiry = record.expiresAt ? `<t:${Math.floor(new Date(record.expiresAt).getTime() / 1000)}:R>` : '`Never (Permanent)`';
            const embed = new EmbedBuilder()
                .setTitle(`${emojis.zap || '⚡'} NoPrefix Status`)
                .setColor(0x10B981)
                .setDescription(
                    `${emojis.success || '✅'} **${record.username || targetId}** has active NoPrefix access!\n\n` +
                    `• **User ID:** \`${record.userId}\`\n` +
                    `• **Duration:** \`${record.duration}\`\n` +
                    `• **Expires:** ${expiry}\n` +
                    `• **Authorized By:** <@${record.grantedBy}>`
                )
                .setFooter({ text: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™' });

            return message.reply({ embeds: [embed] });
        }

        // Help / Usage
        const embed = new EmbedBuilder()
            .setTitle(`${emojis.gear || '⚙️'} No-Prefix System Commands`)
            .setColor(0x5865F2)
            .setDescription(
                `Allows authorized developers and owners to grant global no-prefix access.\n\n` +
                `**Commands:**\n` +
                `• \`?np add <@user/ID> [duration]\` (e.g. \`1d\`, \`7d\`, \`30d\`, or \`permanent\`)\n` +
                `• \`?np remove <@user/ID>\` — Revoke access\n` +
                `• \`?np list\` — View all authorized users\n` +
                `• \`?np check <@user/ID>\` — Check specific user`
            )
            .setFooter({ text: '𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ • Developer Level' });

        return message.reply({ embeds: [embed] });
    }
};