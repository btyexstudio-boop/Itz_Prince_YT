// © Author: itsfizys
// https://discord.gg/aerox



const {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags,
  PermissionFlagsBits,
} = require('discord.js');
const { validateRoleAssignment } = require('../../../../lib/roleSecurity');

function modReply(interaction, title, body, ephemeral = false) {
  const container = new ContainerBuilder().setAccentColor(0x2B2D31)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`**${title}**`))
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(body));
  return interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2, ephemeral });
}

module.exports = {
  name: 'rolegive',
  description: 'Give a role to a user',

  async execute(interaction) {
    const targetUser = interaction.options.getUser('user');
    const targetMember = interaction.options.getMember('user');
    const role = interaction.options.getRole('role');

    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageRoles))
      return modReply(interaction, 'Permission Denied', 'You need the **Manage Roles** permission.', true);

    if (!targetMember)
      return modReply(interaction, 'User Not Found', 'User is not in this server.', true);

    // Strict role security & privilege escalation check
    const securityCheck = await validateRoleAssignment(interaction.guild, role, interaction.member);
    if (!securityCheck.allowed) {
      return modReply(interaction, 'Security Restriction', securityCheck.error, true);
    }

    if (targetMember.roles.cache.has(role.id))
      return modReply(interaction, 'Role Already Assigned', 'User already has this role.', true);

    try {
      await targetMember.roles.add(role, `[ROLEGIVE] By ${interaction.user.tag}`);
      await modReply(interaction, 'Role Given',
        `**User:** ${targetUser}\n**Role:** ${role.name}\n**Given by:** ${interaction.user.tag}`);
    } catch (error) {
      const msg = error.code === 50013 ? 'I lack the permissions to manage this role.' : 'Failed to give role.';
      await modReply(interaction, 'Error', msg, true);
    }
  },
};

/**
 * Project: Melon
 * Author: itsfizys (Aegis)
 * Organization: AeroX Development
 * GitHub: https://github.com/itsfizys
 * License: Custom
 * © 2026 AeroX Development. All rights reserved.
 */