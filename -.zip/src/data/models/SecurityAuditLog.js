// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — SecurityAuditLog Model
const { DataTypes } = require('sequelize');
const BaseModel = require('../BaseModel');

class SecurityAuditLog extends BaseModel {
    static init(sequelize) {
        super.init(
            {
                id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
                guildId: { type: DataTypes.STRING, allowNull: false, comment: 'Discord Guild ID or GLOBAL' },
                module: { type: DataTypes.STRING, allowNull: false, comment: 'ANTINUKE, AUTOMOD, MODERATION, PREMIUM, DASHBOARD' },
                action: { type: DataTypes.STRING, allowNull: false, comment: 'Specific action performed' },
                severity: { type: DataTypes.STRING, defaultValue: 'INFO', comment: 'INFO, WARNING, CRITICAL' },
                executorId: { type: DataTypes.STRING, allowNull: true, comment: 'User or system ID' },
                targetId: { type: DataTypes.STRING, allowNull: true, comment: 'Target user/channel/role ID' },
                reason: { type: DataTypes.STRING, allowNull: true, comment: 'Context or reason' },
                details: {
                    type: DataTypes.TEXT,
                    allowNull: true,
                    defaultValue: '{}',
                    get() {
                        const val = this.getDataValue('details');
                        try { return val ? JSON.parse(val) : {}; } catch { return {}; }
                    },
                    set(val) {
                        this.setDataValue('details', typeof val === 'object' ? JSON.stringify(val) : val);
                    }
                }
            },
            {
                sequelize,
                modelName: 'SecurityAuditLog',
                tableName: 'security_audit_logs',
                timestamps: true,
                indexes: [
                    { fields: ['guildId'] },
                    { fields: ['module'] },
                    { fields: ['createdAt'] }
                ]
            }
        );
        return this;
    }
}

module.exports = SecurityAuditLog;
