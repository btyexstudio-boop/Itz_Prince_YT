// © Author: itsfizys
// https://discord.gg/aerox

const { DataTypes } = require('sequelize');
const sequelize = require('../sequelize');
const BaseModel = require('../BaseModel');

class TempChannel extends BaseModel {
    static CACHE_KEYS = [['channelId'], ['guildId', 'ownerId']];
    static init(sequelize) {
        super.init(
            {
                id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
                channelId: { type: DataTypes.STRING, allowNull: false, unique: true, comment: 'Discord Voice Channel ID' },
                guildId: { type: DataTypes.STRING, allowNull: false, comment: 'Discord Guild ID' },
                ownerId: { type: DataTypes.STRING, allowNull: false, comment: 'Discord User ID of owner' },
            },
            {
                sequelize,
                modelName: 'TempChannel',
                tableName: 'temp_channels',
                timestamps: false,
                indexes: [
                    {
                        unique: true,
                        fields: ['channelId'],
                    },
                    {
                        fields: ['guildId', 'ownerId'],
                    },
                ],
            }
        );
        return this;
    }
}

module.exports = TempChannel;

/*
: ! Aegis !
    + Discord: itsfizys
    + Portfolio: https://itsfiizys.com
    + Community: https://discord.gg/8wfT8SfB5Z  (Melon )
    + for any queries reach out Community or DM me.
*/

/*
: ! Aegis !
    + Discord: itsfizys
    + Portfolio: https://itsfiizys.com
    + Community: https://discord.gg/8wfT8SfB5Z  (Melon )
    + for any queries reach out Community or DM me.
*/

/**
 * Project: Melon
 * Author: itsfizys (Aegis)
 * Organization: AeroX Development
 * GitHub: https://github.com/itsfizys
 * License: Custom
 * © 2026 AeroX Development. All rights reserved.
 */