// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Subscription Model
const { DataTypes } = require('sequelize');
const BaseModel = require('../BaseModel');

class Subscription extends BaseModel {
    static CACHE_KEYS = [['userId']];

    static PLANS = {
        FREE: 'FREE',
        PREMIUM: 'PREMIUM',
        LIFETIME: 'LIFETIME',
        ENTERPRISE: 'ENTERPRISE'
    };

    static init(sequelize) {
        super.init(
            {
                id: { type: DataTypes.STRING, primaryKey: true, comment: 'Subscription UUID' },
                userId: { type: DataTypes.STRING, allowNull: false, comment: 'Discord User ID' },
                plan: { type: DataTypes.STRING, defaultValue: 'FREE', comment: 'Plan: FREE, PREMIUM, LIFETIME, ENTERPRISE' },
                status: { type: DataTypes.STRING, defaultValue: 'ACTIVE', comment: 'ACTIVE, EXPIRED, CANCELLED, PENDING' },
                maxSlots: { type: DataTypes.INTEGER, defaultValue: 1, comment: 'Number of servers allowed' },
                startDate: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
                endDate: { type: DataTypes.DATE, allowNull: true, comment: 'Null for Lifetime' },
                source: { type: DataTypes.STRING, defaultValue: 'MANUAL', comment: 'PAYPAL, STRIPE, CODE, DEVELOPER, MANUAL' },
                paymentId: { type: DataTypes.STRING, allowNull: true },
                autoRenew: { type: DataTypes.BOOLEAN, defaultValue: false },
                metadata: {
                    type: DataTypes.TEXT,
                    allowNull: true,
                    defaultValue: '{}',
                    get() {
                        const val = this.getDataValue('metadata');
                        try { return val ? JSON.parse(val) : {}; } catch { return {}; }
                    },
                    set(val) {
                        this.setDataValue('metadata', typeof val === 'object' ? JSON.stringify(val) : val);
                    }
                }
            },
            {
                sequelize,
                modelName: 'Subscription',
                tableName: 'subscriptions',
                timestamps: true,
                indexes: [
                    { fields: ['userId'] },
                    { fields: ['status'] }
                ]
            }
        );
        return this;
    }
}

module.exports = Subscription;
