// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — RedemptionCode Model
const { DataTypes } = require('sequelize');
const BaseModel = require('../BaseModel');

class RedemptionCode extends BaseModel {
    static CACHE_KEYS = [['code']];

    static init(sequelize) {
        super.init(
            {
                id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
                code: { type: DataTypes.STRING, allowNull: false, unique: true, comment: 'Redemption code e.g. ZORVIX-PREM-XXXXX' },
                plan: { type: DataTypes.STRING, defaultValue: 'PREMIUM', comment: 'PREMIUM, LIFETIME, ENTERPRISE' },
                durationDays: { type: DataTypes.INTEGER, defaultValue: 30, comment: 'Duration in days (0 for lifetime)' },
                slots: { type: DataTypes.INTEGER, defaultValue: 1, comment: 'Allowed server slots' },
                isRedeemed: { type: DataTypes.BOOLEAN, defaultValue: false },
                redeemedBy: { type: DataTypes.STRING, allowNull: true, comment: 'Discord User ID' },
                redeemedAt: { type: DataTypes.DATE, allowNull: true },
                createdBy: { type: DataTypes.STRING, allowNull: false, comment: 'Developer User ID' },
            },
            {
                sequelize,
                modelName: 'RedemptionCode',
                tableName: 'redemption_codes',
                timestamps: true,
                indexes: [
                    { unique: true, fields: ['code'] },
                    { fields: ['isRedeemed'] }
                ]
            }
        );
        return this;
    }
}

module.exports = RedemptionCode;
