// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — PremiumSlot Model
const { DataTypes } = require('sequelize');
const BaseModel = require('../BaseModel');

class PremiumSlot extends BaseModel {
    static CACHE_KEYS = [['guildId'], ['userId']];

    static init(sequelize) {
        super.init(
            {
                id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
                userId: { type: DataTypes.STRING, allowNull: false, comment: 'Discord User ID owner of slot' },
                guildId: { type: DataTypes.STRING, allowNull: false, unique: true, comment: 'Activated Guild ID' },
                subscriptionId: { type: DataTypes.STRING, allowNull: true, comment: 'Associated Subscription ID' },
                status: { type: DataTypes.STRING, defaultValue: 'ACTIVE', comment: 'ACTIVE, REVOKED, EXPIRED' },
                activatedAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
            },
            {
                sequelize,
                modelName: 'PremiumSlot',
                tableName: 'premium_slots',
                timestamps: true,
                indexes: [
                    { unique: true, fields: ['guildId'] },
                    { fields: ['userId'] }
                ]
            }
        );
        return this;
    }
}

module.exports = PremiumSlot;
