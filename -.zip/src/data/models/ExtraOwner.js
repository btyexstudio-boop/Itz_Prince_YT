// 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — ExtraOwner Model
const { DataTypes } = require('sequelize');
const BaseModel = require('../BaseModel');

class ExtraOwner extends BaseModel {
    static CACHE_KEYS = [['guildId', 'userId']];

    static init(sequelize) {
        super.init(
            {
                id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
                guildId: { type: DataTypes.STRING, allowNull: false, comment: 'Discord Guild ID' },
                userId: { type: DataTypes.STRING, allowNull: false, comment: 'Extra Owner User ID' },
                addedBy: { type: DataTypes.STRING, allowNull: false, comment: 'Guild Owner who added this user' },
            },
            {
                sequelize,
                modelName: 'ExtraOwner',
                tableName: 'extra_owners',
                timestamps: true,
                indexes: [
                    {
                        unique: true,
                        fields: ['guildId', 'userId'],
                    },
                ],
            }
        );
        return this;
    }

    static async isExtraOwner(guildId, userId) {
        if (!guildId || !userId) return false;
        try {
            const entry = await this.findOne({ where: { guildId: String(guildId), userId: String(userId) } });
            return !!entry;
        } catch (_) {
            return false;
        }
    }
}

module.exports = ExtraOwner;
