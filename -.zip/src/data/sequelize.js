const { Sequelize } = require('sequelize');
const config = require('../config');
const rawUrl = process.env.DATABASE_URL;
const DATABASE_URL = (rawUrl && !rawUrl.includes('username:password') && !rawUrl.includes('localhost:5432')) ? rawUrl : (config.DATABASE_URL || 'postgresql://neondb_owner:npg_0sb7MUxrtugy@ep-little-water-adb9fuko.c-2.us-east-1.aws.neon.tech/neondb?sslmode=require');

const sequelize = new Sequelize(DATABASE_URL, {
    dialect: 'postgres',
    logging: false,
    define: {
        timestamps: true,
    },
    pool: {
        max: 10,
        min: 0,
        acquire: 45000,
        idle: 30000,
        evict: 15000
    },
    dialectOptions: {
        ssl: {
            require: true,
            rejectUnauthorized: false
        },
        keepAlive: true
    },
    retry: {
        max: 5,
        match: [
            /SequelizeConnectionError/,
            /SequelizeConnectionRefusedError/,
            /SequelizeHostNotFoundError/,
            /SequelizeHostNotReachableError/,
            /SequelizeInvalidConnectionError/,
            /SequelizeConnectionTimedOutError/,
            /ECONNRESET/,
            /ECONNREFUSED/,
            /Connection terminated unexpectedly/i,
            /SSL SYSCALL error/i,
            /EOF detected/i,
            /closed unexpectedly/i,
            /server closed the connection unexpectedly/i,
            /57P01/,
            /Connection reset by peer/i,
            /ETIMEDOUT/i
        ],
    }
});

module.exports = sequelize;

/**
 * Project: Melon
 * Author: itsfizys (Aegis)
 * Organization: AeroX Development
 * GitHub: https://github.com/itsfizys
 * License: Custom
 * © 2026 AeroX Development. All rights reserved.
 */