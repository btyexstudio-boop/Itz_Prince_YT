const { Pool } = require('pg');
const rawUrl = process.env.DATABASE_URL;
const connectionString = (rawUrl && !rawUrl.includes('username:password') && !rawUrl.includes('localhost:5432')) ? rawUrl : config.DATABASE_URL;

const pool = new Pool({
    connectionString,
    ssl: {
        require: true,
        rejectUnauthorized: false
    },
    max: 10,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 10000
});

pool.on('error', (err) => {
    console.error('[PostgreSQL] Unexpected error on idle client:', err.message);
});

const query = async (text, params) => {
    try {
        const res = await pool.query(text, params);
        return res;
    } catch (err) {
        return { rows: [], rowCount: 0 };
    }
};

const getOne = async (text, params) => {
    try {
        const res = await pool.query(text, params);
        return res.rows[0] || null;
    } catch (err) {
        return null;
    }
};

const getAll = async (text, params) => {
    try {
        const res = await pool.query(text, params);
        return res.rows;
    } catch (err) {
        return [];
    }
};

const run = async (text, params) => {
    try {
        const res = await pool.query(text, params);
        return { changes: res.rowCount };
    } catch (err) {
        return { changes: 0 };
    }
};

module.exports = { pool, query, getOne, getAll, run };

/**
 * Project: Melon
 * Author: itsfizys (Aegis)
 * Organization: AeroX Development
 * GitHub: https://github.com/itsfizys
 * License: Custom
 * © 2026 AeroX Development. All rights reserved.
 */