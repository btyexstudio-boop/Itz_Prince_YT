# 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™ — Production Deployment & Operator Manual

## 1. Project Overview

**𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™** is an enterprise-grade Discord server protection bot, moderation automation platform, and full-stack web dashboard built on Node.js and Discord.js.

- **Bot Name**: 𝐙𝐨𝐫𝐯𝐢𝐱 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲™
- **Default Prefix**: `?`
- **Dashboard Web Port**: `3000` (host `0.0.0.0`)
- **Key Capabilities**: Anti-Nuke, Advanced AutoMod, Multi-Server Isolation, Entitlement Licensing, NoPrefix VIP System, Live Threat Simulator, Full Web Dashboard.

---

## 2. Environment Configuration

Copy `.env.example` to `.env` and provide your production credentials:

```bash
cp .env.example .env
```

### Essential Variables

| Variable | Description | Example |
| :--- | :--- | :--- |
| `PORT` | Web server port (always 3000 in AI Studio) | `3000` |
| `BOT_TOKEN` | Discord Bot Token from Discord Developer Portal | `MTM5...` |
| `CLIENT_ID` | Discord Application Client ID | `1390663877544509580` |
| `OWNER_ID` | Discord User ID of the primary bot owner | `1124248109472550993` |
| `DEVELOPER_IDS`| Comma-separated Discord User IDs for dev commands | `1124248109472550993,1234567890` |
| `PREFIX` | Default text command prefix | `?` |
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://user:pass@host:5432/db` |
| `DISCORD_CLIENT_SECRET` | OAuth2 Client Secret for dashboard login | `your_secret` |
| `SESSION_SECRET` | Secure cryptographic session key | `random_secret_hash` |
| `STRIPE_SECRET_KEY` | Stripe live or test secret API key | `sk_test_...` |
| `STRIPE_WEBHOOK_SECRET` | Stripe signing webhook secret | `whsec_...` |

---

## 3. Installation & Startup

### Install Dependencies
```bash
npm install
```

### Run Full Test Suite
```bash
npm test
```

### Start Development Server & Bot
```bash
npm run dev
```

### Production Build & Launch
```bash
npm run build
npm start
```

---

## 4. Command Reference

### Anti-Nuke Commands (`?antinuke` or `?an`)
- `?antinuke status` — View active protection state, threshold, and timeframe.
- `?antinuke enable` — Activate real-time Anti-Nuke containment.
- `?antinuke disable` — Temporarily deactivate Anti-Nuke.
- `?antinuke wizard` — Run step-by-step interactive setup wizard.
- `?antinuke filters` — Inspect status of all 12 protection event filters.
- `?antinuke logs` — View recent incident logs and containment triggers.
- `?antinuke wl add @user` — Add trusted administrator to bypass whitelist.
- `?antinuke unwl @user` — Remove administrator from whitelist.
- `?antinuke wlist` — List all whitelisted administrators.
- `?antinuke wlreset` — Reset whitelist to empty (Server Owner only).
- `?antinuke settings` — View and edit current thresholds and punishment.

### Extra Owner Commands (`?extraowner` or `?eo`)
- `?extraowner set @user` — Designate an Extra Owner (Server Owner only).
- `?extraowner view` — List current Extra Owners.
- `?extraowner reset` / `clear` — Clear all Extra Owners (Server Owner only).

### AutoMod Commands (`?automod` or `?am`)
- `?automod status` — View AutoMod state and active filter counts.
- `?automod enable` / `disable` — Toggle AutoMod engine.
- `?automod rules` — List active rules (Spam, Invites, Links, Mentions, Caps, Emojis, Zalgo, NSFW).
- `?automod logs` — View recent AutoMod violations.
- `?automod blacklist add <word>` — Add term to prohibited words list.
- `?automod blacklist remove <word>` — Remove term from blacklist.
- `?automod blacklist list` — Display all blacklisted words.
- `?automod whitelist` — Manage exempt channels, roles, and users.

### Moderation Commands
- `?ban @user [reason]` / `?unban <id>` — Member ban and revocation.
- `?kick @user [reason]` — Kick member from server.
- `?timeout @user <duration>` — Apply Discord timeout.
- `?warn @user [reason]` / `?warnings @user` / `?clearwarns @user` — Warn system.
- `?purge <count>` — Mass message purge within API limits.
- `?lock` / `?unlock` — Lock down channel permissions.
- `?slowmode <seconds>` — Configure channel slowmode.
- `?nick @user <new_nickname>` — Manage nicknames.
- `?cases` — Browse moderation audit case records.

### Subscriptions & Premium Commands
- `?premium status` — View server protection tier and personal slots.
- `?premium activate` — Activate current server using an entitlement slot.
- `?premium servers` / `?premium slots` — View active server slot allocations.
- `?plans` / `?premium features` — View and compare subscription tiers.
- `?redeem <CODE>` — Redeem a `ZORVIX-PREM-XXXXX` license key.
- `?addpremium @user <plan> <days> <slots>` — Grant entitlement (Developer only).
- `?removepremium @user` — Revoke entitlement (Developer only).
- `?premium createcode <plan> <days> <slots>` — Generate license code (Developer only).
- `?premium codes` — View generated license codes (Developer only).
- `?premium audit` — View global security audit logs (Developer only).

### NoPrefix Commands (`?np`)
- `?np add @user [duration]` — Grant prefix-less command execution.
- `?np remove @user` — Revoke NoPrefix entitlement.
- `?np list` — View all users with NoPrefix access.
- `?np check @user` — Check if a specific user has NoPrefix.
- `?np setup` — View system configuration and usage.

---

## 5. Web Dashboard Architecture

The dashboard runs on Port 3000 and connects directly to the bot backend:

1. **Overview & Analytics**: Live bot cluster telemetry, threat containment counters, gateway latency.
2. **Server Security Center**: Comprehensive security score breakdown per guild.
3. **Anti-Nuke Configurator**: Adjust thresholds, timeframes, and punishments with one click.
4. **AutoMod Rules**: Granular toggles for Zalgo, spam, attachments, invites, and bad words.
5. **Logging Dashboard**: Configure 6 separate Discord log channels.
6. **Whitelist & Extra Owners**: Add and remove trusted staff members.
7. **Threat Simulator**: Live sandbox terminal to test attacks against bot defenses in real time.
8. **Developer Command Center**: Instant redemption code generator, subscriber overview, and audit trails.
